+++++++++++++++++++++++++++++++++++++++
+				      +
+	The Trinity Gamma Patch	      +
+  Upgraded by UNOWN X and Articuno   +
+	       Patch v3.0	      +
+				      +
+++++++++++++++++++++++++++++++++++++++

(Gamma Info)

Trinity Gamma was created by UNOWN X and is an upgrade of the Trinity Alpha Patch.

All credit is due to Trinity and more especially, Proteus for making the base version. Visit
the Trinity site at http://trinity.blinkz.net.

Go to www.tyais.com/gamma for the official site of Trinity Gamma.

========================================================

QUICK NOTES:

All the Neo2 and Neo3 translations are checked and re-checked using the Edo Translations.
Edo's Small Pokemon Web Site can be found at http://www.geocities.com/TimesSquare/Alley/2247/Poke.htm

All Neo2 and Neo3 translations are UN-OFFICIAL, however, should be used as the most accurate
translations. If you find any errors in the patch, report them in #pokegym and it will find its 
way into being corrected.


RELEASE NOTES:

v4.0c - I added the Smeargle Promo (Season 3 of Pokemon League).

v4.0b - Arti fixed a bunch of spelling errors pointed out by Zapdos

v4.0 - I fixed all of the Gym sets! Wahoo! There were a TON of card placing mistakes, rarity mistakes,
etc. However, I fixed most of them. The only currently known errors in the entire patch are these:
There is 1 extra card in Gym2, and there are 2 missing cards in Gym1. If you can give us info on ANY
of these, E-mail us at Pokegym@Tyais.com and tell us. As well, if you see any other mistakes (mainly
rarity mistakes) tell us quick!

v2.4 - Fixed some random Neo and Neo2 mistakes

v2.3 - Fixed all the Team Rocket mistakes

v2.2 - Fixed all the Fossil Mistakes

v2.1 - I went through and corrected all the card mistakes in the Jungle Expansion. If you find
any mistakes from cards in Jungle Expansion, report them in #pokegym.

v2.0 - Second release of Gamma (though it won't be open for public for awhile) is release. I have
corrected all errors in the Neo: Genesis Set. Also, I have updated the patch with the big release
of Neo3. (Which is why it is a full upgrade.)

v1.0 - The first set of Gamma is released. All Neo cards are 100% English. Neo2 has had all the
errors in it checked and fixed.


SETS NOTES:
Base Set 1
Jungle
Fossil
Base Set 2
Team Rocket
Gym: Heroes
Gym: Challenge
Neo: Genesis
American Promos #1-#31 (League Pikachu - Cleffa(Bill))
Neo 2 (Japanse)
Neo 3 (Japanese)
Southern Islands (Japanese)
Vending Machine (Japanase)
CD Promos (Japanese)
Japanse Only Cards (Japanese)

============================================================================

(Alpha Info)

Legal Notes:
-This file has tags written throughout it and is legally protected by copyrights. If you attempt to altar this file in any way, your attempts will be punished by the full extent of the law. If any attempt of selling this patch is discovered, Ninentendo, Wizards of the Coast, and Gamefreak will be contacted.
-Basis of this patch was created by Proteus.
-The Gamma upgrade was created by an announomous person.
-Visit us at http://trinity.blinkz.net (Alpha version)

Dedications:
I would like to thank Desi for being my noble assistant on this patch, and checkerbee for making the wonderful translation guide I used for gym and neo spoilers. Thanks to Mew151, BladeHonduro, and PokemonMatt for the Neo II spoiler. Also thanks to Inquest Gamer for the Vending Machine and Promo spoilers. Thanks to Metathran for being my inspiration for this patch. Finally thanks to Wizards, Nintendo, and all those other guys for making this excellent TCG.

IMPORTANT!: Some cards have so much text in them, that it does not all fit in text box. So if you are looking at one of these cards, please click and hold the mouse in the txt box and move your mouse down to see the rest of it.

Release Notes:

Alpha 2.6
-Fixed errors with Brock's Rhyhorn.
-Fixed Electrode's self damage.
-Fixed a few spelling errors.

Alpha 2.3
-Added Watermark

Alpha 2.2
-Made Gym1 American Set Friendly
-Renamed Gym1 to Gym: Heroes
-Fixed a few minor problems

Alpha 2.1
-Added Foretosu, a card I forgot in Neo 2
-Changed Annon to Annon I
-Removed Pokeleague set
-Combined pokeleague and x-league patch since they were no different

Alpha 2.0
-Added the complete Neo II set
-Fixed Rocket's Scyther's shadow attack.

Alpha 1.0
-Fixed pokeball and other minor card problems.
-Changed the name, DUH
-Fixed yet some more legal info
-Changed setup file
-Trinity and Neo are now used in Pokeleague (#pokeleague, newnet irc), Pojoleague (#pojo, dalnet irc), and X-League (#[x]-league, newnet irc).

Version 9.1
-Reconfigured **Credits** to include the version number.
-Added a spiffy new install program.

Version 9.0
-Important Gym 1 mistranslations are fixed, but I don't think I have 
 them all fixed. (If you see any more mistranslations, e-mail them to 
 DesiGuy421@aol.com).

Version 8.7
-Ancient Mew and the legendary birds from the vending machine set have
 been included with American Promos due to the fact that these will be
 the movie promos for Pokemon The Movie 2000.
-Text file enclosed containing information on new formats.
-Fixed several errors on some cards.
-Added the new Promo Eevee L6 that will be released (pretty wicked
 card).
-Added Vanguard cards. For more information on vanguard, type !vanguard
 when Articuno is on.
-Fixed several errors with the "evil" to "dark" transition.
-I made the cards so that each attack is on a separate line, which 
 makes it easier to read.

Version 8.4
-Added bill (DAMN HOW DID THAT GET REMOVED!?!?!?!?)

Version 8.3
-Fixed problems that were in 8.2, mainly that the cardinfo.dat files were exactly the same :)

Version 8.2
-Added Blaine's Ponyta, Rapidash, and Mankey to Gym 2
-Errata made for several Pokeleague Cards
-According to Nintendo, the two new types of pokemon in G/S are the
 "Dark" type and "Steel" type. So Evil energy and evil pokemon are 
 changed to "Dark" types. The new symbol for Dark Energy is D.
-Moved Dark and Steel Energy to PKLG expansion.
-Added Poison Energy to PKLG expansion.

Version 8.1
-Added the missing Blaine's Moltres to Gym 2
-Errata made for several Pokeleague Cards
-Fixed several errors
-Added some new cards to the Pokeleague Expansion

Version 8.0
-Fixed final errors

Version 7.1
-Fixed some errors caused by one of the fantasy contest patchers
-Added the Pokeleague Chaos addon

Version 7.0
-Added the rest of the Pokeleague Expansion
-Fixed Gameboy Articuno

Version 6.2
-Fixed minor errors in base set

Version 6.1
-Fixed some errors
-Added new English Team Rocket card, Dark Raichu

Version 6.0
-Fixed spelling errors
-Added gameboy cards
-Added Pokeleague expansion
-Added Blaine's Ninetails

Version 5.2
-Fixed 59 minor spelling errors

Version 5.1
-Fixed error on moltres
-Fixed Cool Porygon error
-Fixed Tauros color

Version 5.0
-Final Version, every pokemon card in the world added

Version 4.1
-Fixed all errors, being distributed to pokeleague judges non colorized

Version 4.0
-Fixed some minor errors, added vending sheet, added more promos

Version 3.0
-Fixed compatibility errors with fossil and energy search, added intro set

Version 2.01
-Some minor errors fixed from version 2.0.

Version 2.0
-Contains almost all cards ever printed (we think), in all correct format.
-Official patch of the Pojo Apprentice League.

Version 1.9
-Contained limited version of Gym 2, also buggy.

Version 1.2
-Removed Gym 1 (VERY BUGGY) and completely fixed the rest of the sets.
-Official Pokemon patch of E-League.

Version 1.1
-Added color listings to the cards, and added in a few American promos.

Version 1.01
-Removed a lot of bugs from cards.

Version 1.0
-Added Base Set, Jungle, Fossil, and Gym Leaders 1


Questions/Comments/Complaints about the patch can go to proteus@blinkz.net.
