import glob
import base58
import logging
import hashlib
import binascii
import re

"""
v1.0.0 - 2021-02-27
Author: krzotr@zeroid.bit

To get more details please check the find_address_by_hash_info.py file

To reverse hash => Zite i have generated that script. The output of the file
contains addresses of Zite from different sources

Merge all zites and generate zites.txt file

Zites got from:
    2021-02-27 - Zirch Automated Search
        cat search.json | jq -r '.[].name' | sort -u > ZirchAutomatedSearch.txt

    2021-02-27 - RVRE
        cat data.json | jq -r '.zites[] | .Address'  | sort -u > RVRE.txt
    
    2021-02-27 - Kaffiene Search
        cat data.txt | rev | cut -d ' ' -f 2 | cut -d ':' -f 1 | rev | sort -u > KaffieneSearch.txt
            
    2021-02-27 - EulerFinder      
        cat sites.json | jq -r '.zites[][2]' | sort -u > EulerFinder.txt

    2021-02-27 -Zoogle Zearch
        cat ZoogleZearch.json | jq -r '.zites[] | .Address' | sort -u > ZoogleZearch.txt

    2021-02-27 - Dream Search + blocklist

    2021-02-27 - Sites.ZeroNetwork.bit
        Just open zerosite.db and execute SQL query - "SELECT address FROM site"

    2021-02-27 - ZeroName
        
    2019-01-21
        http://127.0.0.1:43115/1TaLkFrMwvbNsooF4ioKAY9EuxTBTjipT/?Topic:1548083742_14ytAKDfNjArMTqGecTi7ginG3aZTsRAum/Unlock+all+sites+in+2+steps+safely        

Usage:
    ./address_merger.py > zites.txt
"""

zites = []

logging.basicConfig(level=logging.WARNING)


# Lazy function to check BTC address
#     https://medium.com/coinmonks/bitcoin-address-validation-on-python-a0123ba3adb8
def verify_bitcoin_address(address):
    try:
        base58_address = base58.b58decode(address).hex()

        prefix_hash = base58_address[:len(base58_address)-8]
        checksum = base58_address[len(base58_address)-8:]
    except ValueError as e:
        logging.debug("VerifyBTCAddress: Got exception '%s' for '%s'" % (
            str(e), address))
        return False

    calculated_address_hash = prefix_hash
    for x in range(1, 3):
        calculated_address_hash = hashlib.sha256(binascii.unhexlify(
            calculated_address_hash)).hexdigest()

    calculated_checksum = calculated_address_hash[:8]

    # print("Address: " + address)
    # print("Base58 Address: " + base58_address)
    # print("Prefix Hash: " + prefix_hash)
    # print("Checksum: " + checksum)
    # print("Address Hash: " + calculated_address_hash)
    # print("Calculated Checksum: " + calculated_checksum)
    # print("Is valid BTC address? %s" % (checksum == calculated_checksum, ))

    return checksum == calculated_checksum


def add_zite(zite):
    global zites

    # Remove last lines
    zite = zite.strip()
    address = zite

    # Skip comments
    if "#" == address[0:1]:
        logging.debug("Filter: Skipped comment line '%s'" % address)
        return False

    # Skip empty lines
    if not address:
        logging.debug("Filter: Skipped empty line")
        return False

    # Remove everything behind "/"
    # e.g. 1LUW1nUq3wng1M2G3yCXmqapuxAkvaRX3w/?Home -> 1LUW1nUq3wng1M2G3yCXmqapuxAkvaRX3w
    if "/" in address:
        address, _ = address.split("/", 1)
        logging.debug("Converter: Found '/', reduced from '%s' to '%s'" % (
            zite, address))

    if "#" in address:
        address, _ = address.split("#", 1)
        logging.debug("Converter: Found '#', reduced from '%s' to '%s'" % (
            zite, address))

    # Remove all .bit addresses
    if ".bit" in address.lower():
        logging.debug("Filter: Skipped '.bit' address '%s'" % address)
        return False

    if not re.match(r"^[A-Za-z0-9]+$", address):
        logging.debug("Filter: Address '%s' contains incorrect charractes" %
                      address)
        return False

    if not verify_bitcoin_address(address):
        logging.debug("Filter: BTC address '%s' is not valid!" % address)
        return False

    # Already on list!
    if address in zites:
        return False

    zites.append(address)

    return True


for f in glob.glob("./zites/*.txt"):
    with open(f, "r") as zite_file:
        for line in zite_file.readlines():
            add_zite(line)

for zite in zites:
    print(zite)
