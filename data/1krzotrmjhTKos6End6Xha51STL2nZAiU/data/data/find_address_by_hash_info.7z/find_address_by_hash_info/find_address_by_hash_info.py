import sys
from urllib.parse import unquote_to_bytes
import hashlib
import binascii
import json

"""
v1.0.0 - 2021-02-27
Author: krzotr@zeroid.bit


Regarding https://www.welivesecurity.com/2021/02/22/brave-browser-tor-mode-exposed-dark-web-activity/

"If you're using Brave you probably use it because you expect a certain level
of privacy/anonymity. Piping .onion requests through DNS where your ISP or
DNS provider can see that you made a request for an .onion site defeats that
purpose"

What about ZeroNet?

When you use HTTP (unsecure) trackers to get peers your ISP can get
information about sites which you visit and share. Is very easy to find ZeroNet
requests (just find left=431102370 and event=started - means ZeroNet)

To get peers ZeroNet sends HTTP request to server e.g.
    GET /announce?info_hash=%86%D6%5B%F5%A8%DE%A3%EB%E1%96%5C%FEi%06g%25%5D%90d~&peer_id=-UT3530-mVSHktxFVXdE&port=1&uploaded=0&downloaded=0&left=431102370&compact=1&numwant=30&event=started HTTP/1.1

info_hash is url encoded sha1 of Zite e.g.
    sha1("1HeLLo4uzjaLetFx6NH3PMwFP3qbRbTf3D") == 86d65bf5a8dea3ebe1965cfe690667255d90647e
    urlencode(86d65bf5a8dea3ebe1965cfe690667255d90647e) == %86%D6%5B%F5%A8%DE%A3%EB%E1%96%5C%FEi%06g%25%5D%90d~

To reverse hash => Zite i have generated zites.txt file using another script
`address_merger.py`. That file contains addresses of Zite from names.json file,
from `Sites.ZeroNetwork.bit` and other

If Zite has been found that script uses names.json to resolve `.bit` domain


usage:
    ./find_address_by_hash_info.py "%86%D6%5B%F5%A8%DE%A3%EB%E1%96%5C%FEi%06g%25%5D%90d~"

result:
    Zite tracker hash: %86%D6%5B%F5%A8%DE%A3%EB%E1%96%5C%FEi%06g%25%5D%90d~
            Zite hash: 86d65bf5a8dea3ebe1965cfe690667255d90647e

         Zite Address: 1HeLLo4uzjaLetFx6NH3PMwFP3qbRbTf3D
              Domains:
                        952754.bit
                        agora.bit
                        apkg.bit
                        (...)



"""

ZERO_NAME_JSON = "./names.json"
ZITES = "./zites.txt"


def parse_zite_hash(zite_hash):
    zite_hash = unquote_to_bytes(zite_hash)

    return zite_hash


def get_zite_sha1_hash(zite):
    return hashlib.sha1(zite.encode("ascii")).digest()


def get_domains_for_zite(zite):
    with open(ZERO_NAME_JSON, "r") as zite_name_file:
        zites = json.loads(zite_name_file.read())

    domains = []

    for domain, z in zites.items():
        if z == zite:
            domains.append(domain)

    return domains


def find_addr(zite_tracker_hash):
    zite_sha1_hash = parse_zite_hash(zite_tracker_hash)

    with open(ZITES, "r") as zite_file:
        for line in zite_file.readlines():
            addr = line.strip()
            zite_hash = get_zite_sha1_hash(addr)

            if zite_sha1_hash == zite_hash:
                print("Zite tracker hash: %s " % zite_tracker_hash)
                print("        Zite hash: %s " % binascii.hexlify(
                    zite_sha1_hash).decode())
                print("")
                print("     Zite Address: %s " % addr)

                domains = get_domains_for_zite(addr)

                if domains:
                    print("          Domains:")

                    for d in domains:
                        print("                    %s" % d)

                    return

    print("Nothing found :(")
    exit(1)


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Find ZeroNet Zite address based on info_hash sent to BitTorrent tracker")
        print("")
        print("    Usage:")
        print("        ./find_address_by_hash_info.py \"%86%D6%5B%F5%A8%DE%A3%EB%E1%96%5C%FEi%06g%25%5D%90d~\"")
        exit(255)

    find_addr(sys.argv[1])
