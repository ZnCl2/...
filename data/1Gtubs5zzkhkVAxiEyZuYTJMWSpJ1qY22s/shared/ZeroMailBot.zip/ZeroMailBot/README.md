## Local ZeroMail Bot

This is a Python2 script that decrypts your ZeroMail and sends them to a local bot. After you schedule the bot and follow it, you can receive new ZeroMail notification from ZeroHello newsfeed.

## How to install:

1. Open [ZeroMail bot zite](/16WKzsiU8QrYo2AghXEpMT6LaMQVofLmqC), then from ZeroHello, choose `3-dot menu` after the zite "Local ZeroMail Bot" and clone it. Again from ZeroHello choose the menu after your new "myLocal ZeroMail Bot" and check "Pause" (Because it's for local use ;).
2. On your new bot zite select an id you like and send a message, so your id folder is generated in your zite. Also hit the "Follow" button.
3. Download [ZeroMailBot.zip](/1EiMAqhd6sMjPG2tznkkGXxhdwFBDdeqT9/shared/ZeroMailBot.zip) from my blog, then unzip it to the root folder of your ZeroNet instance. Or clone and copy it from [my messy repo](/13zzNGxEXDeLxHEGZdG3mE7G8dChf45LrV/).
4. Finally start the bot with `$ python2 zeromail_bot.py`, follow the instruction and done! You can schedule the bot with `cron`, `systemd`, or with a simple command like `$ while sleep TIME_INTERVAL_IN_SECOND; do python2 zeromail_bot.py; done`.

## FAQ:

1. Is it possible that my mails leak to the public?

   It should be impossible, because I also tweaked `cert_signers` in `data/users/content.json` to `"zeroid.nobit": ["2iD5ZQJMNXu43w1qLB8sfdHVKppVMduGz"]`, so your content will be never published.


2. Can I send zeromail from the bot? If not, why did you bother creating a UI for the bot?

   No. Well.. because of personal interest. Also in some machine (like my Raspberry Pi 2), it can be very slow to open ZeroMail. So.. before your ZeroMail is initiated, you can read the mail on the bot zite.

## Credits:

Thank gitcenter for extracting the essential functions to `cryptlib.py` and many other things!
Thank bornfree for [the idea](/Talk.ZeroNetwork.bit/?Topic:1514602755_1GNuATGPPFyvKngtWmbDrpo2D7u2rGM36m/How+to+extract+ZeroMail+messages+directly) and some related code!

## Link:

[ZeroMailProxy](https://github.com/imachug/ZeroMailProxy) - IMAP/POP3 protocol for ZeroMail by gitcenter.
