#! /usr/bin/python2

import os, sys, subprocess, inspect, json, time, sqlite3

# Set working dir to ZeroNet
get_dir = os.path.dirname(os.path.abspath(inspect.stack()[0][1]))  # http://stackoverflow.com/questions/918154/relative-paths-in-python
app_dir = get_dir.replace("ZeroMailBot", "")
os.chdir(app_dir)
zeronet_directory = app_dir + "data/"

sys.path.insert(0, os.path.join(app_dir, "ZeroMailBot"))
sys.path.insert(0, os.path.join(app_dir, "plugins/CryptMessage"))
sys.path.insert(0, os.path.join(app_dir, "src/lib"))  # External liblary directory
sys.path.insert(0, os.path.join(app_dir, "src"))  # Imports relative to src

from cryptlib import *

def initGlobalName():  # http://stackoverflow.com/questions/1977362/how-to-create-module-wide-variables-in-python
    global SITE_ADDRESS, AUTH_ADDRESS, AUTH_KEY, DATA_JSON, \
            ENCRYPTED_PRIVATE_KEY, ENCRYPTED_PRIVATE_KEY

    if not os.path.isfile('ZeroMailBot/addr_info.json'):
        json_data = json.load(open('data/users.json'))
        for i in json_data:
            main_addr = i
            certs = json_data[i]['certs']
            break
        cert_list = {}
        cert_index = 1
        for i in certs:
            cert_list[cert_index] = i
            cert_index += 1
        cert_suggestion = ''
        for i in cert_list:
            cert_suggestion += str(i) + ' ' + cert_list[i] + '; '
        choose_cert = int(input("choose your cert (number): " + cert_suggestion))
        cert_provider = cert_list[choose_cert]


        addr_info = {'main_addr': main_addr,
                'cert_provider': cert_provider,
                'site_address': raw_input('Your bot site address: ')
                }
        json.dump(addr_info, open('ZeroMailBot/addr_info.json', "w"), indent=2)
    json_data = json.load(open('data/users.json'))
    addr_info = json.load(open('ZeroMailBot/addr_info.json'))
    SITE_ADDRESS = addr_info['site_address']
    cert = json_data[addr_info['main_addr']]['certs'][addr_info['cert_provider']]
    AUTH_ADDRESS = cert['auth_address']
    #AUTH_KEY = bytes(cert['auth_privatekey'], 'utf-8') ## Python3
    AUTH_KEY = cert['auth_privatekey']
    DATA_JSON = 'data/' + SITE_ADDRESS + '/data/users/' + AUTH_ADDRESS + '/data.json'

    sites = json_data[addr_info['main_addr']]['sites']
    ENCRYPTED_PUBLIC_KEY = ''
    zeromail_site = sites['1MaiL5gfBM1cyb4a8e3iiL8L5gXmoAJu27']
    for i in zeromail_site:
        if i[0:4] == 'encr':
            if i[8:11] == 'pri':
                ENCRYPTED_PRIVATE_KEY = zeromail_site[i]
            else:
                ENCRYPTED_PUBLIC_KEY = zeromail_site[i]
    if ENCRYPTED_PUBLIC_KEY == '': ## One of my account has no publickey in users.json, so also try to get it in data.json
        site_json_data=json.load(open(zeronet_directory + "1MaiL5gfBM1cyb4a8e3iiL8L5gXmoAJu27/data/users/" + \
                AUTH_ADDRESS + "/data.json"))
        ENCRYPTED_PUBLIC_KEY = site_json_data.get('publickey')

def decryptMail():
    conn = sqlite3.connect(zeronet_directory + '1MaiL5gfBM1cyb4a8e3iiL8L5gXmoAJu27/data/users/zeromail.db')
    c = conn.cursor()
    secrets = []

    if not os.path.isfile('ZeroMailBot/last_update_info.json'):
        last_update_info = {}
    else:
        last_update_info = json.load(open('ZeroMailBot/last_update_info.json'))

    for row in c.execute('SELECT encrypted, json_id FROM secret ORDER BY date_added DESC'):
        aes_key, json_id = eciesDecrypt(row[0], ENCRYPTED_PRIVATE_KEY), row[1]
        if aes_key != None:
            secrets.append([aes_key, json_id])

    decrypted_data = []

    for s in secrets:
        aes_key, json_id = s[0], s[1]
        messages = c.execute("""
            SELECT encrypted, date_added, keyvalue.value AS cert_user_id
            FROM message
            LEFT JOIN json USING (json_id)
            LEFT JOIN json AS json_content
			ON (json.directory = json_content.directory AND json_content.file_name = "content.json")
			LEFT JOIN keyvalue ON (keyvalue.json_id = json_content.json_id)
            WHERE message.json_id = ? ORDER BY date_added DESC
        """, (json_id,))
        count = 0
        for m in messages:
            message = m[0].split(',')
            date_added, cert_user_id = m[1], m[2]
            iv, encrypted_text = message[0], message[1]
            result = aesDecrypt(iv, encrypted_text, aes_key)
            if result != None:
                result_parsed = json.loads(result)
                result_parsed["date_sent"] = date_added
                result_parsed["from"] = cert_user_id
                if cert_user_id not in last_update_info or \
                        date_added > last_update_info[cert_user_id]:
                    if count == 0:
                        date_added_new = date_added
                        count = 1
                    decrypted_data.append(result_parsed)
                else:
                    break
        if 'date_added_new' in locals():
            last_update_info[cert_user_id] = date_added_new
            del(locals()['date_added_new'])

    json.dump(last_update_info, open('ZeroMailBot/last_update_info.json', "w"), indent=2)
    return decrypted_data

def botControl(decrypted_data):
    output_data = json.load(open(DATA_JSON))
    decrypted_data = sorted(decrypted_data, key=lambda entry: entry['date_sent'])

    for message in decrypted_data:
        output_data['message'] += [{
                    'body': message['body'],
                    'send_from': message['from'],
                    'send_to': message['to'],
                    'subject': message['subject'],
                    'date_sent': message['date_sent'],
                    'date_added': int(time.time()*1000)
                    }]
        time.sleep(1)  # Sleep one second to avoid same timestamp and message unable to display, also ZeroHello doesn't allow more than 1 feed in a second from the same zite.
    json.dump(output_data, open(DATA_JSON, "w"), indent=2)

    sign_command_path = SITE_ADDRESS + ' ' + '--inner_path' + ' ' + 'data/users/' + \
            AUTH_ADDRESS + '/content.json'

    # Sign and publish content
    siteSign = subprocess.Popen("python2 zeronet.py siteSign" + " " + sign_command_path,
            shell=True, stdin=subprocess.PIPE)  # http://stackoverflow.com/questions/163542/python-how-do-i-pass-a-string-into-subprocess-popen-using-the-stdin-argument
    siteSign.communicate(input=AUTH_KEY)[0] # From subprocess doc: Use communicate() rather than .stdin.write, .stdout.read or .stderr.read to avoid deadlocks due to any of the other OS pipe buffers filling up and blocking the child process.
    #sitesign.stdin.write(AUTH_KEY)  # https://stackoverflow.com/questions/16768290/understanding-popen-communicate
    #subprocess.Popen("python2 ../zeronet.py sitePublish" + " " + sign_command_path,
    #        shell=True).stdout

if __name__ == '__main__':
    initGlobalName()
    decrypted_data = decryptMail()
    botControl(decrypted_data)
