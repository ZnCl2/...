Still remember [my ZeroMe Feedbot](/1EiMAqhd6sMjPG2tznkkGXxhdwFBDdeqT9/?Post:22:ZeroMe+Feed+Bot), here is a rebranded feedbot for ZeroTalk :3
The installation will be a little easier because you don't need to create another ID.

![Bildschirmfoto_2017-06-28_11-40-14.png (0x0)](data/img/post_33_Bildschirmfoto_2017-06-28_11-40-14.png)

* * *

A python script that will turn a ZeroTalk clone into a RSS feed bot and more.

> RSS (Rich Site Summary; originally RDF Site Summary; often called Really Simple Syndication) uses a family of standard web feed formats to publish frequently updated information: blog entries, news headlines, audio, video. An RSS document (called "feed", "web feed", or "channel") includes full or summarized text, and metadata, like publishing date and author's name. [Src:Wiki](https://en.wikipedia.org/wiki/RSS)

[How to Subscribe to RSS Feeds](http://rss-tutorial.com/rss-how-to-subscribe-to-feeds.htm)

## How to Install:

1.  Clone a ZeroTalk, then login your ZeroTalk with your ID and create a random topic to generate your profile. Then you may like to edit `/path/to/your/zerotalk/data/users/content.json` and change the `max_size`, or your data.json will fail to sign if it reaches the limit. After changing the `max_size`, you need to sign (and publish) your ZeroTalk from the right config panel (drag the '0' button to left).

2.  Download [the script zip file](/1EiMAqhd6sMjPG2tznkkGXxhdwFBDdeqT9/shared/FeedBot-ZeroTalk.zip) and extract it directly to your ZeroNet root directory.

3.  Add your feeds:
    There are two way to add your feeds:
    One way is to directly copy your feed url to `rssAddresses.txt`, one url one line.
    The other way is by creating a topic with your bot ZeroTalk account. The title format is `add-feed YOUR_FEED_URL`. Your can also delete your feed with `del-feed URL`. That's cool, isn't it ;)
    Check [this article](/1EiMAqhd6sMjPG2tznkkGXxhdwFBDdeqT9/?Post:25:Directly+Parsing+Website+Content+to+Feedbot) if you want something like this :3
    ![Bildschirmfoto_2017-06-28_13-35-42.png (0x0)](data/img/post_33_Bildschirmfoto_2017-06-28_13-35-42.png)
    To use it you need to create a file named `htmlAddresses.txt` in the `FeedBot-ZeroTalk` folder instead.

4.  Run the script:
    Install package dependency `feedparser`:
    Clone the branch with timeout function (Check Bug and Troubleshooting below) and install it (Default is 30 seconds, check [this](https://github.com/kurtmckee/feedparser/pull/80)): `$ git clone https://github.com/JPFrancoia/feedparser && cd feedparser && python setup.py install --user`. Then simply run it with `$ python feedbot.py`.
    If you want to run it periodically, you can use `$ while sleep TIME_INTERVAL_IN_SECOND; do python feedbot.py; done`. If your system uses `systemd`, you can check [this](/1EiMAqhd6sMjPG2tznkkGXxhdwFBDdeqT9/?Post:24:ZeroNet+Systemd+Service+and+Timer).
    The script normally won't fetch anything if there are no new content. But some websites don't support `etag` and `last-modified header`, the script has to always fetch feeds from them, but still won't update anything.

5.  If you want to create a ZeroTalk group like [P2P news flow](/Talk.ZeroNetwork.bit/?Topics:1_1KbV1e1u6P6AsY8XNBydgtbtN8iSB5WMyG/P2P+news+flow), you can edit `/path/to/your/zerotalk/data/users/YOUR_AUTH_ADDRESS/data.json` and add `"type": "group",` to a topic you created, also copy the `topic_id`, uncomment `#'parent_topic_uri': 'TOPIC_ID' + '_' + AUTH_ADDRESS` in the feedbot.py and change `TOPIC_ID` respectively.

## Bugs and Troubleshooting:

### 1\. The script sometimes hangs up.

Official `feedparser` package [doesn't support timeout setting](https://github.com/kurtmckee/feedparser/pull/80), so you need to install it from another branch. How to:

1.  Uninstall the package if you've installed it: `$ pip uninstall feedparser`.
2.  Clone the branch with timeout function and install it (Default is 30 seconds, check [this](https://github.com/kurtmckee/feedparser/pull/80)): `$ git clone https://github.com/JPFrancoia/feedparser && cd feedparser && python setup.py install --user`

Note: There is another solution by using `requests` library instead [[1]](http://stackoverflow.com/questions/9772691/feedparser-with-timeout) [[2]](http://stackoverflow.com/questions/27621689/not-getting-a-304-response-even-after-adding-etag-header), I will check it later^TM if I have time.

## Todo^TM:

*   Remove posts with keyword
*   Set limit of post size
*   Any recommendation?

## License:

MIT