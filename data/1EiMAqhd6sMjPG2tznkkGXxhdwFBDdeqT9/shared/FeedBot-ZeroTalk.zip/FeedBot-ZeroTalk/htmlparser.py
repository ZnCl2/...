#! /usr/bin/env python

from bs4 import BeautifulSoup
#from html2text import html2text
import requests
import time
import os
import json

import feedbot

class HtmlParser(object):
    def __init__(self, addr, address_and_etag, entry_output):
        self.addr = addr
        self.address_and_etag = address_and_etag
        self.entry_output = entry_output
        self.no_marker_feeds = {}
        if os.path.isfile('no_marker_feeds.json'):
            self.no_marker_feeds = json.load(open('no_marker_feeds.json'))
        self.response = requests.get(addr, timeout=20.0)
        doc = self.response.text
        self.soup = BeautifulSoup(doc, 'html.parser')
        if self.soup.head != None:
            self.feed_title = self.soup.head.title.text
        else:
            self.feed_title = ''  # Temporary solution

    def Parser1(self, entries, entry_dict):
        addr = self.addr
        timestamp = int(time.time())
        title = entry_dict['title']
        if addr in self.no_marker_feeds:
            if title in self.no_marker_feeds[addr]:
                return self.entry_output, self.no_marker_feeds  # No new entry
            else:
                self.no_marker_feeds[addr].append(title)
        else:
            self.no_marker_feeds[addr] = [title]
        entry_dict['feed_title'] = self.feed_title
        entry_dict['feed_link'] = addr
        entry_dict['timestamp'] = timestamp
        self.entry_output += [entry_dict]

    def noNewEntry(self, entries):
        last_entry_date = 0
        no_new_entry = False
        date_and_etag = self.address_and_etag[self.addr]
        date_and_etag = date_and_etag.split(None, 1)  # Split to last_entry_date and etag
        if len(date_and_etag) == 2:
            last_entry_date = int(date_and_etag[0])
            etag = date_and_etag[1]
            etag_value = etag[4:]
            if etag[0:4] == 'lmod':  # last-modified
                if self.response.headers['Last-Modified'] == etag_value:
                    no_new_entry = True
            elif etag[0:4] == 'etag':
                if self.response.headers['Etag'] == etag_value:
                    no_new_entry = True
            else:  # etag[0:4] == 'elen', length of entries
                entries_length = str(len(str(entries)))
                if entries_length == etag_value:
                    no_new_entry = True
        return no_new_entry

    def getHtmlContent(self):
        addr = self.addr
        # Set specific entries for sites
        if addr == 'https://www.uni-konstanz.de/universitaet/aktuelles-und-medien/aktuelle-meldungen/aktuelles/':
            entries = self.soup.find_all('article')
        elif addr == 'https://manga-tube.me/series/one_piece':
            entries = self.soup.find('ul', class_='chapter-list').find_all('li')
        elif addr == 'https://nyaa.si':
            entries = self.soup.find('tbody').find_all('tr')
        # Only parsing last 5 entries or less
        if len(entries) > 5:
            entries = entries[0:5]
        if self.noNewEntry(entries):
            return self.entry_output, self.address_and_etag
        # Set specific entry_dict and last_entry_date for sites
        if addr == 'https://www.uni-konstanz.de/universitaet/aktuelles-und-medien/aktuelle-meldungen/aktuelles/':
            for entry in entries[::-1]:
                entry_dict = {'title': entry.a.get('title'),
                        'link': entry.a.get('href'),
                        'summary': entry.p.text,
                        'date': entry.time.text
                        }
                # Replace encode error
                for key in entry_dict:
                    if key == 'title' or key == 'summary':
                        entry_dict[key] = entry_dict[key].replace('\u00c3\u00bc', '\u00fc').\
                                replace('\u00c3\u00a4', '\u00e4').\
                                replace('\u00c3\u00b6', '\u00f6').\
                                replace('\u00c3\u0096', '\u00d6').\
                                replace('\u00c3\u009f', '\u00df').\
                                replace('\u00c3\u009c', '\u00dc').\
                                replace('\u00c3\u0084', '\u00c4')
                self.Parser1(entries, entry_dict)
            last_entry_date = int(time.time())
        elif addr == 'https://manga-tube.me/series/one_piece':
            for entry in entries[::-1]:
                entry_dict = {'title': entry.b.text,
                        'link': 'https:' + entry.a.find_next_sibling('a').get('href'),
                        'summary': '',
                        'date': entry.p.text
                        }
                self.Parser1(entries, entry_dict)
            last_entry_date = int(time.time())
        elif addr == 'https://nyaa.si':
            for entry in entries[::-1]:
                entry_dict = {'title': entry.find_all('a')[1].get('title'),
                        'link': "https://nyaa.si" + entry.find_all('a')[2].get('href'),
                        'summary': entry.find_all('a')[3].get('href'),
                        'date': entry.find_all('td')[-4].text
                        }
                self.Parser1(entries, entry_dict)
            last_entry_date = int(time.time())

        ## Renew address_and_etag
        if self.response.headers.get('Last-Modified') != None:
            self.address_and_etag[addr] = str(last_entry_date) + ' ' + 'lmod' + \
                    self.response.headers['Last-Modified']
        elif self.response.headers.get('Etag') != None:
            self.address_and_etag[addr] = str(last_entry_date) + ' ' + 'etag' + \
                    self.response.headers['Etag']
        else:  # etag[0:4] == 'elen'
            entries_length = str(len(str(entries)))
            self.address_and_etag[addr] = str(last_entry_date) + ' ' + 'elen' + entries_length
        # Renew no_marker_feeds.json
        json.dump(self.no_marker_feeds, open('no_marker_feeds.json', "w"), indent=2)

        return self.entry_output, self.address_and_etag

def htmlParser(entry_output, address_and_etag):
    for addr in address_and_etag:
        try:
            htmlparser = HtmlParser(addr, address_and_etag, entry_output)
            entry_output, address_and_etag = htmlparser.getHtmlContent()
        except Exception as error:
            print('Error when parsing', addr, error)
            pass
    ## Renew htmlAddresses.txt
    with open("htmlAddresses.txt", "a") as file:
        for addr in address_and_etag:
            file.write(addr + ' ' + address_and_etag[addr] + '\n')
    return entry_output

if __name__ == '__main__':
    feedbot.initGlobalName()
    bot_data = json.loads(open(DATA_JSON).read().replace("\\u0000", ""))
    address_and_etag = feedbot.getAddressAndEtag(bot_data, 'htmlAddresses.txt')
    entry_output = []
    entry_output = htmlParser(entry_output, address_and_etag)
    json.dump(entry_output, open('test_htmlparser.json', "w"), indent=2)
