#! /usr/bin/env python

# Check http://127.0.0.1:43110/1EiMAqhd6sMjPG2tznkkGXxhdwFBDdeqT9/?Post:22:ZeroMe+Feed+Bot for details

import feedparser
from html2text import html2text

import os
import subprocess
import inspect
from datetime import datetime
import time
import json

try:
    import htmlparser
except:
    pass

def initGlobalName():  # http://stackoverflow.com/questions/1977362/how-to-create-module-wide-variables-in-python
    global SITE_ADDRESS, AUTH_ADDRESS, AUTH_KEY, \
            HOUR_MAX_ENTRIES, SIGN_COMMAND_PATH, DATA_JSON, OFFSET
    # Set working dir to ZeroNet/Feedbot
    getdir = os.path.dirname(os.path.abspath(inspect.stack()[0][1]))  # http://stackoverflow.com/questions/918154/relative-paths-in-python
    os.chdir(getdir)

    if not os.path.isfile('addr_info.json'):
        json_data = json.load(open('../data/users.json'))
        for i in json_data:
            main_addr = i
            certs = json_data[i]['certs']
            break
        cert_list = {}
        cert_index = 1
        for i in certs:
            cert_list[cert_index] = i
            cert_index += 1
        cert_suggestion = ''
        for i in cert_list:
            cert_suggestion += str(i) + ' ' + cert_list[i] + '; '
        choose_cert = int(input("choose your cert: " + cert_suggestion))
        addr_info = {'main_addr': main_addr,
                'cert_provider': cert_list[choose_cert],
                'site_address': input('Your bot site address: ')}
        json.dump(addr_info, open('addr_info.json', "w"), indent=2)
    json_data = json.load(open('../data/users.json'))
    addr_info = json.loads(open('addr_info.json').read().replace("\\u0000", ""))
    SITE_ADDRESS = addr_info['site_address']
    cert = json_data[addr_info['main_addr']]['certs'][addr_info['cert_provider']]
    AUTH_ADDRESS = cert['auth_address']
    AUTH_KEY = bytes(cert['auth_privatekey'], 'utf-8')
    HOUR_MAX_ENTRIES = 10
    SIGN_COMMAND_PATH = SITE_ADDRESS + ' ' + '--inner_path' + ' ' + 'data/users/' + \
            AUTH_ADDRESS + '/content.json'
    DATA_JSON = '../data/' + SITE_ADDRESS + '/data/users/' + AUTH_ADDRESS + '/data.json'
    # Timezone offset
    if time.localtime().tm_isdst and time.daylight:  # https://blogs.gnome.org/jamesh/2006/12/31/python-timetimezone-timealtzone-edge-case/
        OFFSET = -time.altzone
    else:
        OFFSET = -time.timezone

# Update rssAddresses if there are new ones in last posts,
# Then store address and etag/header to dict.
def getAddressAndEtag(bot_data, file_name):
    address_and_etag = {}
    address_and_etag_rest = []
    counter = 0
    with open(file_name) as file:
        for line in file:
            if counter < 50:  # parse only 50 feeds every time
                line = line.split(None, 1)
                if len(line) == 2:
                    address_and_etag[line[0]] = line[1].rstrip() # remove trailing whitespace
                elif len(line) == 1:  # avoid empty line
                    address_and_etag[line[0]] = ''
                counter += 1
            else:
                address_and_etag_rest += [line]

    for item in bot_data['topic'][::-1]:
        item_body = item['title'].split()
        if len(item_body) != 2:
            break
        if item_body[0] == 'add-feed':
            address_and_etag[item_body[1]] = ''
        elif item_body[0] == 'del-feed':
            if item_body[1] in address_and_etag:
                del(address_and_etag[item_body[1]])
            else:
                for line in address_and_etag_rest:
                    if item_body[1] == line.split()[0]:
                        address_and_etag_rest.remove(line)
                        break
        else:
            break

    with open(file_name, 'w') as file:
        for line in address_and_etag_rest:
            file.write(line)

    return address_and_etag

def getRssfeeds(addr, address_and_etag):
    last_entry_date = 0
    date_and_etag = address_and_etag[addr]
    date_and_etag = date_and_etag.split(None, 1)  # Split to last_entry_date and etag
    if len(date_and_etag) == 2:
        last_entry_date = int(date_and_etag[0])
        etag = date_and_etag[1]
        if etag[0:4] == 'lmod':  # last-modified
            rssfeeds = feedparser.parse(addr, modified = etag[4:])
        elif etag[0:4] == 'etag':
            rssfeeds = feedparser.parse(addr, etag = etag[4:])
        else:  # etag[0:4] == 'elen', length of entries
            rssfeeds = feedparser.parse(addr)
            entries_length = str(len(str(rssfeeds.entries)))
            if entries_length == etag[4:]:
                rssfeeds = feedparser.parse('')
    else:  # date_and_etag == []
        rssfeeds = feedparser.parse(addr)
        if len(date_and_etag) == 1:  # support backwards older version
            last_entry_date = int(date_and_etag[0])
    return rssfeeds, last_entry_date

def parseEntry(entry, addr, rssfeeds, timestamp, feed_output):
    if entry.get('summary') != None:
        entry_summary = html2text(entry.summary)
        if len(entry_summary) > 300:
            entry_summary = entry_summary[0:300] + '...'
        entry_summary = entry_summary.replace('![', ' [IMG ')  # Change Image to url
        entry_summary = entry_summary.replace('-\n', '-').\
                replace(')', ') ').\
                replace('\n\n', '\t\t').\
                replace('\n', ' ').\
                replace('\t\t', '\n\n')  # Solve some link parsing issues.
    else:
        entry_summary = ''

    entry_title = entry.title
    feed_title = rssfeeds.feed.title
    if feed_title == '':
        if rssfeeds.feed.get('subtitle') != None:
            feed_title = rssfeeds.feed.subtitle
        elif rssfeeds.feed.get('rights') != None:
            feed_title = rssfeeds.feed.rights
    if entry.get('published') != None:
        entry_date = entry.published
    elif entry.get('updated') != None:
        entry_date = entry.updated
    else:
        entry_date = ''
    feed_output += [{'timestamp': timestamp,
            'summary': entry_summary,
            'title': entry_title,
            'link': entry.link,
            'date': entry_date,
            'feed_title': feed_title,
            'feed_link': addr
            }]
    if addr == 'https://planet.archlinux.de/rss20.xml':  # Replace encode error
        for key in feed_output[-1]:
            if key == 'summary' or key == 'title':
                feed_output[-1][key] = feed_output[-1][key].\
                        replace('\u0102\u017a', '\u00fc').\
                        replace('\u0102\u00a4', '\u00e4').\
                        replace('\u0102\u015b', '\u00f6').\
                        replace('\u0102\u0178', '\u00df')
    elif addr == 'https://discourse.diasporafoundation.org/latest.rss':  # Parsed Text is too ugly
        feed_output[-1]['summary'] = ''
    return feed_output

# Fetch Feeds and Renew rssAddresses.txt
def getFeedAndRenewAddr(address_and_etag):
    feed_output = []
    no_marker_feeds = {}
    if os.path.isfile('no_marker_feeds.json'):
        no_marker_feeds = json.loads(open('no_marker_feeds.json').read().replace("\\u0000", ""))
    for addr in address_and_etag:
        try:
            rssfeeds, last_entry_date = getRssfeeds(addr, address_and_etag)
            timestamp_list = []
            # Only fetch last n entries or less
            if len(rssfeeds.entries) > HOUR_MAX_ENTRIES:
                rssfeeds_entries = rssfeeds.entries[0:HOUR_MAX_ENTRIES]
            else:
                rssfeeds_entries = rssfeeds.entries
            for entry in rssfeeds_entries:
                if entry.get('published_parsed') != None:
                    timestamp = int(time.mktime(entry.published_parsed)) + OFFSET
                elif entry.get('updated_parsed') != None:
                    timestamp = int(time.mktime(entry.updated_parsed)) + OFFSET
                elif rssfeeds.get('modified') != None or rssfeeds.get('etag') != None:
                    timestamp = int(time.time())
                else:  # Use title of the feed to check if it's new or old.
                    if addr in no_marker_feeds:
                        if entry.title in no_marker_feeds[addr]:
                            timestamp = 0
                        else:
                            no_marker_feeds[addr].append(entry.title)
                            if len(no_marker_feeds[addr]) > HOUR_MAX_ENTRIES:
                                no_marker_feeds[addr] = no_marker_feeds[addr][-HOUR_MAX_ENTRIES:]
                            timestamp = int(time.time())
                    else:
                        no_marker_feeds[addr] = [entry.title]
                        timestamp = int(time.time())
                if timestamp > last_entry_date and timestamp < time.time() + 1:  # Avoid entry with future timestamp...
                    timestamp_list.append(timestamp)
                    feed_output = parseEntry(entry, addr, rssfeeds, timestamp, feed_output)

            if timestamp_list != []:
                last_entry_date = max(timestamp_list)

                # Update last_entry_date and etag
                if rssfeeds.get('modified') != None:
                    address_and_etag[addr] = str(last_entry_date) + ' ' + 'lmod' + rssfeeds.modified
                elif rssfeeds.get('etag') != None:  # Etag ended with "gzip" failed to work.
                    address_and_etag[addr] = str(last_entry_date) + ' ' + 'etag' + rssfeeds.etag
                else:  # etag[0:4] == 'elen'
                    entries_length = str(len(str(rssfeeds.entries)))
                    address_and_etag[addr] = str(last_entry_date) + ' ' + 'elen' + entries_length
        except Exception as error:
            print('Error when parsing', addr, error)
            pass

    # Renew rssAddresses.txt
    #os.rename('rssAddresses.txt','rssAddresses.txt.backup')  # backup rssAddresses.txt
    with open("rssAddresses.txt", "a") as file:
        for addr in address_and_etag:
            file.write(addr + ' ' + address_and_etag[addr] + '\n')
    # Renew no_marker_feeds.json
    json.dump(no_marker_feeds, open('no_marker_feeds.json', "w"), indent=2)

    return feed_output

def startFeedbot():
    bot_data = json.loads(open(DATA_JSON).read().replace("\\u0000", ""))
    address_and_etag = getAddressAndEtag(bot_data, 'rssAddresses.txt')
    feed_output = getFeedAndRenewAddr(address_and_etag)
    if os.path.isfile('htmlAddresses.txt'):
        address_and_etag = getAddressAndEtag(bot_data, 'htmlAddresses.txt')
        feed_output = htmlparser.htmlParser(feed_output, address_and_etag)
    if feed_output != []:
        feed_output = sorted(feed_output, key=lambda entry: entry['timestamp'])

        # Renew data.json
        for entry in feed_output:
            bot_data['topic'] += [{
                    'topic_id': len(bot_data['topic']) + 1,
                    'title': entry['title'],
                    'body': entry['summary'] + '\n\n' + entry['link'] + \
                            '\n\n-- [' + entry['feed_title'] + '](' + \
                            entry['feed_link'] + ')' + ' ' + entry['date'],
                    #'parent_topic_uri': 'TOPIC_ID' + '_' + AUTH_ADDRESS,
                    'added': int(time.time())
                    }]
        bot_data['next_topic_id'] = len(bot_data['topic']) + 1
        json.dump(bot_data, open(DATA_JSON, "w"), indent=2)

        # Sign and publish content
        sitesign = subprocess.Popen("python2 ../zeronet.py siteSign" + " " + SIGN_COMMAND_PATH,
                shell=True, stdin=subprocess.PIPE)  # http://stackoverflow.com/questions/163542/python-how-do-i-pass-a-string-into-subprocess-popen-using-the-stdin-argument
        #sitesign.communicate(input=AUTH_KEY)
        sitesign.stdin.write(AUTH_KEY)  # https://stackoverflow.com/questions/16768290/understanding-popen-communicate
        subprocess.Popen("python2 ../zeronet.py sitePublish" + " " + SIGN_COMMAND_PATH,
                shell=True).stdout
    else:
        print("No new Feed.", str(datetime.now()))


if __name__ == '__main__':
    initGlobalName()
    startFeedbot()
