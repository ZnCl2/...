<script>
var DMap = new Map();
</script>
