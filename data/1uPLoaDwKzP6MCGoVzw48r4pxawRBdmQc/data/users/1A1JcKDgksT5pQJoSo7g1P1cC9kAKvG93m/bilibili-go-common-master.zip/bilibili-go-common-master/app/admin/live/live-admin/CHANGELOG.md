### v2.4.0
1. 接入 UploadServcie & TokenService 提供运营平台上传图片接口

### v2.3.0
1. 接入 roomService，聚合二审后台图片接口

### v2.2.0
1. 接入 user Resource

### v2.0.2
1.增加直播配置中心逻辑
2.fix new client

### V2.0.1
1. 升级 bmgen

### v2.0.0

1. 从 `interface/live/live-admin` 迁移至 `admin/live/live-admin`
2. 重构 resourceService
3. 直播前端接管项目

### v2.0.1
1. 付费直播后台