#V 0.0.3
import xbmc , xbmcaddon , xbmcgui , xbmcplugin , requests , urllib , urllib2 , json , os , re , sys , datetime , urlresolver , random , liveresolver , base64
from resources . lib . common_addon import Addon
from HTMLParser import HTMLParser
from metahandler import metahandlers
import requests
import downloader as Get_Files
import extract
import time
if 64 - 64: i11iIiiIii
if 65 - 65: Vev / iIii1I11I1II1 % VeeeeeeeVV - i1IIi
if 73 - 73: II111iiii
IiII1IiiIiI1 = 'script.module.xhamster'
iIiiiI1IiI1I1 = Addon ( IiII1IiiIiI1 , sys . argv )
eevVeVeVVevev = xbmcaddon . Addon ( id = IiII1IiiIiI1 )
I11i = xbmcaddon . Addon ( ) . getAddonInfo
VevV = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + IiII1IiiIiI1 , 'fanart.jpg' ) )
Ve = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + IiII1IiiIiI1 , 'fanart.jpg' ) )
I1ii11iIi11i = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + IiII1IiiIiI1 , 'icon.png' ) )
I1IiI = base64 . b64decode ( 'aHR0cHM6Ly94aGFtc3Rlci5jb20v' )
eevVVV = base64 . b64decode ( 'aHR0cHM6Ly93d3cuZXBvcm5lci5jb20v' )
iIiiiI = base64 . b64decode ( 'aHR0cHM6Ly93d3cucG9ybi5jb20vY2F0ZWdvcmllcw==' )
Iii1ii1II11i = base64 . b64decode ( 'aHR0cHM6Ly93d3cuZW1wZmxpeC5jb20vY2F0ZWdvcmllcw==' )
iI111iI = base64 . b64decode ( 'aHR0cDovL3d3dy5zZXhkcmF3LmNvbS90YWdz' )
IiII = base64 . b64decode ( 'aHR0cDovL3d3dy53aGVyZXNteWdmLmNvbQ==' )
iI1Ii11111iIi = base64 . b64decode ( 'aHR0cDovL3d3dy5mYXB0di5jb20vdGFncw==' )
i1i1II = base64 . b64decode ( 'aHR0cHM6Ly93d3cuZXJveGlhLmNvbS9jYXQv' )
VeveeevVVev = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
I1i1iiI1 = requests . session ( )
iiIIIII1i1iI = xbmc . translatePath ( 'special://home/userdata/addon_data/' + IiII1IiiIiI1 )
eeveVev = 'Tissues Time'
eeevev = xbmcgui . Dialog ( )
eevev = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'repository.stefanorepository' ) )
VeeveVeveee = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + IiII1IiiIiI1 + '/resources/art' , 'hamster.png' ) )
eeveVeVeveve = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + IiII1IiiIiI1 + '/resources/art' , 'empflix.png' ) )
i1 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + IiII1IiiIiI1 + '/resources/art' , 'eporner.png' ) )
eVVeeevevVevV = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + IiII1IiiIiI1 + '/resources/art' , 'fap.png' ) )
i1111 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + IiII1IiiIiI1 + '/resources/art' , 'porn.png' ) )
i11 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + IiII1IiiIiI1 + '/resources/art' , 'sexdraw.png' ) )
I11 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + IiII1IiiIiI1 + '/resources/art' , 'wheresgf.png' ) )
Veeveeveveveveeveev = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + IiII1IiiIiI1 + '/resources/art' , 'search.png' ) )
eVeeveeeeeveve = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + IiII1IiiIiI1 + '/resources/art' , 'next.png' ) )
if 65 - 65: Veve * i1iIIII * I1
if 54 - 54: eV % IiiIIiiI11 / eeeVVVVV * IiiIII111ii / i1iIIi1
if 50 - 50: IiIi1Iii1I1 - VevevVevVevVev
if 75 - 75: IIIiiiiiIii / eVVeVev % VevVeVevevevVevVV
if 23 - 23: iIiIiIiIIi + IiiIII111ii
if not os . path . exists ( eevev ) :
 iI = xbmcgui . Dialog ( ) . yesno ( eeveVev , 'This Add-on requires [COLOR cyan]Multixxx[/COLOR] to be installed to work correctly would you like to install it now?' , '' , yeslabel = '[B][COLOR white]YES[/COLOR][/B]' , nolabel = '[B][COLOR grey]NO[/COLOR][/B]' )
 if iI == 1 :
  iI11iiiI1II = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'packages' ) )
  if not os . path . exists ( iI11iiiI1II ) :
   os . makedirs ( iI11iiiI1II )
  VeveeeeevVeevev = base64 . b64decode ( b'aHR0cDovL3N0ZWZhbm9hZGRvbi5pbmZvL3ppcC9zY3JpcHQubW9kdWxlLm11bHRpeHh4L3NjcmlwdC5tb2R1bGUubXVsdGl4eHgtMS4wLjAuemlw' )
  Ii11iii11I = xbmcgui . DialogProgress ( )
  Ii11iii11I . create ( eeveVev , "" , "" , "Downloading [COLOR cyan]Multixxx[/COLOR]" )
  eVeevevVeevevV = os . path . join ( iI11iiiI1II , 'repo.zip' )
  if 43 - 43: Veve - IIIiiiiiIii * iIii1I11I1II1
  try :
   os . remove ( eVeevevVeevevV )
  except :
   pass
   if 97 - 97: IiIi1Iii1I1 % IiIi1Iii1I1 + II111iiii * IIIiiiiiIii
  Get_Files . download ( VeveeeeevVeevev , eVeevevVeevevV , Ii11iii11I )
  eeveeveveev = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) )
  time . sleep ( 2 )
  Ii11iii11I . update ( 0 , "" , "Installing [COLOR red]Multixxx[/COLOR] Please Wait" , "" )
  extract . all ( eVeevevVeevevV , eeveeveveev , Ii11iii11I )
  xbmc . executebuiltin ( "UpdateAddonRepos" )
  xbmc . executebuiltin ( "UpdateLocalAddons" )
  if 25 - 25: i1iIIII - eVVeVev . VeeeeeeeVV
  if 22 - 22: eVVeVev + II111iiii % VevVeVevevevVevVV . IiIi1Iii1I1 . eV
  if 76 - 76: eV - Vev % i1iIIi1 / eeeVVVVV / eV
def eeeveeeeeVev ( ) :
 i11Iiii ( '[B][COLOR gold]XHAMSTER.COM[/COLOR][/B]' , 'url' , 1 , VeeveVeveee , VevV , '' )
 #i11Iiii ( '[B][COLOR gold]EPORNER.COM[/COLOR][/B]' , 'url' , 2 , i1 , VevV , '' )
 #i11Iiii ( '[B][COLOR gold]PORN.COM[/COLOR][/B]' , 'url' , 3 , i1111 , VevV , '' )
 #i11Iiii ( '[B][COLOR gold]EMPFLIX.COM[/COLOR][/B]' , 'url' , 4 , eeveVeVeveve , VevV , '' )
 #i11Iiii ( '[B][COLOR gold]FAPTV.COM[/COLOR][/B]' , 'url' , 7 , eVVeeevevVevV , VevV , '' )
 #i11Iiii ( '[B][COLOR gold]WHERESMYGF.COM[/COLOR][/B]' , 'url' , 6 , I11 , VevV , '' )
 #i11Iiii ( '[B][COLOR gold]SEXDRAW.COM[/COLOR][/B]' , 'url' , 5 , i11 , VevV , '' )
 if 23 - 23: IiiIIiiI11 . II111iiii
 if 98 - 98: iIii1I11I1II1 % eV * eeeVVVVV * eV
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 45 - 45: VevVeVevevevVevVV . eV
 if 83 - 83: IiiIII111ii . iIii1I11I1II1 . eeeVVVVV
def I1I ( ) :
 i11Iiii ( '[B][COLOR gold]Categories[/COLOR][/B]' , I1IiI + 'categories' , 39 , VeeveVeveee , VevV , '' )
 i11Iiii ( '[B][COLOR gold]Categories A-Z[/COLOR][/B]' , I1IiI + 'categories' , 38 , VeeveVeveee , VevV , '' )
 i11Iiii ( '[B][COLOR gold]Porn Stars A-Z[/COLOR][/B]' , I1IiI + 'pornstars' , 43 , VeeveVeveee , VevV , '' )
 i11Iiii ( '[B][COLOR gold]Best[/COLOR][/B]' , I1IiI + 'best/weekly' , 37 , VeeveVeveee , VevV , '' )
 i11Iiii ( '[B][COLOR gold]Channels A-Z[/COLOR][/B]' , I1IiI + 'channels' , 44 , VeeveVeveee , VevV , '' )
 i11Iiii ( '[B][COLOR gold]Top Rated[/COLOR][/B]' , I1IiI + 'best/weekly' , 37 , VeeveVeveee , VevV , '' )
 i11Iiii ( '[B][COLOR gold]Top Viewed[/COLOR][/B]' , I1IiI + 'most-viewed' , 37 , VeeveVeveee , VevV , '' )
 i11Iiii ( '[B][COLOR gold]HD[/COLOR][/B]' , I1IiI + 'hd' , 37 , VeeveVeveee , VevV , '' )
 i11Iiii ( '[B][COLOR gold]Most Commented[/COLOR][/B]' , I1IiI + 'most-commented/weekly' , 37 , VeeveVeveee , VevV , '' )
 i11Iiii ( '[B][COLOR gold]Most Viewed Of 2017[/COLOR][/B]' , I1IiI + 'most-viewed/year-2017' , 37 , VeeveVeveee , VevV , '' )
 i11Iiii ( '[B][COLOR gold]Search[/COLOR][/B]' , 'url' , 40 , Veeveeveveveveeveev , VevV , '' )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 80 - 80: eV - I1
def VVVevev ( url ) :
 if 21 - 21: VeeeeeeeVV - VeeeeeeeVV
 if 'xhamster.com' in url :
  url = url . replace ( 'https://xhamster.com' , '' )
 else :
  url = url
 iIii11I = VVVevVVVevevee ( I1IiI + url )
 Iii111II = '<a class="video-thumb__image-container thumb-image-container" href="https:\/\/xhamster\.com(.*?)" data-sprite="(.*?)" data-previewvideo="(.*?)">'
 if 9 - 9: I1
 i11VeveeevVVeveVVVe = re . findall ( Iii111II , iIii11I , re . DOTALL )
 if 35 - 35: eVVeVev % Veve
 for eevVVeeevVVevVVV in i11VeveeevVVeveVVVe :
  iI1iI1I1i1I = eevVVeeevVVevVVV [ 0 ] . replace ( '-' , ' ' ) . replace ( '/videos/' , '' )
  url = eevVVeeevVVevVVV [ 0 ]
  I1ii11iIi11i = eevVVeeevVVevVVV [ 1 ] . replace ( 's_' , '2_' )
  iIi11Ii1 ( '[B][COLOR gold]' + iI1iI1I1i1I + '[/COLOR][/B]' , url , 41 , I1ii11iIi11i , VevV , '' )
  if 50 - 50: II111iiii - iIiIiIiIIi * eeeVVVVV / VevVeVevevevVevVV + IiiIIiiI11
 VevVevV = re . compile ( '<link rel="next" href="(.+?)"' , re . DOTALL ) . findall ( iIii11I )
 if 83 - 83: eeeVVVVV / iIiIiIiIIi
 for url in VevVevV :
  iIi11Ii1 ( '[B][COLOR white]Next Page>>>[/COLOR][/B]' , url , 37 , eVeeveeeeeveve , VevV , '' )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 49 - 49: IiiIIiiI11
def IIii1Ii1 ( url ) :
 if 5 - 5: IIIiiiiiIii % i1iIIi1 + iIiIiIiIIi % i11iIiiIii + IiiIIiiI11
 iIii11I = VVVevVVVevevee ( url )
 VVVVevVVeVevVev = re . findall ( '<div class="item">\s+<a href="https://xhamster.com/pornstars/(.*?)" >(.*?)</a>\s+</div>' , iIii11I , re . DOTALL )
 if 65 - 65: eVVeVev * Veve + VevevVevVevVev % i11iIiiIii * IiiIII111ii . VevVeVevevevVevVV
 for VeVevVevev in VVVVevVVeVevVev :
  if 5 - 5: i1iIIII / IiiIIiiI11 . VevevVevVevVev - Vev / eVVeVev
  eeVeeeeveveveVV = VeVevVevev [ 1 ]
  VeeveVVe = '/pornstars/' + VeVevVevev [ 0 ]
  iIi11Ii1 ( '[B][COLOR gold]' + eeVeeeeveveveVV + '[/COLOR][/B]' , VeeveVVe , 37 , VeeveVeveee , VevV , '' )
  if 58 - 58: II111iiii * i1iIIi1 * eeeVVVVV / i1iIIi1
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 75 - 75: IiiIII111ii
def I1III ( url ) :
 if 63 - 63: i1iIIi1 % IiiIII111ii * IiiIII111ii * I1 / eeeVVVVV
 iIii11I = VVVevVVVevevee ( url )
 VVVVevVVeVevVev = re . findall ( '<div class="item">\s+<a href="https://xhamster.com/channels/(.*?)" >(.*?)</a>\s+</div>' , iIii11I , re . DOTALL )
 if 74 - 74: II111iiii
 for VeVevVevev in VVVVevVVeVevVev :
  if 75 - 75: IiiIIiiI11 . iIiIiIiIIi
  eeVeeeeveveveVV = VeVevVevev [ 1 ]
  VeeveVVe = '/channels/' + VeVevVevev [ 0 ]
  iIi11Ii1 ( '[B][COLOR gold]' + eeVeeeeveveveVV + '[/COLOR][/B]' , VeeveVVe , 37 , VeeveVeveee , VevV , '' )
  if 54 - 54: II111iiii % eV % IiIi1Iii1I1 % iIii1I11I1II1 + iIii1I11I1II1 * iIiIiIiIIi
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 87 - 87: iIiIiIiIIi * i1iIIII % i11iIiiIii % eV - i1iIIi1
def VeveeeevVeveeev ( url ) :
 if 91 - 91: iIii1I11I1II1 + VevVeVevevevVevVV
 iIii11I = VVVevVVVevevee ( url )
 VVVVevVVeVevVev = re . findall ( '<div class="item">\s+<a href="https://xhamster.com/tags/(.*?)" >(.*?)</a>\s+</div>' , iIii11I , re . DOTALL )
 if 31 - 31: eVVeVev . eV . i1iIIi1
 for VeVevVevev in VVVVevVVeVevVev :
  if 75 - 75: IiIi1Iii1I1 + I1 . eV . iIiIiIiIIi + i1iIIII . I1
  eeVeeeeveveveVV = VeVevVevev [ 1 ]
  VeeveVVe = '/tags/' + VeVevVevev [ 0 ]
  iIi11Ii1 ( '[B][COLOR gold]' + eeVeeeeveveveVV + '[/COLOR][/B]' , VeeveVVe , 37 , VeeveVeveee , VevV , '' )
  if 96 - 96: i1iIIi1 . iIiIiIiIIi - i1iIIII + iIii1I11I1II1 / eV * i1iIIi1
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 65 - 65: VevevVevVevVev . iIii1I11I1II1 / Vev - VevevVevVevVev
def iii1i1iiiiIi ( url ) :
 if 2 - 2: Veve / Vev / IiiIIiiI11 % eV % VevevVevVevVev
 iIii11I = VVVevVVVevevee ( url )
 VVVVevVVeVevVev = re . findall ( '<a href="https://xhamster.com/categories-(.*?)" class="view-all">' , iIii11I , re . DOTALL )
 if 52 - 52: IiiIIiiI11
 for VeVevVevev in VVVVevVVeVevVev :
  if 95 - 95: VevevVevVevVev
  eeVeeeeveveveVV = VeVevVevev [ 0 ]
  VeeveVVe = I1IiI + '/categories-' + VeVevVevev [ 0 ]
  iIi11Ii1 ( '[B][COLOR gold]' + eeVeeeeveveveVV + '[/COLOR][/B]' , VeeveVVe , 39 , VeeveVeveee , VevV , '' )
  if 87 - 87: iIiIiIiIIi + eV . i1iIIi1 + eV
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 91 - 91: Vev
def eVVeev ( url ) :
 iIii11I = VVVevVVVevevee ( url )
 Iii111II = re . compile ( '<div class="letter-categories">(.+?)</ul>' , re . DOTALL ) . findall ( iIii11I )
 eeevevVeveveV = re . compile ( 'href="(.+?)"><span >(.+?)<' , re . DOTALL ) . findall ( str ( Iii111II ) )
 for url , iI1iI1I1i1I in eeevevVeveveV :
  iIi11Ii1 ( '[B][COLOR gold]%s[/COLOR][/B]' % iI1iI1I1i1I , url , 37 , VeeveVeveee , VevV , '' )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 23 - 23: I1 + I1 . i1iIIi1
def ii1ii11IIIiiI ( ) :
 VevevVVVeVeeevV = xbmc . Keyboard ( '' , 'Search For Your Porn!' )
 VevevVVVeVeeevV . doModal ( )
 if ( VevevVVVeVeeevV . isConfirmed ( ) ) :
  VevevevVVeevevee = VevevVVVeVeeevV . getText ( ) . replace ( ' ' , '+' )
  VeveeeeevVeevev = I1IiI + 'search.php?from=&q=' + VevevevVVeevevee + '&qcat=video'
  VVVevev ( VeveeeeevVeevev )
  if 71 - 71: i11iIiiIii + eVVeVev
def VVVevVVVevevee ( url ) :
 eVe = { }
 eVe [ 'User-Agent' ] = VeveeevVVev
 eVVevevVe = I1i1iiI1 . get ( url , headers = eVe ) . text
 eVVevevVe = eVVevevVe . encode ( 'ascii' , 'ignore' )
 return eVVevevVe
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 6 - 6: IiiIII111ii
def eVVeeveVeev ( url ) :
 eeevev = xbmcgui . Dialog ( )
 if not 'https' in url :
  url = 'https://xhamster.com' + url
 II = [ ]
 eeeee = [ ]
 if 1 - 1: i1iIIII / IiiIIiiI11 % IIIiiiiiIii * eVVeVev . i11iIiiIii
 III1Iiii1I11 = ''
 if 9 - 9: eeeVVVVV / i1iIIII - Veve / VeeeeeeeVV / iIii1I11I1II1 - IiiIIiiI11
 iIii11I = VVVevVVVevevee ( url )
 if 91 - 91: IIIiiiiiIii % i1IIi % iIii1I11I1II1
 IIi1I11I1II = re . findall ( '"(\d+)p":"(.*?)"' , iIii11I , re . DOTALL )
 if 63 - 63: VeeeeeeeVV - I1 . II111iiii / IiiIIiiI11 . eV / Vev
 for eevVVVVevevVevVe in IIi1I11I1II :
  if 48 - 48: Vev
  eVVevevVe = eevVVVVevevVevVe [ 1 ] . replace ( '\\' , '' )
  if 11 - 11: IiIi1Iii1I1 + VeeeeeeeVV - I1 / IiiIIiiI11 + i1iIIII . II111iiii
  if '.flv' in eevVVVVevevVevVe [ 1 ] :
   III1Iiii1I11 = '[B][COLOR gold]FLV : ' + eevVVVVevevVevVe [ 0 ] + '[/COLOR][/B]'
  elif '.mp4' in eevVVVVevevVevVe [ 1 ] :
   III1Iiii1I11 = '[B][COLOR gold]MP4 : ' + eevVVVVevevVevVe [ 0 ] + '[/COLOR][/B]'
   if 41 - 41: VevevVevVevVev - Vev - Vev
  II . append ( III1Iiii1I11 )
  eeeee . append ( eVVevevVe )
  if 68 - 68: i1iIIi1 % VevVeVevevevVevVV
 if len ( II ) > 1 :
  eeevev = xbmcgui . Dialog ( )
  eeVevevVVev = eeevev . select ( 'Please Select Quality' , II )
  if 31 - 31: IIIiiiiiIii % IIIiiiiiIii % IiIi1Iii1I1
  if eeVevevVVev == - 1 :
   return
  elif eeVevevVVev > - 1 :
   url = eeeee [ eeVevevVVev ]
   if 69 - 69: I1 - i1iIIII + i1IIi / VevVeVevevevVevVV
 ii1 = xbmcgui . ListItem ( iI1iI1I1i1I , iconImage = 'DefaultVideo.png' , thumbnailImage = I1iI1iIi111i )
 ii1 . setInfo ( type = 'Video' , infoLabels = { "Title" : iI1iI1I1i1I } )
 ii1 . setProperty ( "IsPlayable" , "true" )
 ii1 . setPath ( url )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ii1 )
 if 44 - 44: i1IIi % II111iiii + IiIi1Iii1I1
 if 45 - 45: IIIiiiiiIii / IIIiiiiiIii + VevVeVevevevVevVV + iIiIiIiIIi
 if 47 - 47: IiiIIiiI11 + iIiIiIiIIi
def VeV ( ) :
 VeveeeeevVeevev = ( eevVVV )
 eVVevevVe = VVVevVVVevevee ( VeveeeeevVeevev )
 Vevev = re . compile ( '<li class="">(.+?)</li>' ) . findall ( eVVevevVe )
 i11Iiii ( '[B][COLOR gold]SEARCH[/COLOR][/B]' , VeveeeeevVeevev , 57 , Veeveeveveveveeveev , VevV , '' )
 i11Iiii ( '[B][COLOR gold]Top Rated[/COLOR][/B] [B][COLOR white](68)[/COLOR][/B]' , eevVVV + 'top-rated/' , 48 , i1 , VevV , '' )
 for I1iI1 in Vevev :
  iI1iI1I1i1I = re . compile ( '<strong>(.+?)</strong>' ) . findall ( I1iI1 ) [ 0 ]
  iiiIi1 = re . compile ( '<div class="cllnumber">(.+?)</div>' ) . findall ( I1iI1 ) [ 0 ]
  i1I1ii11i1Iii = re . compile ( '<a href="(.+?)"' ) . findall ( I1iI1 ) [ 0 ]
  VeveeeeevVeevev = 'https://www.eporner.com' + i1I1ii11i1Iii
  if not 'All' in iI1iI1I1i1I :
   if not 'Homemade' in iI1iI1I1i1I :
    i11Iiii ( "[B][COLOR gold]" + iI1iI1I1i1I + "  " + "[COLOR white]" + iiiIi1 + "[/COLOR][/B]" , VeveeeeevVeevev , 48 , i1 , Ve , '' )
    if 26 - 26: IiIi1Iii1I1 - iIii1I11I1II1 - Veve / I1 . eV % iIii1I11I1II1
def VV ( url ) :
 if 25 - 25: I1
 url = url
 iIii11I = VVVevVVVevevee ( url )
 Iii111II = '<span>.+?</span></div> <a href="(.+?)" title="(.+?)" id=".+?"> <div id=".+?" class="mbimg"> <div class="mbcontent"> <img id=".+?" src="(.+?)"'
 if 62 - 62: i1iIIi1 + Vev
 i11VeveeevVVeveVVVe = re . findall ( Iii111II , iIii11I , re . DOTALL )
 if 98 - 98: IiiIIiiI11
 for eevVVeeevVVevVVV in i11VeveeevVVeveVVVe :
  iI1iI1I1i1I = eevVVeeevVVevVVV [ 1 ]
  url = eevVVeeevVVevVVV [ 0 ]
  I1ii11iIi11i = eevVVeeevVVevVVV [ 2 ]
  i11Iiii ( '[B][COLOR gold]' + iI1iI1I1i1I + '[/COLOR][/B]' , url , 47 , I1ii11iIi11i , VevV , '' )
  if 51 - 51: i1iIIII - IiiIII111ii + II111iiii * VevevVevVevVev . IiIi1Iii1I1 + IiiIII111ii
 try :
  VevVevV = re . compile ( '<a href=\"([^"]*)\" title="Next page">' ) . findall ( iIii11I ) [ 0 ]
  VeVeve = 'https://www.eporner.com' + VevVevV
  iIi11Ii1 ( "[B][COLOR white]" + "Next Page>>>" + "[/COLOR][/B]" , VeVeve , 48 , eVeeveeeeeveve , Ve , '' )
 except : pass
 if 78 - 78: IiiIII111ii % Vev % VevevVevVevVev
def ii ( url , iconimage ) :
 if 5 - 5: iIiIiIiIIi - II111iiii - VeeeeeeeVV % VevevVevVevVev + Veve * iIii1I11I1II1
 if not 'https' in url :
  url = 'https://eporner.com' + url
 eVVevevVe = VVVevVVVevevee ( url ) . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' )
 I1I1II1I11 = re . compile ( '<div id="hd-porn-dload">(.+?)</div>' ) . findall ( eVVevevVe ) [ 0 ]
 IIiiIiII1Ii = re . compile ( '<strong>(.+?)</strong>.+?<a href="(.+?)"' ) . findall ( I1I1II1I11 )
 for III1Iiii1I11 , eVVevevVe in IIiiIiII1Ii :
  III1Iiii1I11 = III1Iiii1I11 . replace ( ':' , '' )
  url = 'https://www.eporner.com' + eVVevevVe
  eeeveveVVeveveveVev ( "[COLOR gold]" + "Link Quality " + "[COLOR silver]" + III1Iiii1I11 + "[/COLOR]" , url , 45 , iconimage , Ve , '' )
  if 4 - 4: VevevVevVevVev
def iI11I1II ( ) :
 VevevVVVeVeeevV = xbmc . Keyboard ( '' , 'Search For Your Porn!' )
 VevevVVVeVeeevV . doModal ( )
 if ( VevevVVVeVeeevV . isConfirmed ( ) ) :
  VevevevVVeevevee = VevevVVVeVeeevV . getText ( ) . replace ( ' ' , '+' )
  VeveeeeevVeevev = eevVVV + 'search/?q=' + VevevevVVeevevee
  VV ( VeveeeeevVeevev )
  if 40 - 40: iIii1I11I1II1 / eV % eeeVVVVV + II111iiii
  if 27 - 27: II111iiii * eV * iIii1I11I1II1
def eVeeveveVeVevevev ( ) :
 VeveeeeevVeevev = ( iIiiiI )
 eVVevevVe = VVVevVVVevevee ( VeveeeeevVeevev )
 i11Iiii ( '[B][COLOR gold]SEARCH[/COLOR][/B]' , VeveeeeevVeevev , 58 , Veeveeveveveveeveev , VevV , '' )
 Vevev = re . compile ( '<div class=\"thumb\">(.+?)</a>' ) . findall ( eVVevevVe )
 for I1iI1 in Vevev :
  iI1iI1I1i1I = re . compile ( 'title=\"(.+?)\">' ) . findall ( I1iI1 ) [ 0 ]
  i1I1ii11i1Iii = re . compile ( '<a href=\"(.+?)\"' ) . findall ( I1iI1 ) [ 0 ]
  I1ii11iIi11i = re . compile ( '<img src=\"(.+?)\"' ) . findall ( I1iI1 ) [ 0 ]
  VeveeeeevVeevev = 'https://www.porn.com' + i1I1ii11i1Iii
  if not 'Gay' in iI1iI1I1i1I :
   i11Iiii ( "[B][COLOR gold]" + iI1iI1I1i1I + " [/COLOR][/B]" , VeveeeeevVeevev , 49 , I1ii11iIi11i , Ve , '' )
   if 93 - 93: IiiIIiiI11 % i1IIi . VevevVevVevVev . i11iIiiIii
def eVVeeevevVeveve ( url ) :
 if 98 - 98: i1iIIi1 + eVVeVev + IiiIII111ii % VeeeeeeeVV
 url = url
 iIii11I = VVVevVVVevevee ( url )
 Iii111II = '<div class="thumb"><a href="(.+?)" title="(.+?)"><img src="(.+?)" '
 if 97 - 97: Vev * VeeeeeeeVV . VeeeeeeeVV
 i11VeveeevVVeveVVVe = re . findall ( Iii111II , iIii11I , re . DOTALL )
 if 33 - 33: VevVeVevevevVevVV + IIIiiiiiIii * IiiIII111ii / iIii1I11I1II1 - Veve
 for eevVVeeevVVevVVV in i11VeveeevVVeveVVVe :
  iI1iI1I1i1I = eevVVeeevVVevVVV [ 1 ]
  url = eevVVeeevVVevVVV [ 0 ]
  I1ii11iIi11i = eevVVeeevVVevVVV [ 2 ]
  i11Iiii ( '[B][COLOR gold]' + iI1iI1I1i1I + '[/COLOR][/B]' , url , 50 , I1ii11iIi11i , VevV , '' )
  if 54 - 54: VevVeVevevevVevVV / i1iIIi1 . IiiIII111ii % IIIiiiiiIii
  if 57 - 57: i11iIiiIii . eeeVVVVV - VevevVevVevVev - IiiIII111ii + eV
 try :
  VevVevV = re . compile ( 'class="active">.+?</a><a href="(.+?)">.+?</a>' ) . findall ( iIii11I ) [ 0 ]
  VeVeve = 'https://www.porn.com' + VevVevV
  iIi11Ii1 ( "[B][COLOR white]" + "Next Page>>>" + "[/COLOR][/B]" , VeVeve , 49 , eVeeveeeeeveve , Ve , '' )
 except : pass
 if 63 - 63: eV * IIIiiiiiIii
def ee ( url , iconimage ) :
 if 44 - 44: IiiIII111ii / IiIi1Iii1I1 / IiIi1Iii1I1
 if not 'https' in url :
  url = 'https://www.porn.com' + url
 eVVevevVe = VVVevVVVevevee ( url ) . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' )
 I1I1II1I11 = re . compile ( 'streams:\[{(.+?),hide' ) . findall ( eVVevevVe ) [ 0 ]
 IIiiIiII1Ii = re . compile ( 'id:"(.+?)".+?"(.+?)"' ) . findall ( I1I1II1I11 )
 for III1Iiii1I11 , eVVevevVe in IIiiIiII1Ii :
  III1Iiii1I11 = III1Iiii1I11 . replace ( ':' , '' )
  url = eVVevevVe
  eeeveveVVeveveveVev ( "[COLOR gold]" + "Link Quality " + "[COLOR silver]" + III1Iiii1I11 + "[/COLOR]" , url , 45 , iconimage , Ve , '' )
  if 87 - 87: i1iIIII . Veve - II111iiii + Vev / i1iIIII / IiiIII111ii
def IiI ( ) :
 VevevVVVeVeeevV = xbmc . Keyboard ( '' , 'Search For Your Porn!' )
 VevevVVVeVeeevV . doModal ( )
 if ( VevevVVVeVeeevV . isConfirmed ( ) ) :
  VevevevVVeevevee = VevevVVVeVeeevV . getText ( ) . replace ( ' ' , '+' )
  VeveeeeevVeevev = iIiiiI + 'search/?q=' + VevevevVVeevevee
  eVVeeevevVeveve ( VeveeeeevVeevev )
  if 32 - 32: IiiIIiiI11 + Veve + VevVeVevevevVevVV . iIiIiIiIIi - i1IIi
  if 36 - 36: eV
def VVevVevevev ( ) :
 if 37 - 37: VeeeeeeeVV - Vev - IiiIIiiI11
 VeveeeeevVeevev = ( Iii1ii1II11i )
 eVVevevVe = VVVevVVVevevee ( VeveeeeevVeevev )
 i11Iiii ( '[B][COLOR gold]SEARCH[/COLOR][/B]' , VeveeeeevVeevev , 59 , Veeveeveveveveeveev , VevV , '' )
 Vevev = re . compile ( '<li>\s+(.+?)<em class=\"facet\">' ) . findall ( eVVevevVe )
 for I1iI1 in Vevev :
  iI1iI1I1i1I = re . compile ( 'title=\"(.+?)\">' ) . findall ( I1iI1 ) [ 0 ] . replace ( '&amp;' , '&' )
  iiiIi1 = re . compile ( '<em class=\"normal\">(.+?)</em>' ) . findall ( I1iI1 ) [ 0 ]
  i1I1ii11i1Iii = re . compile ( '<a href=\"(.+?)\"' ) . findall ( I1iI1 ) [ 0 ]
  VeveeeeevVeevev = 'https://www.empflix.com' + i1I1ii11i1Iii
  i11Iiii ( "[B][COLOR gold]" + iI1iI1I1i1I + "  " + "[COLOR white]" "(" + iiiIi1 + ")" " [/COLOR][/B]" , VeveeeeevVeevev , 51 , eeveVeVeveve , Ve , '' )
  if 77 - 77: i1iIIi1 * iIii1I11I1II1
def eVeveveVVeeeV ( url ) :
 if 46 - 46: Veve - VeeeeeeeVV - IiIi1Iii1I1 * II111iiii
 url = url
 iIii11I = VVVevVVVevevee ( url )
 Iii111II = '<a class=\'thumb\' href=\'(.+?)\' data-width=\'0\'>\s+<img class=\'lazy\' src=\'/images/loader.jpg\' data-original=\'(.+?)\' alt=\"(.+?)\">'
 if 34 - 34: IiIi1Iii1I1 - IIIiiiiiIii / i1iIIi1 + eeeVVVVV * VevevVevVevVev
 i11VeveeevVVeveVVVe = re . findall ( Iii111II , iIii11I , re . DOTALL )
 if 73 - 73: eV . VevevVevVevVev * eeeVVVVV % eeeVVVVV % VeeeeeeeVV
 for eevVVeeevVVevVVV in i11VeveeevVVeveVVVe :
  iI1iI1I1i1I = eevVVeeevVVevVVV [ 2 ]
  url = eevVVeeevVVevVVV [ 0 ]
  I1ii11iIi11i = eevVVeeevVVevVVV [ 1 ]
  eeeveveVVeveveveVev ( '[B][COLOR gold]' + iI1iI1I1i1I + '[/COLOR][/B]' , url , 52 , I1ii11iIi11i , VevV , '' )
  if 63 - 63: iIii1I11I1II1 * i11iIiiIii % iIii1I11I1II1 * i11iIiiIii
 try :
  VevVevV = re . compile ( '<a class="act">.+?</a><a href="(.+?)">.+?</a>' ) . findall ( iIii11I ) [ 0 ]
  VeVeve = 'https://www.empflix.com' + VevVevV
  i11Iiii ( "[B][COLOR white]" + "Next Page>>>" + "[/COLOR][/B]" , VeVeve , 51 , eVeeveeeeeveve , Ve , '' )
 except : pass
 if 32 - 32: i1iIIi1
def I11iiiiIIii1I ( name , url , iconimage ) :
 if 36 - 36: IiiIII111ii % IiiIII111ii % i1IIi / i1IIi - iIiIiIiIIi
 if not 'https' in url :
  i1iI = 'https://empflix.com' + url
 eVVevevVe = VVVevVVVevevee ( i1iI )
 I1I1II1I11 = re . compile ( '<meta itemprop="contentUrl" content="(.+?)" />' ) . findall ( eVVevevVe ) [ 0 ]
 for eVVevevVe in I1I1II1I11 :
  url = I1I1II1I11
  VeevVev ( name , url , iconimage , '' )
  if 82 - 82: II111iiii % IiIi1Iii1I1 / I1 + eV / IiiIIiiI11 / VevVeVevevevVevVV
def eVeevVVeVev ( ) :
 VevevVVVeVeeevV = xbmc . Keyboard ( '' , 'Search For Your Porn!' )
 VevevVVVeVeeevV . doModal ( )
 if ( VevevVVVeVeeevV . isConfirmed ( ) ) :
  VevevevVVeevevee = VevevVVVeVeeevV . getText ( ) . replace ( ' ' , '+' )
  VeveeeeevVeevev = 'https://www.empflix.com/' + 'search.php?what=' + VevevevVVeevevee + '&tab='
  eVeveveVVeeeV ( VeveeeeevVeevev )
  if 11 - 11: eeeVVVVV . I1 * eVVeVev * VeeeeeeeVV + iIiIiIiIIi
  if 33 - 33: Vev * IiiIIiiI11 - VevVeVevevevVevVV % VevVeVevevevVevVV
def I11I ( ) :
 if 50 - 50: VevVeVevevevVevVV * i11iIiiIii * iIii1I11I1II1 - II111iiii * IiiIIiiI11 * eV
 VeveeeeevVeevev = ( iI111iI )
 eVVevevVe = VVVevVVVevevee ( VeveeeeevVeevev )
 Vevev = re . compile ( '<li data-item=\".+?\">(.+?)</a>' ) . findall ( eVVevevVe )
 for I1iI1 in Vevev :
  iI1iI1I1i1I = re . compile ( '<span class="title">(.+?)</span>' ) . findall ( I1iI1 ) [ 0 ]
  I1ii11iIi11i = re . compile ( '<img src="(.+?)" />' ) . findall ( I1iI1 ) [ 0 ]
  i1I1ii11i1Iii = re . compile ( '<a href="(.+?)"' ) . findall ( I1iI1 ) [ 0 ]
  VeveeeeevVeevev = i1I1ii11i1Iii
  i11Iiii ( "[B][COLOR gold]" + iI1iI1I1i1I + "  [/COLOR][/B]" , VeveeeeevVeevev , 53 , I1ii11iIi11i , Ve , '' )
  if 94 - 94: VeeeeeeeVV + VeeeeeeeVV . II111iiii + IiIi1Iii1I1 / eeeVVVVV % VevevVevVevVev
def I1Ii1iiiiii1 ( url ) :
 if 96 - 96: i11iIiiIii % i1iIIi1
 url = 'http://www.sexdraw.com' + url
 iIii11I = VVVevVVVevevee ( url )
 Iii111II = '<li class="newest"><a href="(.+?)" class="thumb"><img src="(.+?)" /><span class="scrub"><span></span></span><span class="duration">.+?</span></a><a href=".+?" class="title" title=".+?">(.+?)</a>'
 if 70 - 70: iIii1I11I1II1
 i11VeveeevVVeveVVVe = re . findall ( Iii111II , iIii11I , re . DOTALL )
 if 31 - 31: eVVeVev - Veve % iIii1I11I1II1
 for eevVVeeevVVevVVV in i11VeveeevVVeveVVVe :
  iI1iI1I1i1I = eevVVeeevVVevVVV [ 2 ]
  url = eevVVeeevVVevVVV [ 0 ]
  I1ii11iIi11i = eevVVeeevVVevVVV [ 1 ]
  i11Iiii ( '[B][COLOR gold]' + iI1iI1I1i1I + '[/COLOR][/B]' , url , 54 , I1ii11iIi11i , VevV , '' )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 92 - 92: i1IIi - iIii1I11I1II1
def IIIIIIii1 ( url , iconimage ) :
 if 88 - 88: I1
 if not 'http' in url :
  url = 'http://www.sexdraw.com' + url
 eVVevevVe = VVVevVVVevevee ( url ) . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' )
 I1I1II1I11 = re . compile ( 'var k=(.+?)},n=' ) . findall ( eVVevevVe ) [ 0 ]
 IIiiIiII1Ii = re . compile ( '{\"(.+?)\":\"(.+?)\"' ) . findall ( I1I1II1I11 )
 for III1Iiii1I11 , eVVevevVe in IIiiIiII1Ii :
  III1Iiii1I11 = III1Iiii1I11 . replace ( ':' , '' )
  url = eVVevevVe
  eeeveveVVeveveveVev ( "[COLOR gold]" + "Link Quality " + "[COLOR silver]" + III1Iiii1I11 + "[/COLOR]" , url , 45 , iconimage , Ve , '' )
  if 71 - 71: eeeVVVVV
  if 7 - 7: eeeVVVVV - Veve . iIii1I11I1II1 - i1IIi
  if 59 - 59: IiiIIiiI11
def eVeVevevVev ( ) :
 if 75 - 75: Veve . iIiIiIiIIi . Vev * VevVeVevevevVevVV
 VeveeeeevVeevev = ( IiII )
 eVVevevVe = VVVevVVVevevee ( VeveeeeevVeevev )
 Vevev = re . compile ( '<li>\s+(.+?)\s+</li>' ) . findall ( eVVevevVe )
 for I1iI1 in Vevev :
  iI1iI1I1i1I = re . compile ( '">(.+?)</a>' ) . findall ( I1iI1 ) [ 0 ]
  i1I1ii11i1Iii = re . compile ( '<a href="(.+?)">' ) . findall ( I1iI1 ) [ 0 ]
  VeveeeeevVeevev = i1I1ii11i1Iii
  if not 'Videos' in iI1iI1I1i1I :
   if not 'Galleries' in iI1iI1I1i1I :
    if not 'Categories' in iI1iI1I1i1I :
     if not 'Upload' in iI1iI1I1i1I :
      if not 'Members' in iI1iI1I1i1I :
       i11Iiii ( "[B][COLOR gold]" + iI1iI1I1i1I + "  [/COLOR][/B]" , VeveeeeevVeevev , 55 , I11 , Ve , '' )
       if 4 - 4: VevevVevVevVev % IiiIII111ii * I1
def eevVevVVVVeVVev ( url ) :
 if 23 - 23: i11iIiiIii
 url = url
 iIii11I = VVVevVVVevevee ( url )
 Iii111II = '<div class="thumbnail thumb">\s+<a href="(.+?)">\s+<h5 class="text-nowrap title">(.+?)</h5>\s+<img src="(.+?)"'
 if 30 - 30: IiiIIiiI11 - i1IIi % II111iiii + IiIi1Iii1I1 * iIii1I11I1II1
 i11VeveeevVVeveVVVe = re . findall ( Iii111II , iIii11I , re . DOTALL )
 if 81 - 81: eVVeVev % i1IIi . iIii1I11I1II1
 for eevVVeeevVVevVVV in i11VeveeevVVeveVVVe :
  iI1iI1I1i1I = eevVVeeevVVevVVV [ 1 ]
  url = eevVVeeevVVevVVV [ 0 ]
  I1ii11iIi11i = eevVVeeevVVevVVV [ 2 ]
  eeeveveVVeveveveVev ( '[B][COLOR gold]' + iI1iI1I1i1I + '[/COLOR][/B]' , url , 56 , I1ii11iIi11i , VevV , '' )
  if 4 - 4: i11iIiiIii % I1 % i1IIi / eVVeVev
 try :
  if 6 - 6: IIIiiiiiIii / Veve % i1iIIi1 - Veve
  VevVevV = re . compile ( '<a href=\'(.+?)\' class=\'btn btn-primary\'>More videos</a>' ) . findall ( iIii11I ) [ 0 ]
  VeVeve = VevVevV
  iIi11Ii1 ( "[B][COLOR white]" + "Next Page>>>" + "[/COLOR][/B]" , VeVeve , 55 , eVeeveeeeeveve , Ve , '' )
 except : pass
 if 31 - 31: i1iIIi1
def i1VVVeveveveveV ( name , url , iconimage ) :
 if 15 - 15: eV % Veve * IiIi1Iii1I1
 url = url
 eVVevevVe = VVVevVVVevevee ( url )
 I1I1II1I11 = re . compile ( '<source type="video/mp4" src="(.+?)">' ) . findall ( eVVevevVe ) [ 0 ]
 for eVVevevVe in I1I1II1I11 :
  url = I1I1II1I11
  VeevVev ( name , url , iconimage , '' )
  if 81 - 81: iIiIiIiIIi - iIii1I11I1II1 - i1IIi / VevVeVevevevVevVV - Vev * IiIi1Iii1I1
  if 20 - 20: IiiIII111ii % eVVeVev
def III1i1i11i ( ) :
 if 100 - 100: IiiIII111ii / VevVeVevevevVevVV / eeeVVVVV
 VeveeeeevVeevev = ( iI1Ii11111iIi )
 eVVevevVe = VVVevVVVevevee ( VeveeeeevVeevev )
 i11Iiii ( '[B][COLOR gold]SEARCH[/COLOR][/B]' , VeveeeeevVeevev , 62 , Veeveeveveveveeveev , VevV , '' )
 Vevev = re . compile ( '<li data-item=\".+?\">(.+?)</a></li>' ) . findall ( eVVevevVe )
 for I1iI1 in Vevev :
  iI1iI1I1i1I = re . compile ( '<span class="title">(.+?)</span>' ) . findall ( I1iI1 ) [ 0 ]
  I1ii11iIi11i = re . compile ( '<img src=\"(.+?)\"' ) . findall ( I1iI1 ) [ 0 ]
  i1I1ii11i1Iii = re . compile ( '<a href="(.+?)" class' ) . findall ( I1iI1 ) [ 0 ]
  VeveeeeevVeevev = i1I1ii11i1Iii
  i11Iiii ( "[B][COLOR gold]" + iI1iI1I1i1I + "  [/COLOR][/B]" , VeveeeeevVeevev , 60 , I1ii11iIi11i , Ve , '' )
  if 78 - 78: i1iIIII - IiiIIiiI11 / eV
def I11IIIi ( url ) :
 if 15 - 15: eeeVVVVV * I1
 url = 'http://www.faptv.com' + url
 iIii11I = VVVevVVVevevee ( url )
 Iii111II = '<a href=\"(.+?)\" class=\".+?\"><img src=\"(.+?)\" /><span class=\".+?\"><span></span></span><span class=\"duration\">.+?</span></a><a href=\".+?\" class=\"title\" title=\".+?\">(.+?)</a>'
 if 16 - 16: IIIiiiiiIii + eV
 i11VeveeevVVeveVVVe = re . findall ( Iii111II , iIii11I , re . DOTALL )
 if 66 - 66: IIIiiiiiIii / IiiIII111ii * VeeeeeeeVV + VeeeeeeeVV % IiIi1Iii1I1
 for eevVVeeevVVevVVV in i11VeveeevVVeveVVVe :
  iI1iI1I1i1I = eevVVeeevVVevVVV [ 2 ]
  I1ii11iIi11i = eevVVeeevVVevVVV [ 1 ]
  url = eevVVeeevVVevVVV [ 0 ]
  if not 't=' in url :
   eeeveveVVeveveveVev ( '[B][COLOR gold]' + iI1iI1I1i1I + '[/COLOR][/B]' , url , 61 , I1ii11iIi11i , VevV , '' )
   if 49 - 49: IiiIII111ii - i11iIiiIii . VevVeVevevevVevVV * VevevVevVevVev % IIIiiiiiIii + i1IIi
   if 71 - 71: IiiIIiiI11
 try :
  VevVevV = re . compile ( '<link rel="next" href="(.+?)" />' ) . findall ( iIii11I ) [ 0 ]
  VeVeve = VevVevV . replace ( '&amp;p' , '&p' )
  i11Iiii ( "[B][COLOR white]" + "Next Page>>>" + "[/COLOR][/B]" , VeVeve , 60 , eVeeveeeeeveve , Ve , '' )
 except : pass
 if 38 - 38: IiiIII111ii % eV + eeeVVVVV . i11iIiiIii
def eeeveveveveeeeVeve ( name , url , iconimage ) :
 if 40 - 40: eeeVVVVV + i1IIi * i1iIIi1
 if not 'http' in url :
  url = 'http://www.faptv.com' + url
 eVVevevVe = VVVevVVVevevee ( url )
 I1I1II1I11 = re . compile ( 'var k={".+?":"(.+?)"}' ) . findall ( eVVevevVe ) [ 0 ]
 for eVVevevVe in I1I1II1I11 :
  url = I1I1II1I11
  VeevVev ( name , url , iconimage , '' )
  if 85 - 85: VevevVevVevVev * i1iIIII . Vev - i11iIiiIii
  if 18 - 18: VevevVevVevVev + eVVeVev - Vev
  if 53 - 53: i1IIi
  if 87 - 87: i11iIiiIii + VevVeVevevevVevVV . eeeVVVVV * VevVeVevevevVevVV . iIiIiIiIIi / eeeVVVVV
def VeeeevV ( ) :
 eeevevVeveVevVev = [ ]
 eeeevVVevVevVe = sys . argv [ 2 ]
 if len ( eeeevVVevVevVe ) >= 2 :
  VeeevVeveeee = sys . argv [ 2 ]
  iiI = VeeevVeveeee . replace ( '?' , '' )
  if ( VeeevVeveeee [ len ( VeeevVeveeee ) - 1 ] == '/' ) :
   VeeevVeveeee = VeeevVeveeee [ 0 : len ( VeeevVeveeee ) - 2 ]
  eVIIiIi = iiI . split ( '&' )
  eeevevVeveVevVev = { }
  for VVeVeeVeVVVee in range ( len ( eVIIiIi ) ) :
   Iiii1iI1i = { }
   Iiii1iI1i = eVIIiIi [ VVeVeeVeVVVee ] . split ( '=' )
   if ( len ( Iiii1iI1i ) ) == 2 :
    eeevevVeveVevVev [ Iiii1iI1i [ 0 ] ] = Iiii1iI1i [ 1 ]
 return eeevevVeveVevVev
 if 34 - 34: iIiIiIiIIi * Veve . i1IIi * iIiIiIiIIi / iIiIiIiIIi
 if 30 - 30: eeeVVVVV + i1iIIII / i1iIIII % eeeVVVVV . eeeVVVVV
def i11Iiii ( name , url , mode , iconimage , fanart , description = '' ) :
 VevVevVeevev = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&description=" + str ( description ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 eVeVeveve = True
 ii1 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 ii1 . setInfo ( type = "Video" , infoLabels = { "Title" : name , 'plot' : description } )
 ii1 . setProperty ( 'fanart_image' , fanart )
 eVeVeveve = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = VevVevVeevev , listitem = ii1 , isFolder = True )
 return eVeVeveve
 if 100 - 100: IiiIIiiI11 + i1iIIi1 * IiiIIiiI11
def iIi11Ii1 ( name , url , mode , iconimage , fanart , description ) :
 VevVevVeevev = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&description=" + urllib . quote_plus ( description )
 eVeVeveve = True
 ii1 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 ii1 . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 ii1 . setProperty ( 'fanart_image' , fanart )
 if mode == 41 :
  ii1 . setProperty ( "IsPlayable" , "true" )
  eVeVeveve = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = VevVevVeevev , listitem = ii1 , isFolder = False )
 else :
  eVeVeveve = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = VevVevVeevev , listitem = ii1 , isFolder = True )
 return eVeVeveve
 if 80 - 80: IiiIIiiI11 * Vev - VevevVevVevVev
def eeeveveVVeveveveVev ( name , url , mode , iconimage , fanart , description = '' ) :
 VevVevVeevev = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&description=" + str ( description ) + "&fanart=" + urllib . quote_plus ( fanart ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 eVeVeveve = True
 ii1 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 ii1 . setProperty ( 'fanart_image' , fanart )
 ii1 . setProperty ( "IsPlayable" , "true" )
 eVeVeveve = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = VevVevVeevev , listitem = ii1 , isFolder = False )
 return eVeVeveve
 if 66 - 66: i11iIiiIii - i1iIIi1 * i1iIIII
def VeevVev ( name , url , iconimage , description ) :
 if description : name = description
 try :
  if urlresolver . HostedMediaFile ( url ) . valid_url ( ) :
   url = urlresolver . HostedMediaFile ( url ) . resolve ( )
   VeeVVVV ( name , url , iconimage )
  elif liveresolver . isValid ( url ) == True :
   url = liveresolver . resolve ( url )
   VeeVVVV ( name , url , iconimage )
  else : VeeVVVV ( name , url , iconimage )
 except :
  iIIIiiI1i1i ( iIII ( 'Tissues Time' ) , 'Stream Unavailable' , '3000' , I1ii11iIi11i )
  if 70 - 70: IIIiiiiiIii / iIii1I11I1II1
def VeeVVVV ( name , url , iconimage ) :
 eVeVeveve = True
 ii1 = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage ) ; ii1 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 eVeVeveve = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = url , listitem = ii1 )
 ii1 . setPath ( url )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ii1 )
 if 85 - 85: VeeeeeeeVV % i1IIi * VeeeeeeeVV / eeeVVVVV
def iIIIiiI1i1i ( title , message , ms , nart ) :
 xbmc . executebuiltin ( "XBMC.notification(" + title + "," + message + "," + ms + "," + nart + ")" )
 if 96 - 96: VeeeeeeeVV + IiiIII111ii
def iIII ( string ) :
 string = string . split ( ' ' )
 iiII1i11i = ''
 for IiIi in string :
  VVVVVevVevev = '[B][COLOR yellow]' + IiIi [ 0 ] . upper ( ) + '[/COLOR][COLOR white]' + IiIi [ 1 : ] + '[/COLOR][/B] '
  iiII1i11i = iiII1i11i + VVVVVevVevev
 return iiII1i11i
 if 30 - 30: iIii1I11I1II1 . Veve . i1iIIi1 / IiiIIiiI11
VeeevVeveeee = VeeeevV ( ) ; VeveeeeevVeevev = None ; iI1iI1I1i1I = None ; iiI1I1 = None ; eeV = None ; I1iI1iIi111i = None ; iiVVevVevVee = None
try : eeV = urllib . unquote_plus ( VeeevVeveeee [ "site" ] )
except : pass
try : VeveeeeevVeevev = urllib . unquote_plus ( VeeevVeveeee [ "url" ] )
except : pass
try : iI1iI1I1i1I = urllib . unquote_plus ( VeeevVeveeee [ "name" ] )
except : pass
try : iiI1I1 = int ( VeeevVeveeee [ "mode" ] )
except : pass
try : I1iI1iIi111i = urllib . unquote_plus ( VeeevVeveeee [ "iconimage" ] )
except : pass
try : VevV = urllib . unquote_plus ( VeeevVeveeee [ "fanart" ] )
except : pass
try : iiVVevVevVee = str ( VeeevVeveeee [ "description" ] )
except : pass
if 77 - 77: IiiIIiiI11 / VeeeeeeeVV
if iiI1I1 == None or VeveeeeevVeevev == None or len ( VeveeeeevVeevev ) < 1 : eeeveeeeeVev ( )
elif iiI1I1 == 1 : I1I ( )
elif iiI1I1 == 2 : VeV ( )
elif iiI1I1 == 3 : eVeeveveVeVevevev ( )
elif iiI1I1 == 4 : VVevVevevev ( )
elif iiI1I1 == 5 : I11I ( )
elif iiI1I1 == 6 : eVeVevevVev ( )
elif iiI1I1 == 7 : III1i1i11i ( )
elif iiI1I1 == 8 : EROXIAPORN ( )
elif iiI1I1 == 36 : RESOLVE2 ( VeveeeeevVeevev )
elif iiI1I1 == 37 : VVVevev ( VeveeeeevVeevev )
elif iiI1I1 == 38 : iii1i1iiiiIi ( VeveeeeevVeevev )
elif iiI1I1 == 39 : VeveeeevVeveeev ( VeveeeeevVeevev )
elif iiI1I1 == 40 : ii1ii11IIIiiI ( )
elif iiI1I1 == 41 : eVVeeveVeev ( VeveeeeevVeevev )
elif iiI1I1 == 42 : eVVeev ( VeveeeeevVeevev )
elif iiI1I1 == 43 : IIii1Ii1 ( VeveeeeevVeevev )
elif iiI1I1 == 44 : I1III ( VeveeeeevVeevev )
elif iiI1I1 == 45 : VeevVev ( iI1iI1I1i1I , VeveeeeevVeevev , I1iI1iIi111i , iiVVevVevVee )
elif iiI1I1 == 46 : VeeVVVV ( iI1iI1I1i1I , VeveeeeevVeevev , I1iI1iIi111i )
elif iiI1I1 == 47 : ii ( VeveeeeevVeevev , I1iI1iIi111i )
elif iiI1I1 == 48 : VV ( VeveeeeevVeevev )
elif iiI1I1 == 49 : eVVeeevevVeveve ( VeveeeeevVeevev )
elif iiI1I1 == 50 : ee ( VeveeeeevVeevev , I1iI1iIi111i )
elif iiI1I1 == 51 : eVeveveVVeeeV ( VeveeeeevVeevev )
elif iiI1I1 == 52 : I11iiiiIIii1I ( iI1iI1I1i1I , VeveeeeevVeevev , I1iI1iIi111i )
elif iiI1I1 == 53 : I1Ii1iiiiii1 ( VeveeeeevVeevev )
elif iiI1I1 == 54 : IIIIIIii1 ( VeveeeeevVeevev , I1iI1iIi111i )
elif iiI1I1 == 55 : eevVevVVVVeVVev ( VeveeeeevVeevev )
elif iiI1I1 == 56 : i1VVVeveveveveV ( iI1iI1I1i1I , VeveeeeevVeevev , I1iI1iIi111i )
elif iiI1I1 == 57 : iI11I1II ( )
elif iiI1I1 == 58 : IiI ( )
elif iiI1I1 == 59 : eVeevVVeVev ( )
elif iiI1I1 == 60 : I11IIIi ( VeveeeeevVeevev )
elif iiI1I1 == 61 : eeeveveveveeeeVeve ( iI1iI1I1i1I , VeveeeeevVeevev , I1iI1iIi111i )
elif iiI1I1 == 62 : GET_CONTENTEROXIA ( VeveeeeevVeevev )
elif iiI1I1 == 63 : ADULT_LINKSEROXIA ( iI1iI1I1i1I , VeveeeeevVeevev , I1iI1iIi111i )
if 46 - 46: IiiIIiiI11 % iIii1I11I1II1 . IIIiiiiiIii % IIIiiiiiIii + i11iIiiIii
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
