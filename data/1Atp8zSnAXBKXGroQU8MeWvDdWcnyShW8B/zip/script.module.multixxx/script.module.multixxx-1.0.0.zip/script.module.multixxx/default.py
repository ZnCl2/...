# -*- coding: utf-8 -*-
import xbmcgui, xbmcplugin, urllib2

# import ghetto
# import ama
# import best

import requests, xbmcgui, xbmcplugin, xbmc, re, sys, os, xbmcaddon, json, urllib
from threading import Thread


def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if (params[len(params) - 1] == '/'):
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]

    return param


params = get_params()
mode = None

try:
    mode = int(params["addon"])
except:
    pass

#####################################################END PROCESSES##############################################################


if mode == 100:
    import ghetto

elif mode == 101:
    import ama

elif mode == 102:
    import best

xbmcplugin.endOfDirectory(int(sys.argv[1]))
