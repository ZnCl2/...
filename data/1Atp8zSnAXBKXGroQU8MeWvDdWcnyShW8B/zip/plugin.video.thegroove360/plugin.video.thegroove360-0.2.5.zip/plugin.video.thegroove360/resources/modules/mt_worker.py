import logging
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmc
from threading import Thread, Lock
from resources.modules.thegroove import support
from resources.lib import kodiutils

logger = logging.getLogger(xbmcaddon.Addon().getAddonInfo('id'))

try:
    import queue as mQueue
except ImportError:
    import Queue as mQueue


class MTWorker(Thread):

    def __init__(self, queue, fn, qsize, lock=None, show_progress=False, pb_dialog=None, *args, **kwargs):
        Thread.__init__(self, *args, **kwargs)
        self.queue = queue
        self.fn = fn
        self.lock = lock
        self.show_progress = show_progress
        self.pb_dialog = pb_dialog
        self.qsize = qsize
        self.stopped = False

    def stop(self):
        self.stopped = True

    def run(self):
        while not xbmc.Monitor().abortRequested():
            if self.stopped:
                break
            if self.lock:
                with self.lock:
                    self.run_thread()
            else:
                self.run_thread()
        self.stop()

    def run_thread(self):
        logger.debug("__________________ RUN THREAD ________________")
        try:
            if not self.stopped:
                params = self.queue.get()
                if params is None:
                    self.stop()
                    return self.queue.task_done()
                if type(params) == tuple:
                    self.fn(*params)
                else:
                    self.fn(params)
        except:
            raise
        finally:
            if self.show_progress:
                if self.pb_dialog.iscanceled():
                    self.queue.task_done()
                    self.stop()
                    from resources.lib.plugin import plugin
                    xbmcplugin.endOfDirectory(plugin.handle)
                    self.pb_dialog.close()
                    self.queue.task_done()
                    return

                # logger.debug(self.queue.unfinished_tasks)
                item_counter = self.qsize - self.queue.unfinished_tasks
                percent = (item_counter * 100) / self.qsize
                self.pb_dialog.update(percent, "Elaborando Elementi", "%s di %s" % (item_counter, self.qsize))
            if not self.stopped:
                self.queue.task_done()

    @staticmethod
    def set_jobs(queue, fn, use_lock=False, show_progress=False):
        logger.debug("_____________ SET JOBS ____________________")

        # logger.debug(show_progress)
        pb_dialog = xbmcgui.DialogProgress()
        if show_progress:
            addon_name = xbmcaddon.Addon().getAddonInfo('name')
            pb_dialog.create(addon_name, "Loading items")

        if queue.qsize() > 1000:
            use_lock = False

        if use_lock:
            lock = Lock()
        else:
            lock = None
        # mt_list = ['Auto', 1, 2, 4, 8, 16]
        n_cores = kodiutils.get_setting_as_float("n_cores")
        if n_cores == 0:
            n_cores = support.get_cores_num()
            logger.debug(n_cores)
        try:
            n_cores = int(n_cores)
        except:
            n_cores = 2

        max_threads = kodiutils.get_setting_as_int("max_threads")
        logger.debug("MAX THREADS " + str(max_threads))
        # if max_threads != 0:
        #    n_cores = min(mt_list[max_threads], n_cores)
        logger.debug("N_CORES " + str(n_cores))

        kodiutils.set_setting("n_cores", n_cores)

        qsize = queue.qsize()
        threads = []

        for x in range(n_cores):
            worker = MTWorker(queue, fn, qsize, lock=lock, show_progress=show_progress, pb_dialog=pb_dialog)
            worker.daemon = True
            worker.start()
            threads.append(worker)

        queue.join()

        for i in range(n_cores):
            queue.put(None)

        for t in threads:
            t.stop()
            # t.join()

        if show_progress:
            pb_dialog.close()
