import logging
import xbmcaddon
import zlib
import base64

try:
    from urllib.parse import quote as quoter
    from urllib.parse import unquote as unquoter
except ImportError:
    from urllib import quote as quoter
    from urllib import unquote as unquoter

from resources.lib import kodiutils
from resources.modules.httpclient import HttpClient

ADDON = xbmcaddon.Addon()
logger = logging.getLogger(ADDON.getAddonInfo('id'))


class ThegrooveHttpClient(HttpClient):

    def __init__(self):
        HttpClient.__init__(self)
        self.zeronet_url = kodiutils.get_setting("zeronet_url")
        if not self.zeronet_url or self.zeronet_url == "":
            self.zeronet_url = "127.0.0.1:43110"

        self.zeronet_url = "http://" + self.zeronet_url

        self.website = '/1Atp8zSnAXBKXGroQU8MeWvDdWcnyShW8B/'
        self.server_url = self.zeronet_url + self.website
        self._loader = self.server_url + "loader2.php?page="
        self.opts = ""

    def get_request(self, url, **kwargs):
        url = self.server_url + "addon/" + url + ".xml"
        res = HttpClient.get_request(self, url, **kwargs)
        return res.text

    @staticmethod
    def url_composer(page):
        if "/thegroove/scripters/" in page and "path=" in page:
            scripter, spage = page.replace("/thegroove/scripters/", "").split("/", 1)
            page = "php_script_loader?scripter=" + unquoter(scripter) + "&" + unquoter(spage)

        if "?" in page:
            page, params = page.split("?")
            if params != "":
                params = base64.urlsafe_b64encode(params)
                page += "&page_params=" + params

        return page
