# coding: UTF-8
import sys
l1ll1_thegroove = sys.version_info [0] == 2
l1ll111_thegroove = 2048
l11lll_thegroove = 7
def l11_thegroove (ll_thegroove):
    global l1l111l_thegroove
    l11l1_thegroove = ord (ll_thegroove [-1])
    l11l1l_thegroove = ll_thegroove [:-1]
    l111_thegroove = l11l1_thegroove % len (l11l1l_thegroove)
    l1lll_thegroove = l11l1l_thegroove [:l111_thegroove] + l11l1l_thegroove [l111_thegroove:]
    if l1ll1_thegroove:
        l11111_thegroove = unicode () .join ([unichr (ord (char) - l1ll111_thegroove - (l1l111_thegroove + l11l1_thegroove) % l11lll_thegroove) for l1l111_thegroove, char in enumerate (l1lll_thegroove)])
    else:
        l11111_thegroove = str () .join ([chr (ord (char) - l1ll111_thegroove - (l1l111_thegroove + l11l1_thegroove) % l11lll_thegroove) for l1l111_thegroove, char in enumerate (l1lll_thegroove)])
    return eval (l11111_thegroove)
import base64
import hashlib
import os
import requests
import sys
l1l11l_thegroove = False
try:
    from Cryptodome import Random
    from Cryptodome.Cipher import AES
except:
    import resources.lib.pyaes.aes as pyaes
    l1l11l_thegroove = True
try:
    import xbmc
    import xbmcaddon
    import xbmcgui
except:
    pass
class l1lll1l_thegroove:
    def __init__(self):
        self.name = l11_thegroove (u"ࠦࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡸ࡭࡫ࡧࡳࡱࡲࡺࡪ࠹࠶࠱ࠤࠀ")
        self.token = l11_thegroove (u"ࠧࠨࠁ")
        self.l1l1l1_thegroove = l11_thegroove (u"ࠨ࠳࠴࠴ࡖࡉࡈࡘࡅࡕࡣࡥࡧ࠶࠸࠳࠵ࠤࠂ")
        self.l1l11_thegroove = l11_thegroove (u"ࠢࡕࡪࡨ࡫ࡷࡵ࡯ࡷࡧࠣ࠷࠻࠶ࠢࠃ")
        self.result = l11_thegroove (u"ࠣࠤࠄ")
        self.l1ll1l1_thegroove = 0
        self.l1l11l_thegroove = l1l11l_thegroove
    def l1l1l_thegroove(self):
        __caller__ = sys._getframe().f_back.f_code.co_name
        self.l1l1ll1_thegroove(__caller__)
        content = requests.get(l11_thegroove (u"ࠤ࡫ࡸࡹࡶ࠺࠰࠱ࡷ࡬ࡪ࡭ࡲࡰࡱࡹࡩ࠸࠼࠰࠯࡫ࡱࡪࡴ࠵ࡔࡩࡧࡳࡥࡸࡺ࡯࠰ࡶ࡬ࡱࡪ࠴ࡰࡩࡲࠥࠅ"))
        l1lll11_thegroove = content.json()
        ts = l1lll11_thegroove[l11_thegroove (u"ࠥࡸ࡮ࡳࡥࡴࡶࡤࡱࡵࠨࠆ")]
        l1l11l1_thegroove = int(ts - int(l11_thegroove (u"ࠦ࠹࠼࠴࠲࠲࠵࠵࠵࠶ࠢࠇ")))
        return l1l11l1_thegroove
    def l1l1l1l_thegroove(self, l1l11l1_thegroove):
        __caller__ = sys._getframe().f_back.f_code.co_name
        self.l1l1ll1_thegroove(__caller__)
        try:
            __addon__ = xbmcaddon.Addon(id=self.name)
            cwd = xbmc.translatePath(__addon__.getAddonInfo(l11_thegroove (u"ࠬࡶࡡࡵࡪࠪࠈ")))
        except:
            cwd = os.getcwd() + l11_thegroove (u"ࠨ࠯ࡵࡧࡶࡸࠧࠉ")
        path = l11_thegroove (u"ࠢࡳࡧࡶࡳࡺࡸࡣࡦࡵ࠯ࡱࡴࡪࡵ࡭ࡧࡶ࠰࡮ࡺࡥ࡮ࡡࡳࡥࡷࡹࡥࡳ࠰ࡳࡽࠧࠊ").split(l11_thegroove (u"ࠣ࠮ࠥࠋ"))
        l1lllll_thegroove = cwd + os.sep + os.path.join(*path)
        l1l1lll_thegroove = len(open(l1lllll_thegroove).read().splitlines())
        l1l1ll_thegroove = l1l11l1_thegroove % l1l1lll_thegroove
        self.l1ll1l1_thegroove = l1l1ll_thegroove
        line = self.l11ll_thegroove(l1lllll_thegroove, l1l1ll_thegroove)
        return line
    @staticmethod
    def l11ll_thegroove(l1111l_thegroove, l1l1ll_thegroove):
        try:
            with open(l1111l_thegroove, l11_thegroove (u"ࠩࡵࠫࠌ")) as f:
                for l1_thegroove, line in enumerate(f):
                    if l1_thegroove == l1l1ll_thegroove:
                        return str(line)
        except Exception as e:
            pass
    def set_token(self):
        if not self.l111ll_thegroove():
            return None
        try:
            l1l11l1_thegroove = self.l1l1l_thegroove()
            line = self.l1l1l1l_thegroove(l1l11l1_thegroove)
            line = str(l1l11l1_thegroove) + l11_thegroove (u"ࠥ࠾࠿ࠨࠍ") + str(line).rstrip().lstrip()
            l11l_thegroove = self.l111l_thegroove(line)
            self.token = l11l_thegroove
            return l11l_thegroove
        except Exception as e:
            self.l1l1111_thegroove(l11_thegroove (u"ࠦࡋࡵࡲࡣ࡫ࡧࡨࡪࡴࠢࠎ"))
    def set_result(self, data):
        if not self.l111ll_thegroove():
            return None
        if data.headers and data.headers[l11_thegroove (u"࡚ࠧࡨࡦࡩࡵࡳࡴࡼࡥࠣࠏ")] == self.token:
            self.result = bytearray.fromhex(data.text).decode(l11_thegroove (u"ࠨࡵࡵࡨ࠰࠼ࠧࠐ"))
        else:
            self.l1l1111_thegroove(l11_thegroove (u"ࠢࡇࡱࡵࡦ࡮ࡪࡤࡦࡰࠥࠑ"))
            return None
    def l111l_thegroove(self, text):
        __caller__ = sys._getframe().f_back.f_code.co_name
        self.l1l1ll1_thegroove(__caller__)
        l11ll1_thegroove = lambda s, b: s + (b - len(s) % b) * chr(b - len(s) % b)
        l1l_thegroove = l11_thegroove (u"ࠣࡏࡇࡧࡲࡽࡊࡴࡣࠥࠒ") + l11_thegroove (u"ࠤࡊࡵࡋࡔ࡚ࡌࡰࡷࠦࠓ") + l11_thegroove (u"ࠥࡑࡉࡩ࡭ࡸࡌࡶࡥࠧࠔ") + l11_thegroove (u"ࠦ࡟ࡪࡍࡖࡎ࡮ࡔࡗࠨࠕ") + l11_thegroove (u"ࠧࡧࡒ࡚࡜ࡳࡌࡪ࡫ࠢࠖ")
        l1l_thegroove = hashlib.sha256(l1l_thegroove).hexdigest()[:32].encode(l11_thegroove (u"ࠨࡵࡵࡨ࠰࠼ࠧࠗ"))
        l1l1_thegroove = text.encode(l11_thegroove (u"ࠧࡶࡶࡩ࠱࠽࠭࠘"))
        l111l1_thegroove = 32
        if not self.l1l11l_thegroove:
            bs = AES.block_size
            l1ll1ll_thegroove = Random.new().read(bs)
            cipher = AES.new(l1l_thegroove, AES.MODE_CFB, l1ll1ll_thegroove)
            l1ll_thegroove = cipher.encrypt(l11ll1_thegroove(l1l1_thegroove, l111l1_thegroove).encode(l11_thegroove (u"ࠣࡷࡷࡪ࠲࠾ࠢ࠙")))
        else:
            l1ll1ll_thegroove = os.urandom(16)
            aes = pyaes.AESModeOfOperationCFB(l1l_thegroove, l1ll1ll_thegroove)
            l1ll_thegroove = aes.encrypt(l11ll1_thegroove(l1l1_thegroove, l111l1_thegroove).encode(l11_thegroove (u"ࠤࡸࡸ࡫࠳࠸ࠣࠚ")))
        l11l11_thegroove = base64.b64encode(l1ll_thegroove + l11_thegroove (u"ࠪ࠾࠿࠭ࠛ") + l1ll1ll_thegroove).encode(l11_thegroove (u"ࠫࡺࡺࡦ࠮࠺ࠪࠜ"))
        l11l11_thegroove = l11l11_thegroove.replace(l11_thegroove (u"ࠧ࠱ࠢࠝ"), l11_thegroove (u"ࠨ࠮ࠣࠞ"))
        l11l11_thegroove = l11l11_thegroove.replace(l11_thegroove (u"ࠢ࠮ࠤࠟ"), l11_thegroove (u"ࠣ࠮ࠥࠠ"))
        l11l11_thegroove = l11l11_thegroove.replace(l11_thegroove (u"ࠤ࠲ࠦࠡ"), l11_thegroove (u"ࠥࡣࠧࠢ"))
        return l11l11_thegroove
    def l1l11ll_thegroove(self, data):
        __caller__ = sys._getframe().f_back.f_code.co_name
        self.l1l1ll1_thegroove(__caller__)
        data = data.replace(l11_thegroove (u"ࠦ࠳ࠨࠣ"), l11_thegroove (u"ࠧ࠱ࠢࠤ"))
        data = data.replace(l11_thegroove (u"ࠨࠬࠣࠥ"), l11_thegroove (u"ࠢ࠮ࠤࠦ"))
        data = data.replace(l11_thegroove (u"ࠣࡡࠥࠧ"), l11_thegroove (u"ࠤ࠲ࠦࠨ"))
        try:
            res = base64.b64decode(data).split(l11_thegroove (u"ࠪ࠾࠿࠭ࠩ"))
            l1ll1ll_thegroove = res[len(res) - 1]
            l1llll1_thegroove = l11_thegroove (u"ࠫࠬࠪ")
            for i in range(0, (len(res) - 1)):
                l1llll1_thegroove += res[i]
            l1l_thegroove = l11_thegroove (u"ࠧࡓࡄࡤ࡯ࡺࡎࡸࡧࠢࠫ") + l11_thegroove (u"ࠨࡇࡲࡈࡑ࡞ࡐࡴࡴࠣࠬ") + l11_thegroove (u"ࠢࡎࡆࡦࡱࡼࡐࡳࡢࠤ࠭") + l11_thegroove (u"ࠣ࡜ࡧࡑ࡚ࡒ࡫ࡑࡔࠥ࠮") + l11_thegroove (u"ࠤࡤࡖ࡞ࡠࡰࡉࡧࡨࠦ࠯")
            l1l_thegroove = hashlib.sha256(l1l_thegroove).hexdigest()[:32].encode(l11_thegroove (u"ࠥࡹࡹ࡬࠭࠹ࠤ࠰"))
            if not self.l1l11l_thegroove:
                cipher = AES.new(l1l_thegroove, AES.MODE_CFB, l1ll1ll_thegroove)
                l1111_thegroove = cipher.decrypt(l1llll1_thegroove)
            else:
                aes = pyaes.AESModeOfOperationCFB(l1l_thegroove, l1ll1ll_thegroove)
                l1111_thegroove = aes.decrypt(l1llll1_thegroove)
            sep = base64.b64encode(l11_thegroove (u"ࠦ࠯࠰ࠢ࠱")).encode(l11_thegroove (u"ࠧࡻࡴࡧ࠯࠻ࠦ࠲"))
            result, l1ll1l1_thegroove, l1llll_thegroove = l1111_thegroove.split(str(sep))
            if l1ll1l1_thegroove == str(self.l1ll1l1_thegroove):
                return result
            else:
                self.l1l1111_thegroove(l11_thegroove (u"ࠨࡅࡳࡴࡲࡶࡪࠦ࠴࠱࠷ࠥ࠳"), l11_thegroove (u"ࠢࡊ࡯ࡳࡳࡸࡹࡩࡣ࡫࡯ࡩࠥࡉ࡯࡮ࡲ࡯ࡩࡹࡧࡲࡦࠢࡏࡥࠥࡘࡩࡤࡪ࡬ࡩࡸࡺࡡࠣ࠴"))
        except Exception as e:
            self.l1l1111_thegroove(l11_thegroove (u"ࠣࡇࡵࡶࡴࡸࡥࠡ࠶࠳࠻ࠧ࠵"), l11_thegroove (u"ࠤࡌࡱࡵࡵࡳࡴ࡫ࡥ࡭ࡱ࡫ࠠࡄࡱࡰࡴࡱ࡫ࡴࡢࡴࡨࠤࡑࡧࠠࡓ࡫ࡦ࡬࡮࡫ࡳࡵࡣࠥ࠶"))
            import traceback
            traceback.print_stack()
            print(e)
        return None
    def l111ll_thegroove(self, skip=False):
        if skip is False:
            __caller__ = sys._getframe().f_back.f_code.co_name
            self.l1l1ll1_thegroove(__caller__)
        try:
            l1lll1_thegroove = xbmc.getInfoLabel(l11_thegroove (u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡐ࡭ࡷࡪ࡭ࡳࡔࡡ࡮ࡧࠪ࠷"))
            l1lll1_thegroove = xbmcaddon.Addon(l1lll1_thegroove).getAddonInfo(l11_thegroove (u"ࠫࡳࡧ࡭ࡦࠩ࠸"))
            if l1lll1_thegroove != self.l1l11_thegroove:
                raise Exception()
        except Exception as e:
            self.l1l1111_thegroove(l11_thegroove (u"ࠧࡋࡲࡳࡱࡵࡩࠥ࠷ࠢ࠹"), l11_thegroove (u"ࠨࡆࡶࡰࡽ࡭ࡴࡴࡥࠡࡆ࡬ࡷࡵࡵ࡮ࡪࡤ࡬ࡰࡪࠦࡓࡰ࡮ࡲࠤࡘࡻࠢ࠺"), self.l1l11_thegroove + l11_thegroove (u"ࠢࠡࡃࡧࡨࡴࡴࠢ࠻"))
            return False
        try:
            l1ll11l_thegroove = xbmcaddon.Addon(id=self.name)
            xbmc.translatePath(l1ll11l_thegroove.getAddonInfo(l11_thegroove (u"ࠨࡲࡤࡸ࡭࠭࠼")))
        except:
            self.l1l1111_thegroove(l11_thegroove (u"ࠤࡈࡶࡷࡵࡲࡦࠢ࠵ࠦ࠽"), l11_thegroove (u"ࠥࡊࡺࡴࡺࡪࡱࡱࡩࠥࡊࡩࡴࡲࡲࡲ࡮ࡨࡩ࡭ࡧࠣࡗࡴࡲ࡯ࠡࡕࡸࠦ࠾"), self.l1l11_thegroove + l11_thegroove (u"ࠦࠥࡇࡤࡥࡱࡱࠦ࠿"))
            return False
        try:
            l1ll11l_thegroove = xbmcaddon.Addon(id=self.name)
            cwd = xbmc.translatePath(l1ll11l_thegroove.getAddonInfo(l11_thegroove (u"ࠬࡶࡡࡵࡪࠪࡀ")))
            l1ll1l_thegroove = l11_thegroove (u"ࠨࡲࡦࡵࡲࡹࡷࡩࡥࡴ࠮ࡰࡳࡩࡻ࡬ࡦࡵ࠯࡭ࡹ࡫࡭ࡠࡲࡤࡶࡸ࡫ࡲ࠯ࡲࡼࠦࡁ").split(l11_thegroove (u"ࠢ࠭ࠤࡂ"))
            l1lllll_thegroove = cwd + os.sep + os.path.join(*l1ll1l_thegroove)
            if not os.path.isfile(l1lllll_thegroove):
                raise Exception()
        except:
            self.l1l1111_thegroove(l11_thegroove (u"ࠣࡇࡵࡶࡴࡸࡥࠡ࠵ࠥࡃ"), l11_thegroove (u"ࠤࡉࡹࡳࢀࡩࡰࡰࡨࠤࡉ࡯ࡳࡱࡱࡱ࡭ࡧ࡯࡬ࡦࠢࡖࡳࡱࡵࠠࡔࡷࠥࡄ"), self.l1l11_thegroove + l11_thegroove (u"ࠥࠤࡆࡪࡤࡰࡰࠥࡅ"))
            return False
        return True
    def l1l1ll1_thegroove(self, l1l1l11_thegroove):
        if l1l1l11_thegroove != l11_thegroove (u"ࠦࡸ࡫ࡴࡠࡶࡲ࡯ࡪࡴࠢࡆ") and l1l1l11_thegroove != l11_thegroove (u"ࠧࡹࡥࡵࡡࡵࡩࡸࡻ࡬ࡵࠤࡇ"):
            raise Exception()
    def l1l1111_thegroove(self, s1=l11_thegroove (u"ࠨࠢࡈ"), s2=l11_thegroove (u"ࠢࠣࡉ"), l1ll11_thegroove=l11_thegroove (u"ࠣࠤࡊ")):
        try:
            xbmcgui.Dialog().ok(self.l1l11_thegroove, s1, s2, l1ll11_thegroove)
        except:
            print(s1 + l11_thegroove (u"ࠤࠣࠦࡋ") + s2 + l11_thegroove (u"ࠥࠤࠧࡌ") + l1ll11_thegroove)