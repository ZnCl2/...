import base64 as b

id   = b.b64decode('c2NyaXB0Lm1vZHVsZS5zdGVwbHVz')

name = b.b64decode('W0NPTE9SIGZmZmYwMDAwXVN0ZWZhbm8gUHJlbWl1bVsvQ09MT1Jd')

host = b.b64decode('aHR0cDovL3N0ZWZhbm9hZGRvbi5pbmZv')

port = b.b64decode('NDU0NQ==')