# coding: UTF-8
import sys
l1ll1_thegroove = sys.version_info [0] == 2
l1l1lll_thegroove = 2048
l11ll1_thegroove = 7
def l11_thegroove (ll_thegroove):
    global l1l1111_thegroove
    l111l_thegroove = ord (ll_thegroove [-1])
    l11l11_thegroove = ll_thegroove [:-1]
    l111_thegroove = l111l_thegroove % len (l11l11_thegroove)
    l1lll_thegroove = l11l11_thegroove [:l111_thegroove] + l11l11_thegroove [l111_thegroove:]
    if l1ll1_thegroove:
        l1lllll_thegroove = unicode () .join ([unichr (ord (char) - l1l1lll_thegroove - (l11lll_thegroove + l111l_thegroove) % l11ll1_thegroove) for l11lll_thegroove, char in enumerate (l1lll_thegroove)])
    else:
        l1lllll_thegroove = str () .join ([chr (ord (char) - l1l1lll_thegroove - (l11lll_thegroove + l111l_thegroove) % l11ll1_thegroove) for l11lll_thegroove, char in enumerate (l1lll_thegroove)])
    return eval (l1lllll_thegroove)
import base64
import hashlib
import os
import requests
import sys
l1l111_thegroove = False
import inspect
try:
    from Cryptodome import Random
    from Cryptodome.Cipher import AES
except ImportError:
    import resources.lib.pyaes.aes as pyaes
    l1l111_thegroove = True
try:
    import xbmc
    import xbmcaddon
    import xbmcgui
    import xbmcvfs
except:
    pass
class Token:
    def __init__(self):
        self.name = l11_thegroove (u"ࠦࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡸ࡭࡫ࡧࡳࡱࡲࡺࡪ࠹࠶࠱ࠤࠀ")
        self.token = l11_thegroove (u"ࠧࠨࠁ")
        self.l1l11l_thegroove = l11_thegroove (u"ࠨ࠳࠴࠴ࡖࡉࡈࡘࡅࡕࡣࡥࡧ࠶࠸࠳࠵ࠤࠂ")
        self.l11ll_thegroove = l11_thegroove (u"ࠢࡕࡪࡨ࡫ࡷࡵ࡯ࡷࡧࠣ࠷࠻࠶ࠢࠃ")
        self.result = l11_thegroove (u"ࠣࠤࠄ")
        self.l1ll1l1_thegroove = 0
        self.l1l111_thegroove = l1l111_thegroove
    def l1l11_thegroove(self):
        if sys.version_info[0] < 3:
            __caller__ = sys._getframe().f_back.f_code.co_name
        else:
            __caller__ = inspect.stack()[1].function
        self.l1l1l1l_thegroove(__caller__)
        content = requests.get(l11_thegroove (u"ࠤ࡫ࡸࡹࡶ࠺࠰࠱ࡷ࡬ࡪ࡭ࡲࡰࡱࡹࡩ࠸࠼࠰࠯ࡶࡲࡴ࠴࡚ࡨࡦࡲࡤࡷࡹࡵ࠯ࡵ࡫ࡰࡩ࠳ࡶࡨࡱࠤࠅ"))
        l1lll11_thegroove = content.json()
        ts = l1lll11_thegroove[l11_thegroove (u"ࠥࡸ࡮ࡳࡥࡴࡶࡤࡱࡵࠨࠆ")]
        l1l111l_thegroove = int(ts - int(l11_thegroove (u"ࠦ࠹࠼࠴࠲࠲࠵࠵࠵࠶ࠢࠇ")))
        return l1l111l_thegroove
    def l1l1l11_thegroove(self, l1l111l_thegroove):
        if sys.version_info[0] < 3:
            __caller__ = sys._getframe().f_back.f_code.co_name
        else:
            __caller__ = inspect.stack()[1].function
        self.l1l1l1l_thegroove(__caller__)
        try:
            __addon__ = xbmcaddon.Addon(id=self.name)
            if sys.version_info[0] < 3:
                cwd = xbmc.translatePath(__addon__.getAddonInfo(l11_thegroove (u"ࠬࡶࡡࡵࡪࠪࠈ")))
            else:
                cwd = xbmcvfs.translatePath(__addon__.getAddonInfo(l11_thegroove (u"࠭ࡰࡢࡶ࡫ࠫࠉ")))
        except:
            cwd = os.getcwd() + l11_thegroove (u"ࠢ࠰ࡶࡨࡷࡹࠨࠊ")
        path = l11_thegroove (u"ࠣࡴࡨࡷࡴࡻࡲࡤࡧࡶ࠰ࡲࡵࡤࡶ࡮ࡨࡷ࠱࡯ࡴࡦ࡯ࡢࡴࡦࡸࡳࡦࡴ࠱ࡴࡾࠨࠋ").split(l11_thegroove (u"ࠤ࠯ࠦࠌ"))
        l1llll1_thegroove = cwd + os.sep + os.path.join(*path)
        l1l1ll1_thegroove = len(open(l1llll1_thegroove).read().splitlines())
        l1l1l1_thegroove = l1l111l_thegroove % l1l1ll1_thegroove
        self.l1ll1l1_thegroove = l1l1l1_thegroove
        line = self.l11l1_thegroove(l1llll1_thegroove, l1l1l1_thegroove)
        return line
    @staticmethod
    def l11l1_thegroove(l11111_thegroove, l1l1l1_thegroove):
        try:
            with open(l11111_thegroove, l11_thegroove (u"ࠪࡶࠬࠍ")) as f:
                for l1_thegroove, line in enumerate(f):
                    if l1_thegroove == l1l1l1_thegroove:
                        return str(line)
        except Exception as e:
            pass
    def set_token(self):
        if not self.l111l1_thegroove():
            return None
        try:
            l1l111l_thegroove = self.l1l11_thegroove()
            line = self.l1l1l11_thegroove(l1l111l_thegroove)
            line = str(l1l111l_thegroove) + l11_thegroove (u"ࠧࡀ࠺ࠣࠏ") + str(line).rstrip().lstrip()
            l11l_thegroove = self.l1111_thegroove(line)
            self.token = l11l_thegroove
            return l11l_thegroove
        except Exception as e:
            print(l11_thegroove (u"ࠧࡆࡴࡵࡳࡷࠦ࡯࡯ࠢ࡯࡭ࡳ࡫ࠠࡼࡿࠪࠑ").format(sys.exc_info()[-1].tb_lineno), type(e).__name__, e)
            import traceback
            traceback.print_stack()
            print(e)
            self.l11llll_thegroove(l11_thegroove (u"ࠣࡈࡲࡶࡧ࡯ࡤࡥࡧࡱࠦࠒ"))
    def set_result(self, data):
        if not self.l111l1_thegroove():
            return None
        if data.headers and data.headers[l11_thegroove (u"ࠤࡗ࡬ࡪ࡭ࡲࡰࡱࡹࡩࠧࠓ")] == self.token:
            self.result = bytearray.fromhex(data.text).decode(l11_thegroove (u"ࠥࡹࡹ࡬࠭࠹ࠤࠔ"))
        else:
            self.l11llll_thegroove(l11_thegroove (u"ࠦࡋࡵࡲࡣ࡫ࡧࡨࡪࡴࠢࠕ"))
            return None
    @staticmethod
    def l11l1l_thegroove(s, bs):
        l1l1l_thegroove = bs - len(s) % bs
        return (s.decode(l11_thegroove (u"ࠧࡻࡴࡧ࠯࠻ࠦࠖ")) + l1l1l_thegroove * chr(l1l1l_thegroove)).encode(l11_thegroove (u"࠭ࡵࡵࡨ࠰࠼ࠬࠗ"))
    def l1111_thegroove(self, text):
        if sys.version_info[0] < 3:
            __caller__ = sys._getframe().f_back.f_code.co_name
        else:
            __caller__ = inspect.stack()[1].function
        self.l1l1l1l_thegroove(__caller__)
        l1l_thegroove = l11_thegroove (u"ࠢࡎࡆࡦࡱࡼࡐࡳࡢࠤ࠘") + l11_thegroove (u"ࠣࡉࡴࡊࡓࡠࡋ࡯ࡶࠥ࠙") + l11_thegroove (u"ࠤࡐࡈࡨࡳࡷࡋࡵࡤࠦࠚ") + l11_thegroove (u"ࠥ࡞ࡩࡓࡕࡍ࡭ࡓࡖࠧࠛ") + l11_thegroove (u"ࠦࡦࡘ࡙࡛ࡲࡋࡩࡪࠨࠜ")
        if sys.version_info[0] < 3:
            l1l_thegroove = hashlib.sha256(l1l_thegroove).hexdigest()[:32].encode(l11_thegroove (u"ࠧࡻࡴࡧ࠯࠻ࠦࠝ"))
        else:
            l1l_thegroove = hashlib.sha256(l1l_thegroove.encode(l11_thegroove (u"ࠨࡵࡵࡨ࠰࠼ࠧࠞ"))).hexdigest()[:32]
        l1l1_thegroove = text.encode(l11_thegroove (u"ࠧࡶࡶࡩ࠱࠽࠭ࠟ"))
        l1111l_thegroove = 32
        if not self.l1l111_thegroove:
            bs = AES.block_size
            l1ll1ll_thegroove = Random.new().read(bs)
            cipher = AES.new(l1l_thegroove.encode(l11_thegroove (u"ࠣࡷࡷࡪ࠲࠾ࠢࠠ")), AES.MODE_CFB, l1ll1ll_thegroove)
            if sys.version_info[0] < 3:
                l1ll_thegroove = cipher.encrypt(self.l11l1l_thegroove(l1l1_thegroove, l1111l_thegroove).encode(l11_thegroove (u"ࠤࡸࡸ࡫࠳࠸ࠣࠡ")))
            else:
                l1ll111_thegroove = self.l11l1l_thegroove(l1l1_thegroove, l1111l_thegroove)
                l1ll_thegroove = cipher.encrypt(l1ll111_thegroove)
        else:
            l1ll1ll_thegroove = os.urandom(16)
            aes = pyaes.AESModeOfOperationCFB(l1l_thegroove, l1ll1ll_thegroove)
            if sys.version_info[0] < 3:
                l1ll_thegroove = aes.encrypt(self.l11l1l_thegroove(l1l1_thegroove, l1111l_thegroove).encode(l11_thegroove (u"ࠥࡹࡹ࡬࠭࠹ࠤࠢ")))
            else:
                l1ll_thegroove = aes.encrypt(self.l11l1l_thegroove(l1l1_thegroove, l1111l_thegroove))
        if sys.version_info[0] < 3:
            l111ll_thegroove = base64.b64encode(l1ll_thegroove + l11_thegroove (u"ࠫ࠿ࡀࠧࠣ") + l1ll1ll_thegroove).encode(l11_thegroove (u"ࠬࡻࡴࡧ࠯࠻ࠫࠤ"))
        else:
            l111ll_thegroove = base64.b64encode(l1ll_thegroove + l11_thegroove (u"࠭࠺࠻ࠩࠥ").encode(l11_thegroove (u"ࠢࡶࡶࡩ࠱࠽ࠨࠦ")) + l1ll1ll_thegroove).decode(l11_thegroove (u"ࠣࡷࡷࡪ࠲࠾ࠢࠧ"))
        l111ll_thegroove = l111ll_thegroove.replace(l11_thegroove (u"ࠤ࠮ࠦࠨ"), l11_thegroove (u"ࠥ࠲ࠧࠩ"))
        l111ll_thegroove = l111ll_thegroove.replace(l11_thegroove (u"ࠦ࠲ࠨࠪ"), l11_thegroove (u"ࠧ࠲ࠢࠫ"))
        l111ll_thegroove = l111ll_thegroove.replace(l11_thegroove (u"ࠨ࠯ࠣࠬ"), l11_thegroove (u"ࠢࡠࠤ࠭"))
        return l111ll_thegroove
    def l1l11l1_thegroove(self, data):
        if sys.version_info[0] < 3:
            __caller__ = sys._getframe().f_back.f_code.co_name
        else:
            __caller__ = inspect.stack()[1].function
        self.l1l1l1l_thegroove(__caller__)
        data = data.replace(l11_thegroove (u"ࠣ࠰ࠥ࠮"), l11_thegroove (u"ࠤ࠮ࠦ࠯"))
        data = data.replace(l11_thegroove (u"ࠥ࠰ࠧ࠰"), l11_thegroove (u"ࠦ࠲ࠨ࠱"))
        data = data.replace(l11_thegroove (u"ࠧࡥࠢ࠲"), l11_thegroove (u"ࠨ࠯ࠣ࠳"))
        try:
            res = base64.b64decode(data).split(l11_thegroove (u"ࠧ࠻࠼ࠪ࠴"))
            l1ll1ll_thegroove = res[len(res) - 1]
            l1lll1l_thegroove = l11_thegroove (u"ࠨࠩ࠵")
            for i in range(0, (len(res) - 1)):
                l1lll1l_thegroove += res[i]
            l1l_thegroove = l11_thegroove (u"ࠤࡐࡈࡨࡳࡷࡋࡵࡤࠦ࠶") + l11_thegroove (u"ࠥࡋࡶࡌࡎ࡛ࡍࡱࡸࠧ࠷") + l11_thegroove (u"ࠦࡒࡊࡣ࡮ࡹࡍࡷࡦࠨ࠸") + l11_thegroove (u"ࠧࡠࡤࡎࡗࡏ࡯ࡕࡘࠢ࠹") + l11_thegroove (u"ࠨࡡࡓ࡛࡝ࡴࡍ࡫ࡥࠣ࠺")
            l1l_thegroove = hashlib.sha256(l1l_thegroove).hexdigest()[:32].encode(l11_thegroove (u"ࠢࡶࡶࡩ࠱࠽ࠨ࠻"))
            if not self.l1l111_thegroove:
                cipher = AES.new(l1l_thegroove, AES.MODE_CFB, l1ll1ll_thegroove)
                l1llll_thegroove = cipher.decrypt(l1lll1l_thegroove)
            else:
                aes = pyaes.AESModeOfOperationCFB(l1l_thegroove, l1ll1ll_thegroove)
                l1llll_thegroove = aes.decrypt(l1lll1l_thegroove)
            sep = base64.b64encode(l11_thegroove (u"ࠣࠬ࠭ࠦ࠼")).encode(l11_thegroove (u"ࠤࡸࡸ࡫࠳࠸ࠣ࠽"))
            result, l1ll1l1_thegroove, l1lll1_thegroove = l1llll_thegroove.split(str(sep))
            if l1ll1l1_thegroove == str(self.l1ll1l1_thegroove):
                return result
            else:
                self.l11llll_thegroove(l11_thegroove (u"ࠥࡉࡷࡸ࡯ࡳࡧࠣ࠸࠵࠻ࠢ࠾"), l11_thegroove (u"ࠦࡎࡳࡰࡰࡵࡶ࡭ࡧ࡯࡬ࡦࠢࡆࡳࡲࡶ࡬ࡦࡶࡤࡶࡪࠦࡌࡢࠢࡕ࡭ࡨ࡮ࡩࡦࡵࡷࡥࠧ࠿"))
        except Exception as e:
            self.l11llll_thegroove(l11_thegroove (u"ࠧࡋࡲࡳࡱࡵࡩࠥ࠺࠰࠸ࠤࡀ"), l11_thegroove (u"ࠨࡉ࡮ࡲࡲࡷࡸ࡯ࡢࡪ࡮ࡨࠤࡈࡵ࡭ࡱ࡮ࡨࡸࡦࡸࡥࠡࡎࡤࠤࡗ࡯ࡣࡩ࡫ࡨࡷࡹࡧࠢࡁ"))
            import traceback
            traceback.print_stack()
            print(e)
        return None
    def l111l1_thegroove(self, skip=False):
        if skip is False:
            if sys.version_info[0] < 3:
                __caller__ = sys._getframe().f_back.f_code.co_name
            else:
                __caller__ = inspect.stack()[1].function
            self.l1l1l1l_thegroove(__caller__)
        try:
            l1ll1l_thegroove = xbmc.getInfoLabel(l11_thegroove (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡔࡱࡻࡧࡪࡰࡑࡥࡲ࡫ࠧࡂ"))
            l1ll1l_thegroove = xbmcaddon.Addon(l1ll1l_thegroove).getAddonInfo(l11_thegroove (u"ࠨࡰࡤࡱࡪ࠭ࡃ"))
            if l1ll1l_thegroove != self.l11ll_thegroove:
                raise Exception()
        except Exception as e:
            self.l11llll_thegroove(l11_thegroove (u"ࠤࡈࡶࡷࡵࡲࡦࠢ࠴ࠦࡄ"), l11_thegroove (u"ࠥࡊࡺࡴࡺࡪࡱࡱࡩࠥࡊࡩࡴࡲࡲࡲ࡮ࡨࡩ࡭ࡧࠣࡗࡴࡲ࡯ࠡࡕࡸࠦࡅ"), self.l11ll_thegroove + l11_thegroove (u"ࠦࠥࡇࡤࡥࡱࡱࠦࡆ"))
            return False
        try:
            l1ll11l_thegroove = xbmcaddon.Addon(id=self.name)
            xbmc.translatePath(l1ll11l_thegroove.getAddonInfo(l11_thegroove (u"ࠬࡶࡡࡵࡪࠪࡇ")))
        except:
            self.l11llll_thegroove(l11_thegroove (u"ࠨࡅࡳࡴࡲࡶࡪࠦ࠲ࠣࡈ"), l11_thegroove (u"ࠢࡇࡷࡱࡾ࡮ࡵ࡮ࡦࠢࡇ࡭ࡸࡶ࡯࡯࡫ࡥ࡭ࡱ࡫ࠠࡔࡱ࡯ࡳ࡙ࠥࡵࠣࡉ"), self.l11ll_thegroove + l11_thegroove (u"ࠣࠢࡄࡨࡩࡵ࡮ࠣࡊ"))
            return False
        try:
            l1ll11l_thegroove = xbmcaddon.Addon(id=self.name)
            cwd = xbmc.translatePath(l1ll11l_thegroove.getAddonInfo(l11_thegroove (u"ࠩࡳࡥࡹ࡮ࠧࡋ")))
            l1ll11_thegroove = l11_thegroove (u"ࠥࡶࡪࡹ࡯ࡶࡴࡦࡩࡸ࠲࡭ࡰࡦࡸࡰࡪࡹࠬࡪࡶࡨࡱࡤࡶࡡࡳࡵࡨࡶ࠳ࡶࡹࠣࡌ").split(l11_thegroove (u"ࠦ࠱ࠨࡍ"))
            l1llll1_thegroove = cwd + os.sep + os.path.join(*l1ll11_thegroove)
            if not os.path.isfile(l1llll1_thegroove):
                raise Exception()
        except:
            self.l11llll_thegroove(l11_thegroove (u"ࠧࡋࡲࡳࡱࡵࡩࠥ࠹ࠢࡎ"), l11_thegroove (u"ࠨࡆࡶࡰࡽ࡭ࡴࡴࡥࠡࡆ࡬ࡷࡵࡵ࡮ࡪࡤ࡬ࡰࡪࠦࡓࡰ࡮ࡲࠤࡘࡻࠢࡏ"), self.l11ll_thegroove + l11_thegroove (u"ࠢࠡࡃࡧࡨࡴࡴࠢࡐ"))
            return False
        return True
    def l1l1l1l_thegroove(self, l1l11ll_thegroove):
        if l1l11ll_thegroove != l11_thegroove (u"ࠣࡵࡨࡸࡤࡺ࡯࡬ࡧࡱࠦࡑ") and l1l11ll_thegroove != l11_thegroove (u"ࠤࡶࡩࡹࡥࡲࡦࡵࡸࡰࡹࠨࡒ"):
            raise Exception()
    def l11llll_thegroove(self, s1=l11_thegroove (u"ࠥࠦࡓ"), s2=l11_thegroove (u"ࠦࠧࡔ"), l1l1ll_thegroove=l11_thegroove (u"ࠧࠨࡕ")):
        try:
            xbmcgui.Dialog().ok(self.l11ll_thegroove, s1, s2, l1l1ll_thegroove)
        except:
            print(s1 + l11_thegroove (u"ࠨࠠࠣࡖ") + s2 + l11_thegroove (u"ࠢࠡࠤࡗ") + l1l1ll_thegroove)