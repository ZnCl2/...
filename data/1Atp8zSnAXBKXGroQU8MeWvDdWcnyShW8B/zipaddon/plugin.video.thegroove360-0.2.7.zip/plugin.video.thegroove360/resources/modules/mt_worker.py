import logging
import xbmcaddon
import xbmcgui
import xbmcplugin
from threading import Thread, Lock
from resources.modules.thegroove import support
from resources.lib import kodiutils

logger = logging.getLogger(xbmcaddon.Addon().getAddonInfo('id'))

try:
    import queue as mQueue
except ImportError:
    import Queue as mQueue


class MTWorker(Thread):

    def __init__(self, queue, fn, qsize, lock=None, show_progress=False, pb_dialog=None, *args, **kwargs):
        Thread.__init__(self, *args, **kwargs)
        self.queue = queue
        self.fn = fn
        self.lock = lock
        self.show_progress = show_progress
        self.pb_dialog = pb_dialog
        self.qsize = qsize
        self.stopped = False

    def stop(self):
        self.stopped = True

    def run(self):
        while True:
            if self.stopped:
                break
            if self.lock:
                with self.lock:
                    self.run_thread()
            else:
                self.run_thread()

    def run_thread(self):
        logger.debug("__________________ RUN THREAD ________________")
        try:
            logger.debug(self.stopped)
            if not self.stopped:
                params = self.queue.get()
                if params is None:
                    self.stop()
                    return self.queue.task_done()
                if type(params) == tuple:
                    self.fn(*params)
                else:
                    self.fn(params)
        except Exception as E:
            import traceback
            traceback.print_stack()
            logger.debug(E)
            raise
        finally:
            if self.show_progress:
                if self.pb_dialog.iscanceled():
                    self.queue.task_done()
                    self.stop()
                    from resources.lib.plugin import plugin
                    xbmcplugin.endOfDirectory(plugin.handle)
                    self.pb_dialog.close()
                    self.queue.task_done()
                    return

                # logger.debug(self.queue.unfinished_tasks)
                item_counter = self.qsize - self.queue.unfinished_tasks
                percent = int((item_counter * 100) / self.qsize)
                self.pb_dialog.update(percent, "Elaborando Elementi %s di %s" % (item_counter, self.qsize))
            if not self.stopped:
                self.queue.task_done()

    @staticmethod
    def set_jobs(queue, fn, use_lock=False, show_progress=False):
        logger.debug("_____________ SET JOBS ____________________")

        # logger.debug(show_progress)
        pb_dialog = xbmcgui.DialogProgress()
        if show_progress:
            addon_name = xbmcaddon.Addon().getAddonInfo('name')
            pb_dialog.create(addon_name, "Loading items")

        if queue.qsize() > 1000:
            use_lock = False

        if use_lock:
            lock = Lock()
        else:
            lock = None
        mt_list = ['Auto', 1, 2, 4, 8, 16]
        ncores = support.get_cores_num()
        max_threads = kodiutils.get_setting_as_int("max_threads")
        # logger.debug("MAX THREADS " + str(max_threads))
        if max_threads != 0:
            ncores = min(mt_list[max_threads], ncores)
        logger.debug("NCORES " + str(ncores))

        qsize = queue.qsize()
        threads = []
        for x in range(ncores):
            worker = MTWorker(queue, fn, qsize, lock=lock, show_progress=show_progress, pb_dialog=pb_dialog)
            worker.daemon = True
            worker.start()
            threads.append(worker)

        queue.join()

        for i in range(ncores):
            queue.put(None)

        for t in threads:
            t.stop()
            t.join()

        if show_progress:
            pb_dialog.close()
