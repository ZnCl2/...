# SPECTRA

This is the beta release of SPECTRA - an open source, 
LAMP compatible block chain explorer.

For an outline of the installation procedure see the file
'install.txt' located in the "doc" subdirectory.

For more detailed information see the file "readme.txt"
located in the "doc" subdirectory.

Example: http://dev.speccoin.com/spectra/

For issues, previous solved issues or questions visit https://github.com/SpecDevelopment/SPECTRA/issues

Developed by Jake Paysnoe (https://github.com/callmejake),
SPECTRA is licensed under the MIT Software license and 
Copyright © 2015 SPEC Development Team.
