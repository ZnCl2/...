#!/bin/bash
lualatex pyash-SPE
bibtex pyash-SPE
lualatex pyash-SPE
