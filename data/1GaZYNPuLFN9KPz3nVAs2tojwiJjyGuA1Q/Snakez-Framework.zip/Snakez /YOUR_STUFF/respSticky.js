$(window).load(function(){
     $("#header").sticky({ topSpacing: 0 });
});