#!/bin/bash

SOURCE="ZeroNet/"
TARGET="ZeroNet.app"
ICON="ZeroNet.icns"

mkdir -p "$TARGET/Contents/MacOS"
mkdir -p "$TARGET/Contents/Resources"

cat <<EOF >"$TARGET/Contents/Info.plist"
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>CFBundleExecutable</key>
    <string>run.sh</string>
    <key>CFBundleIconFile</key>
    <string>ZeroNet.icns</string>
    <key>CFBundleInfoDictionaryVersion</key>
    <string>1.0</string>
    <key>CFBundlePackageType</key>
    <string>APPL</string>
    <key>CFBundleSignature</key>
    <string>????</string>
    <key>CFBundleVersion</key>
    <string>1.0</string>
</dict>
</plist>
EOF

cp -R $SOURCE "$TARGET/Contents/MacOS"
mv "$TARGET/Contents/MacOS/ZeroNet.app" "$TARGET/Contents/MacOS/run.sh"
cp $ICON "$TARGET/Contents/Resources/"
chmod 755 "$TARGET/Contents/MacOS/run.sh"
