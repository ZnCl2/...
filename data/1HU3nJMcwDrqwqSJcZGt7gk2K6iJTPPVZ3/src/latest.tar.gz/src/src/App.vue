<template>
  <div class="container">
    <div v-if="adminPermission && loaded">
      <div class="header" v-if="currentView.header !== false">
        <select class="view-chooser" v-model="chosenViewName" @change="viewChosen" v-if="chooseView">
          <option :value="k" v-for="v, k in views">{{k}} - {{v.description}}</option>
        </select>
        <span class="current-view"
              @click="beginChooseView"
              :title="`${currentView.description} - Click to change view`"
              v-else>
          {{ currentView.header || "Greetings ZeroNet_" }}
        </span>
      </div>
      <view-module-loader :modelData="modelData" :options="currentView">
    </view-module-loader>
    </div>
    <div class="permission-warning" v-else>
      <div v-if="adminPermission == null">
        Checking admin permission...
      </div>
      <div v-else-if="adminPermission === false">
        <h1>Welcome to ZeroGreeter,</h1>
        <h2>a tag-based ZeroHello replacement with a customizable interface.</h2>
        <p>It looks like this is your first time here. Please read the following carefully before proceeding.</p>
        <hr>
        <p>ZeroGreeter requires the <strong>ADMIN</strong> permission to list your sites and feed.</p>
        <p>
          Sites with <strong>ADMIN</strong> permission may do everything <strong>ZeroHello</strong> is capable of.
          As you can see, it is not a good idea to entrust random sites with it.
        </p>
        <p>
          This is why ZeroGreeter is not simply asking you for the permission here.
          Instead, you should head into its data folder, and find its source under 'src'.
        </p>
        <p>
          <strong>
            Audit the source, and build your own ZeroGreeter site according to the instructions.
          </strong>
          The developer(s) are not going to take any responsibility for your own actions.
          Use at your own risk.
        </p>
        <p v-if="pace">
          This file was built with PACE = <strong>{{ pace }}</strong>.
          <span v-if="paceIsPreset">It does <strong>not</strong> look like you built it yourself.</span>
        </p>
        <hr>
        <div v-if="isOwn">
          <p>
            The site sees you as the owner.
            but please really make sure that you built this code before clicking this.
          </p>
          <p><button @click="requestPermission">Request ADMIN permission</button></p>
        </div>
        <div v-else>
          <p>You won't be able to proceed unless you are the owner of this site.</p>
          <p>
            If you really, <em>really,</em> <em><strong>really</strong></em> just want to use a prebuilt version,
            you may just flip "This is my site" in the sidebar.
            <strong>Be warned that this totally not good to do, though.</strong>
            You are at your own risk.
          </p>
        </div>
      </div>
      <div v-else>
        Loading...
      </div>
    </div>
  </div>
</template>

<script>
import api from 'src/api';
import tagging from 'src/tagging';
import config from 'src/config';
import { extend } from 'src/utils';
import { ViewModuleLoader } from 'src/view';

import presetPaces from 'src/paces';

export default {
  name: 'app',
  data () {
    return {
      isOwn: null,
      adminPermission: null,
      loaded: false,
      sites: [],
      siteLookup: {},
      feed: [],
      siteFeed: {},
      currentViewName: 'hello',
      chosenViewName: 'hello',
      chooseView: false,
      pace: GREETER.pace
    };
  },
  methods: {
    async init () {
      this.setViewport();
      this.loaded = false;
      if(await this.checkPermission()) {
        await config.init();
        await tagging.init();
        await this.fetchSiteList();
        await this.fetchFeed();
        this.currentViewName = this.chosenViewName = config.misc.value.view;
        this.loaded = true;
      }
    },
    async setViewport () {
      api.wrapperSetViewport('width=device-width, initial-scale=1.0');
    },
    async checkPermission () {
      const info = await api.siteInfo();
      if (!info.settings.own) {
        this.isOwn = false;
        return this.adminPermission = false;
      }
      else {
        this.isOwn = true;
      }
      this.adminPermission = info.settings.permissions.indexOf('ADMIN') > -1;
      return this.adminPermission;
    },
    async requestPermission () {
      if (!this.isOwn)
        return false;
      if (!this.adminPermission) {
        const result = await api.wrapperPermissionAdd("ADMIN");
        this.adminPermission = (result === "Granted");
      }
      await this.init();
    },
    async fetchSiteList () {
      const sites = await api.siteList();
      for (const s of sites) {
        this.siteLookup[s.address] = s;
        if (s.content.domain != null)
          this.siteLookup[s.content.domain] = s;
      }
      for (const s of sites) {
        s.tags = this.tags(s);
        s.summary = [s.address, s.content.domain || '', s.content.title,
                     s.content.description, Object.keys(s.tags).join(',')]
                     .join('|').toLowerCase();
        const options = {};
        const rules = config.tags.value.rules;
        for (const t in s.tags) {
          if (rules[t] != null) {
            for (const k in rules[t]) {
              if (options[k] != null) continue;
              options[k] = rules[t][k];
            }
          }
        }
        s.options = extend({ display: true }, options);
      }
      this.sites = sites;
    },
    async fetchFeed () {
      let feed = await api.feedQuery([config.misc.value.feedQueryLimit, config.misc.value.feedQueryDays]);
      if (feed.hasOwnProperty('rows'))
        feed = feed.rows;

      const siteFeed = {};
      for (const f of feed) {
        if (siteFeed[f.site] == null)
          siteFeed[f.site] = [];
        siteFeed[f.site].push(f);
      }

      this.feed = feed;
      this.siteFeed = siteFeed;
    },
    tags (site) {
      return tagging.tags(site, this.modelData);
    },
    beginChooseView () {
      this.chooseView = true;
    },
    viewChosen () {
      config.misc.patch({ view: this.chosenViewName });
      this.currentViewName = this.chosenViewName;
      this.chooseView = false;
    }
  },
  computed: {
    modelData () {
      return {
        sites: this.sites,
        siteLookup: this.siteLookup,
        feed: this.feed,
        siteFeed: this.siteFeed
      };
    },
    paceIsPreset () {
      return presetPaces[this.pace] != null;
    },
    views () {
      return config.views.value || {};
    },
    currentView () {
      return config.views.value[this.currentViewName] || config.views.value.hello;
    }
  },
  mounted () {
    this.init();
  },
  components: {
    ViewModuleLoader
  }
};
</script>

<style lang="less">
@import "~theme";
.theme({
  @global();
});
</style>

<style lang="less" scoped>
@import "~theme";
.theme({
  @com-app();
});
</style>
