const entries = {};

export default {
  add (entry) {
    if (entries[entry.type] == null)
      entries[entry.type] = [];
    entries[entry.type].push(entry);
  },
  get () {
    return entries;
  }
};
