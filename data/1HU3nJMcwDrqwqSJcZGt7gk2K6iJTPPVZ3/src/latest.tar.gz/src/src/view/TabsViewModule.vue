<template>
  <div class="tabs-container" :class="[options.style || 'top']">
    <div class="tab-bar">
      <div class="tab-bar-item" :class="{ current: i === currentTab }"
           v-for="mod, i in options.tabs">
        <span class="header" @click="setTab(i)">{{ mod.header || `Tab ${i + 1}` }}</span>
      </div>
    </div>
    <div class="switcher">
      <span class="prev" @click="prevTab"></span>
      <span class="next" @click="nextTab"></span>
    </div>
    <div class="tab-body" v-for="mod, i in options.tabs" v-show="i === currentTab">
      <view-module-loader :modelData="modelData" :options="mod">
      </view-module-loader>
    </div>
  </div>
</template>

<script>
import ViewModuleLoader from 'src/view/ViewModuleLoader.vue';
import { register } from './components';

import doc from 'src/doc';

doc.add({
  type: 'view-module',
  name: 'tabs',
  summary: 'switch from multiple view modules',
  options: [
    {
      name: 'style',
      type: 'String (Enum)',
      summary: '(theme dependent) change the appearance of the switching mechanism',
      enum: [
        { name: 'top',        summary: 'tab bar on top' },
        { name: 'side',       summary: 'tab bar on side' },
        { name: 'noswitcher', summary: 'do not show switchers' },
      ]
    },
    {
      name: 'initial',
      type: 'Integer (index of initial tab to display)'
    },
    {
      name: 'tabs',
      type: 'Array [View Module Options]'
    }
  ]
});

export default register({
  name: 'tabs-view-module',
  data () {
    return {
      currentTab: this.options.initial || 0
    };
  },
  props: ['modelData', 'options'],
  methods: {
    nextTab () {
      if (this.currentTab < this.options.tabs.length - 1)
        this.currentTab = this.currentTab + 1;
    },
    prevTab () {
      if (this.currentTab > 0)
        this.currentTab = this.currentTab - 1;
    },
    setTab (i) {
      this.currentTab = i;
    }
  },
  mounted () {
  },
  components: {
    ViewModuleLoader
  }
});
</script>

<style lang="less" scoped>
@import "~theme";
.theme({
  @com-tabs-view-module();
});
</style>
