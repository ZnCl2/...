<template>
  <div class="container">
    <div class="header">Palettes</div>
    <div class="palette-list">
      <div class="palette-list-item" :class="{ highlight: p.name === palette }" v-for="p in palettes">
        <div class="palette-name" @click="setPalette(p.name)">{{ p.name }}</div>
        <span class="palette-preview" :class="[ p.name, theme ]">
          <span class="palette-preview-block page-bg"></span>
          <span class="palette-preview-block card-bg"></span>
          <span class="palette-preview-block accent"></span>
          <span class="palette-preview-block card-shadow"></span>
          <span class="palette-preview-block text"></span>
          <span class="palette-preview-block text-sub"></span>
          <span class="palette-preview-block text-accent"></span>
          <span class="palette-preview-block text-active"></span>
        </span>
        <span class="palette-description">{{ p.description }}</span>
      </div>
    </div>
    <div class="header">Themes</div>
    <div class="palette-list">
      <div class="palette-list-item" :class="{ highlight: t.name === theme }" v-for="t in themes">
        <div class="palette-name" @click="setTheme(t.name)">{{ t.name }}</div>
        <span class="palette-description">{{ t.description }}</span>
      </div>
    </div>
  </div>
</template>

<script>
import config from 'src/config';
import { register } from './components';

import doc from 'src/doc';

doc.add({
  type: 'view-module',
  name: 'palette-chooser',
  summary: '(config module) display a palette chooser'
});

export default register({
  name: 'palette-chooser-view-module',
  data () {
    return {
      currentPalette: null,
      currenTheme: null,
      palettes: [
        {
          name: 'eternal',
          description: 'The color palette of the Internet.'
        },
        {
          name: 'emotional',
          description: 'Warm light color palette.'
        },
        {
          name: 'ebullient',
          description: 'Cheerful dark color palette.'
        }
      ],
      themes: [
        {
          name: 'feather',
          description: 'Clean looks, sans superfluous animations.'
        }
      ]
    };
  },
  props: ['modelData', 'options'],
  methods: {
    setPalette (palette) {
      this.currentPalette = palette;
      config.misc.patch({ palette });
    },
    setTheme (theme) {
      this.currenTheme = theme;
      config.misc.patch({ theme });
    }
  },
  computed: {
    theme () {
      return this.currentTheme || config.misc.value.theme || 'feather';
    },
    palette () {
      return this.currentPalette || config.misc.value.palette || 'eternal';
    }
  },
  mounted () {
  },
  components: {
  }
});
</script>

<style lang="less" scoped>
@import "~theme";
.theme({
  @com-palette-chooser-view-module();
});
</style>
