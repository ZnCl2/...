<template>
  <div class="container">
    <div class="header" v-if="options.limit || options.header !== false">
      <span class="title" v-if="options.header !== false">{{ header }}</span>
      <span class="pager" v-if="options.limit && this.sortedSites.length > options.limit">
        <span class="prev" @click="prevPage"></span>
        <span class="next" @click="nextPage"></span>
      </span>
    </div>
    <input class="filter" type="text" v-model="filter" placeholder="filter" v-if="options.editable">
    <div class="site-list" :class="[options.style || 'details']">
      <div class="site-list-item" v-for="s in currentPage"
                                  :class="{ highlight: showHighlight && s.options.highlight }">
        <div class="site-basic-info">
          <a class="site-link" :href="`/${s.content.domain || s.address}`"
                               :title="s.content.description">{{ s.content.title }}</a>
          <span class="site-update-time" :title="time(s.settings.modified)">{{ timeFromNow(s.settings.modified) }}</span>
          <span class="site-peers">{{ s.peers }}</span>
        </div>
        <span class="site-description">{{ s.content.description }}</span>
        <span class="site-tags">{{ Object.keys(s.tags).map((s) => `#${s}`).join(', ') }}</span>
      </div>
    </div>
  </div>
</template>

<script>
import api from 'src/api';
import { filterSites } from 'src/filtering';
import moment from 'moment';
import { register } from './components';

import doc from 'src/doc';

doc.add({
  type: 'view-module',
  name: 'site-list',
  summary: 'display a filtered site list',
  options: [
    {
      name: 'style',
      type: 'String (Enum)',
      summary: '(theme dependent) change the way the module looks',
      enum: [
        { name: 'details', summary: 'show all information, including feed body' },
        { name: 'list',    summary: 'show basic information' },
        { name: 'columns', summary: 'arrange entries in columns' },
        { name: 'nopeers', summary: 'do not show peer count' }
      ]
    },
    { name: 'filter', type: 'String (Filter)' },
    {
      name: 'header',
      type: 'String | false',
      summary: 'supply an custom header instead of the filter'
    },
    {
      name: 'limit',
      type: 'undefined | Integer',
      summary: 'number of entries to display per page'
    },
    {
      name: 'showHidden',
      type: 'Boolean',
      summary: 'show feed from hidden sites'
    },
    {
      name: 'showHighlight',
      type: 'Boolean',
      summary: 'show highlights'
    }
  ]
});

export default register({
  name: 'site-list-view-module',
  data () {
    return {
      filter: null,
      sortedSitesCache: null,
      page: 0
    };
  },
  props: ['modelData', 'options'],
  methods: {
    setFilter () {
      this.filter = this.options.filter;
      this.sortedSitesCache = null;
    },
    timeFromNow (timestamp) {
      return moment.unix(timestamp).fromNow();
    },
    time (timestamp) {
      return moment.unix(timestamp).local().format('lll');
    },
    nextPage () {
      if (!this.options.limit)
        return;
      const page = this.page + 1;
      if (page * this.options.limit < this.sortedSites.length)
        this.page = page;
    },
    prevPage () {
      if (!this.options.limit)
        return;
      if (this.page > 0)
        this.page = this.page - 1;
    }
  },
  computed: {
    filteredSites () {
      return filterSites(this.modelData, this.filter);
    },
    sortedSites () {
      if (this.sortedSitesCache)
        return this.sortedSitesCache;
      const sites = this.filteredSites.filter((s) => this.options.showHidden || s.options.display);
      const sort = this.sort;
      if (sort === 'peers') {
        return sites.sort((a, b) => b.peers - a.peers);
      }
      if (sort === 'title') {
        return sites.sort((a, b) => {
          const titleA = a.content.title.toUpperCase();
          const titleB = b.content.title.toUpperCase();
          if (titleA < titleB) return -1;
          if (titleA > titleB) return 1;
          return 0;
        });
      }
      if (sort === 'modified') {
        return sites.sort((a, b) => b.settings.modified - a.settings.modified);
      }
      return this.sortedSitesCache = sites;
    },
    currentPage () {
      if (!this.options.limit)
        return this.sortedSites;
      const base = this.page * this.options.limit;
      return this.sortedSites.slice(base, base + this.options.limit);
    },
    sort () {
      if (this.options.sort == null)
        return 'peers';
      return this.options.sort;
    },
    header () {
      return this.options.header || this.filter || '';
    },
    showHighlight () {
      if (this.options.showHighlight == null)
        return true;
      return this.options.showHighlight;
    }
  },
  mounted () {
    this.setFilter();
  },
  watch: {
    'options': 'setFilter',
    'modelData': 'setFilter'
  },
  components: {
  }
});
</script>

<style lang="less" scoped>
@import "~theme";
.theme({
  @com-site-list-view-module();
});
</style>
