
import DocViewModule from 'src/view/DocViewModule.vue';
import FeedListViewModule from 'src/view/FeedListViewModule.vue';
import PaletteChooserViewModule from 'src/view/PaletteChooserViewModule.vue';
import PanelsViewModule from 'src/view/PanelsViewModule.vue';
import SiteListViewModule from 'src/view/SiteListViewModule.vue';
import TabsViewModule from 'src/view/TabsViewModule.vue';

import ViewModuleLoader from 'src/view/ViewModuleLoader.vue';

export { ViewModuleLoader };
