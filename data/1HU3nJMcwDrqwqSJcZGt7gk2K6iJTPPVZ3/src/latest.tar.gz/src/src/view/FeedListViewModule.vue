<template>
  <div class="feed-list-view-container">
    <div class="header" v-if="options.limit || options.header !== false">
      <span class="title" v-if="options.header !== false">{{ header }}</span>
      <span class="pager" v-if="readFeed != null">
        <span class="back" @click="readFeed = null"></span>
        <span class="prev" @click="prevFeed"></span>
        <span class="next" @click="nextFeed"></span>
      </span>
      <span class="pager" v-else-if="options.limit && this.filteredFeed.length > options.limit">
        <span class="prev" @click="prevPage"></span>
        <span class="next" @click="nextPage"></span>
      </span>
    </div>
    <div class="feed-list" :class="[options.style || 'details']" v-if="readFeed == null">
      <div class="feed-list-item" v-for="f, id in currentPage">
        <div class="feed-basic-info">
          <a class="feed-site-link"
             :href="`/${modelData.siteLookup[f.site].content.domain || f.site}`"
             :title="modelData.siteLookup[f.site].content.description">
            {{ modelData.siteLookup[f.site].content.title }}
          </a>
          <span class="feed-site-link-separator"></span>
          <a class="feed-link" :href="`/${modelData.siteLookup[f.site].content.domain || f.site}/${f.url}`"
                               :title="f.feed_name"
                               @click="onFeedClick($event, page * options.limit + id)">{{ f.title }}</a>
          <span class="feed-time" :title="time(f.date_added)">{{ timeFromNow(f.date_added) }}</span>
        </div>
        <span class="feed-body">{{ f.body }}</span>
      </div>
    </div>
    <div class="feed-reader" :class="[options.style || 'details']" v-else>
      <div class="feed-basic-info">
        <a class="feed-site-link"
           :href="`/${modelData.siteLookup[readFeedData.site].content.domain || readFeedData.site}`"
           :title="modelData.siteLookup[readFeedData.site].content.description">
          {{ modelData.siteLookup[readFeedData.site].content.title }}
        </a>
        <span class="feed-site-link-separator"></span>
        <a class="feed-link" :href="`/${modelData.siteLookup[readFeedData.site].content.domain || readFeedData.site}/${readFeedData.url}`"
                             :title="readFeedData.feed_name">{{ readFeedData.title }}</a>
        <span class="feed-time" :title="time(readFeedData.date_added)">{{ timeFromNow(readFeedData.date_added) }}</span>
      </div>
      <div class="feed-body" v-html="feedMarkdown(readFeed)">
      </div>
    </div>
  </div>
</template>

<script>
import doc from 'src/doc';

doc.add({
  type: 'view-module',
  name: 'feed-list',
  summary: 'display a filtered feed',
  options: [
    {
      name: 'style',
      type: 'String (Enum)',
      summary: '(theme dependent) change the way the module looks',
      enum: [
        { name: 'details', summary: 'show all information, including feed body' },
        { name: 'list',    summary: 'show basic information' },
        { name: 'nosite',  summary: 'do not show source site' }
      ]
    },
    { name: 'filter', type: 'String (Filter)' },
    {
      name: 'header',
      type: 'String | false',
      summary: 'supply an custom header instead of the filter'
    },
    {
      name: 'limit',
      type: 'undefined | Integer',
      summary: 'number of entries to display per page'
    },
    {
      name: 'type',
      type: 'undefined | String (ZeroNet feed type)',
      summary: 'only show entries of a specific type'
    },
    {
      name: 'showHidden',
      type: 'Boolean',
      summary: 'show feed from hidden sites'
    },
    {
      name: 'reader',
      type: 'Boolean',
      summary: 'instead of following feed url, show feed body in internal markdown reader'
    }
  ]
});

import api from 'src/api';
import { filterSites } from 'src/filtering';
import moment from 'moment';
import { register } from './components';

import marked from 'marked';

export default register({
  name: 'feed-list-view-module',
  data () {
    return {
      filter: null,
      filteredFeedCache: null,
      page: 0,
      readFeed: null
    };
  },
  props: ['modelData', 'options'],
  methods: {
    setFilter () {
      this.filter = this.options.filter;
      this.filteredFeedCache = null;
    },
    timeFromNow (timestamp) {
      return moment.unix(timestamp).fromNow();
    },
    time (timestamp) {
      return moment.unix(timestamp).local().format('lll');
    },
    nextPage () {
      if (!this.options.limit)
        return;
      const page = this.page + 1;
      if (page * this.options.limit < this.filteredFeed.length)
        this.page = page;
    },
    prevPage () {
      if (!this.options.limit)
        return;
      if (this.page > 0)
        this.page = this.page - 1;
    },
    async nextFeed () {
      const readFeed = this.readFeed + 1;
      if (readFeed < this.filteredFeed.length) {
        await api.permissionAdd(`Cors:${this.filteredFeed[readFeed].site}`);
        this.readFeed = readFeed;
      }
    },
    async prevFeed () {
      if (this.readFeed > 0) {
        await api.permissionAdd(`Cors:${this.filteredFeed[this.readFeed - 1].site}`);
        this.readFeed = this.readFeed - 1;
      }
    },
    async onFeedClick (ev, i) {
      if (this.options.reader !== true)
        return;
      ev.preventDefault();
      await api.permissionAdd(`Cors:${this.filteredFeed[i].site}`);
      this.readFeed = i;
    },
    feedMarkdown (i) {
      if (i == null)
        return "";
      const feed = this.filteredFeed[i];
      if (feed == null)
        return "";

      const renderer = new marked.Renderer();
      const renderImage = renderer.image;
      renderer.image = (href, title, text) => {
        href = href.replace('http://127.0.0.1:43110', '');
        if (href.indexOf('://') < 0 && href[0] !== '/')
          href = `cors-${feed.site}/${href}`;
        return renderImage.call(renderer, href, title, text);
      };
      const renderLink = renderer.link;
      renderer.link = (href, title, text) => {
        href = href.replace('http://127.0.0.1:43110', '');
        if (href.indexOf('://') < 0 && href[0] !== '/')
          href = `/${this.modelData.siteLookup[feed.site].content.domain || feed.site}/${href}`;
        return renderLink.call(renderer, href, title, text);
      };
      marked.setOptions({
        renderer: renderer,
        gfm: true,
        tables: true,
        breaks: false,
        pedantic: false,
        sanitize: true,
        smartLists: true,
        smartypants: false
      });

      return marked(feed.body);
    }
  },
  computed: {
    filteredFeed () {
      if (this.filteredFeedCache)
        return this.filteredFeedCache;
      const sites = this.filteredSites;
      const feed = [];
      for (const s of sites) {
        if (this.modelData.siteFeed[s.address] == null)
          continue;
        if (!(s.options.display || this.options.showHidden))
          continue;
        for (const f of this.modelData.siteFeed[s.address]) {
          if (this.options.type == null || f.type === this.options.type)
            feed.push(f);
        }
      }
      this.filteredFeedCache = feed.sort((a, b) => b.date_added - a.date_added);
      return this.filteredFeedCache;
    },
    currentPage () {
      if (!this.options.limit)
        return this.filteredFeed;
      const base = this.page * this.options.limit;
      return this.filteredFeed.slice(base, base + this.options.limit);
    },
    filteredSites () {
      return filterSites(this.modelData, this.filter);
    },
    header () {
      return this.options.header || `@${this.options.type || ''} ${this.filter || ''}`;
    },
    readFeedData () {
      if (this.readFeed == null)
        return null;
      return this.filteredFeed[this.readFeed];
    }
  },
  mounted () {
    this.setFilter();
  },
  watch: {
    'options': 'setFilter',
    'modelData': 'setFilter'
  },
  components: {
  }
});
</script>

<style lang="less">
@import "~theme";
.theme({
  @com-feed-list-view-module();
});
</style>
