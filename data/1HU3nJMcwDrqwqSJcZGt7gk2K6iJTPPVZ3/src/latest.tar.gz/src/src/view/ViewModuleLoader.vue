<template>
  <component :is="`${options.layout}-view-module`" :modelData="modelData" :options="options">
  </component>
</template>

<script>
import { components } from './components';

export default {
  name: 'view-module-loader',
  data () {
    return {
    };
  },
  props: ['modelData', 'options'],
  methods: {
  },
  mounted () {
  },
  components
};
</script>
