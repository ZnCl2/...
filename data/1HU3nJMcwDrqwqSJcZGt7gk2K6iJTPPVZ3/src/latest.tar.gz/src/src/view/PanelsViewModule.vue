<template>
  <div class="panels-container" :class="[options.style || 'plain']">
    <div class="panel" v-for="mod in options.modules">
      <view-module-loader :modelData="modelData" :options="mod">
      </view-module-loader>
    </div>
  </div>
</template>

<script>
import ViewModuleLoader from 'src/view/ViewModuleLoader.vue';
import { register } from './components';

import doc from 'src/doc';

doc.add({
  type: 'view-module',
  name: 'panels',
  summary: 'combine multiple view modules into one',
  options: [
    {
      name: 'style',
      type: 'String (Enum)',
      summary: '(theme dependent) change the way the modules are arranged',
      enum: [
        { name: 'plain',    summary: 'arrange in a most natural way' },
        { name: 'list',     summary: 'arrange in a sequence' },
        { name: 'grids',    summary: 'arrange in a grid' },
        { name: 'uneven-1', summary: '(when using grids) use an uneven grid' },
        { name: 'uneven-2', summary: '(when using grids) use an alternative uneven grid' },
        { name: 'side',     summary: 'enlarge first module, group the rest' },
        { name: 'inv',      summary: '(when using side) switch sides' }
      ]
    },
    {
      name: 'modules',
      type: 'Array [View Module Options]'
    }
  ]
});

export default register({
  name: 'panels-view-module',
  data () {
    return {
    };
  },
  props: ['modelData', 'options'],
  methods: {
  },
  mounted () {
  },
  components: {
    ViewModuleLoader
  }
});
</script>

<style lang="less" scoped>
@import "~theme";
.theme({
  @com-panels-view-module();
});
</style>
