
export const components = {};

export const register = (com) => {
  components[com.name] = com;
  return com;
};
