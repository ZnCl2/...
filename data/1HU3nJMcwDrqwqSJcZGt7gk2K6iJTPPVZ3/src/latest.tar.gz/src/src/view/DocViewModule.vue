<template>
  <div class="container">
    <div class="header">
      <select class="type-chooser" v-model="type">
        <option :value="t" v-for="l, t in docs">{{t}} ({{ l.length }})</option>
      </select>
    </div>
    <div class="doc-list">
      <div class="doc-list-item" v-for="doc in docs[type]">
        <h1>{{ doc.name }}</h1>
        <p class="summary">{{ doc.summary }}</p>
        <p class="remarks" v-if="doc.remarks">{{ doc.remarks }}</p>
        <ul class="options" v-if="doc.options">
          <li v-for="opt in doc.options">
            <h2 class="option">
              <span class="name">{{ opt.name }}</span>
              <span class="type">{{ opt.type }}</span>
            </h2>
            <p class="summary">{{ opt.summary }}</p>
            <p class="remarks" v-if="opt.remarks">{{ opt.remarks }}</p>
            <ul class="enum" v-if="opt.enum">
              <li v-for="val in opt.enum">
                <h3 class="value">{{ val.name }}</h3>
                <p class="summary">{{ val.summary }}</p>
                <p class="remarks" v-if="val.remarks">{{ val.remarks }}</p>
              </li>
            </ul>
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>

<script>
import { register } from './components';

import doc from 'src/doc';

doc.add({
  type: 'view-module',
  name: 'doc',
  summary: 'show ZeroGreeter documentation',
  options: [
    {
      name: 'type',
      type: 'String',
      summary: 'initial type of documentation to display'
    }
  ]
});

export default register({
  name: 'doc-view-module',
  data () {
    return {
      type: this.options.type || 'config'
    };
  },
  props: ['modelData', 'options'],
  computed: {
    docs () {
      return doc.get();
    }
  },
  mounted () {
  },
  components: {
  }
});
</script>

<style lang="less" scoped>
@import "~theme";
.theme({
  @com-doc-view-module();
});
</style>
