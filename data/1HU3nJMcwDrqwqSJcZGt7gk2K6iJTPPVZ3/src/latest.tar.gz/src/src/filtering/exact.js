import doc from 'src/doc';

doc.add({
  type: 'filter',
  name: 'exact',
	summary: 'match a single site by its address or domain',
  remarks: 'case sensitive. this filter is very efficient because it performs a hashtable lookup',
  options: [
    {
      name: '!<address>'
    },
    {
      name: '!<domain>'
    }
  ]
});

const predicate = (site, pattern) => {
  return site.address === pattern || site.content.domain === pattern;
};

const filterSites = (modelData, pattern) => {
  const site = modelData.siteLookup[pattern];
  if (site != null)
    return [site];
  return [];
};

export default {
  prefix: '!',
  predicate,
  filterSites
};
