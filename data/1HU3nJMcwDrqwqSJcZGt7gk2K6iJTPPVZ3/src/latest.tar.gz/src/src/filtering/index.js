
import tag   from './tag';
import expr  from './expr';
import exact from './exact';
import regex from './regex';

const filters = [
  exact,
  expr,
  tag,
  regex
];

import doc from 'src/doc';

doc.add({
  type: 'filter',
  name: 'simple',
	summary: 'match a substring on site summaries',
  remarks: 'used when no prefix matches. case insensitive. site summaries include address, domain, title, description, and tags',
  options: [
    {
      name: '<substring>'
    }
  ]
});

const runSimpleFilter = (sites, pattern) => {
  return sites.filter((s) => {
    return s.summary.indexOf(pattern) > -1;
  });
};

export const predicate = (site, pattern) => {
  if (pattern == null)
    return true;
  for (const f of filters) {
    if (pattern[0] === f.prefix) {
      return f.predicate(site, pattern.slice(1));
    }
  }
  return site.summary.indexOf(pattern.toLowerCase()) > -1;
};

export const filterSites = (modelData, pattern) => {
  if (pattern == null)
    return modelData.sites;
  for (const f of filters) {
    if (pattern[0] === f.prefix) {
      const p = pattern.slice(1);
      if (f.filterSites) {
        return f.filterSites(modelData, p);
      }
      else {
        return modelData.sites.filter((s) => f.predicate(s, p));
      }
    }
  }
  return runSimpleFilter(modelData.sites, pattern.toLowerCase());
};

export default {
  predicate,
  filterSites
};
