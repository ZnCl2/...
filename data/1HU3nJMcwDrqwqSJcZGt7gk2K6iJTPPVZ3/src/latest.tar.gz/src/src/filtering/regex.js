import doc from 'src/doc';

doc.add({
  type: 'filter',
  name: 'regex',
	summary: 'match a regular expression on site summaries',
  remarks: 'case insensitive. site summaries include address, domain, title, description, and tags',
  options: [
    {
      name: '~<regexp>',
      remarks: 'returns nothing when <regexp> is invalid'
    }
  ]
});

const predicate = (site, pattern) => {
  try {
    const regex = new RegExp(pattern, 'iu');
    return regex.test(site.summary);
  }
  catch (e) {
    console.log(`[ZeroGreeter: regex filter] filter "${pattern}" failed to parse: ${e.message}`);
    return false;
  }
};

const filterSites = (modelData, pattern) => {
  try {
    const regex = new RegExp(pattern, 'iu');
    return modelData.sites.filter((s) => {
      return regex.test(s.summary);
    });
  }
  catch (e) {
    console.log(`[ZeroGreeter: regex filter] filter "${pattern}" failed to parse: ${e.message}`);
    return [];
  }
};

export default {
  prefix: '~',
  predicate,
  filterSites
};
