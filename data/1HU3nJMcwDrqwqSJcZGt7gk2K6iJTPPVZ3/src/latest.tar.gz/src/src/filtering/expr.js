import doc from 'src/doc';

doc.add({
  type: 'filter',
  name: 'expr',
	summary: 'evaluate a JS expression or function',
  remarks: 'siteInfo is available under "site", function to run another filter is available as "filter(pattern)" or "$(pattern)"',
  options: [
    {
      name: '$(<expr>)',
      summary: 'the filter matches if <expr> evaluated to exactly "true"'
    },
    {
      name: '${<func>}',
      summary: 'the filter matches if <func> returns exactly "true"'
    }
  ]
});

import filtering from 'src/filtering';

const parsePattern = (pattern) => {
  if (pattern[0] === '(') {
    if (pattern[pattern.length - 1] === ')') {
      try {
        return new Function('site', 'filter', '$', `return ${pattern.slice(1, pattern.length - 1)};`);
      }
      catch (e) {
        console.log(`[ZeroGreeter: expr filter] filter "${pattern}" failed to parse: ${e.message}`);
        return null;
      }
    }
  }
  if (pattern[0] === '{') {
    if (pattern[pattern.length - 1] === '}') {
      try {
        return new Function('site', 'filter', '$', pattern.slice(1, pattern.length - 1));
      }
      catch (e) {
        console.log(`[ZeroGreeter: expr filter] filter "${pattern}" failed to parse: ${e.message}`);
        return null;
      }
    }
  }
  return null;
};

const predicate = (site, pattern) => {
  let fn = parsePattern(pattern);
  if (fn == null) {
    return false;
  }
  try {
    const filter = (p) => filtering.predicate(site, p);
    return fn(site, filter, filter) === true;
  }
  catch (e) {
    console.log(`[ZeroGreeter: expr filter] filter "${pattern}" thrown exception: ${e.message}`);
    return false;
  }
};

const filterSites = (modelData, pattern) => {
  let fn = parsePattern(pattern);
  if (fn == null) {
    return [];
  }
  try {
    return modelData.sites.filter((s) => {
      const filter = (p) => filtering.predicate(s, p);
      return fn(s, filter, filter) === true;
    });
  }
  catch (e) {
    console.log(`[ZeroGreeter: expr filter] filter "${pattern}" thrown exception: ${e.message}`);
    return [];
  }
};

export default {
  prefix: '$',
  predicate,
  filterSites
};
