import doc from 'src/doc';

doc.add({
  type: 'filter',
  name: 'tag',
	summary: 'return sites with tags that match the rules',
  remarks: 'rules also used for "imply" plugin, without the "#" prefix',
  options: [
    {
      name: '#<name>',
      summary: 'tags with the exact name',
      remarks: 'include ":" in <name> for namespaced tags'
    },
    {
      name: '#<namespace>:',
      summary: 'namespaced tags with the exact namespace'
    },
    {
      name: '#:<name>',
      summary: 'namespaced tags with the exact name'
    },
    {
      name: '#~<regex>',
      summary: 'tags that match the regex',
      remarks: 'case sensitive',
    }
  ]
});

import { matchTag } from 'src/utils';

const predicate = (s, pattern) => {
  for (const t in s.tags) {
    if (s.tags[t] !== true)
      continue;
    if (matchTag(pattern, t))
      return true;
  }
  return false;
};

export default {
  prefix: '#',
  predicate
};
