
export const extend = (base, ...objs) => {
  for (const o of objs) {
    for (const k in o) {
      base[k] = o[k];
    }
  }
  return base;
};

export const matchTag = (pattern, str) => {
  if (pattern[0] === '~') {
    return new RegExp(pattern.slice(1)).test(str);
  }
  if (pattern[0] === ':') {
    return str.endsWith(pattern);
  }
  if (pattern[pattern.length - 1] === ':') {
    return str.startsWith(pattern);
  }
  return pattern === str;
};
