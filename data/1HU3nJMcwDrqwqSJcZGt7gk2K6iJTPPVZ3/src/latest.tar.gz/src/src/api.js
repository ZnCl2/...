import ZeroFrame from 'lib/ZeroFrame';

const frame = new ZeroFrame()

const commands = ['siteInfo', 'wrapperPermissionAdd', 'permissionAdd', 'wrapperSetViewport',
                  'mergerSiteList', 'dbQuery',
                  'certSelect', 'fileRules', 'fileWrite', 'sitePublish',
                  'feedListFollow', 'feedFollow',
                  'wrapperGetLocalStorage', 'wrapperSetLocalStorage',
                  'wrapperPushState', 'fileGet', 'fileList',
                  'optionalHelpList', 'optionalHelp', 'optionalHelpRemove',
                  'siteList', 'feedQuery', 'corsPermission'];
const api = {};

const wrap = (name) => (params = {}) =>
  new Promise((resolve, reject) => {
    frame.cmd(name, params, (result) => resolve(result));
  });

for (const name of commands) {
  api[name] = wrap(name);
}

api.json = {
  async read (path, timeout=300) {
    const data = await api.fileGet({ inner_path: path, required: false, format: 'text'. timeout });
    try {
      return JSON.parse(data);
    }
    catch (e) {
      return {};
    }
  },
  async write (path, obj) {
    const raw = unescape(encodeURIComponent(JSON.stringify(obj, undefined, '\t')));
    const result = await api.fileWrite([path, btoa(raw)]);
    if (result !== 'ok') {
      throw new Error(JSON.stringify(result));
    }
  }
}

export default api;
