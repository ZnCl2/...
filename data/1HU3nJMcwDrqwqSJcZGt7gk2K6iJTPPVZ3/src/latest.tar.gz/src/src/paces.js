
import doc from 'src/doc';

const lookup = {};

const add = (docs) => {
  docs.type = 'pace';
  if (docs.name === GREETER.pace) {
    docs.remarks = 'this file was built with this pace set'
  }
  lookup[docs.name] = docs;
  doc.add(docs);
};

add({
  name: 'presto',
  options: [
    {
      name: 'source',
      summary: 'latest HEAD only'
    },
    {
      name: 'schedule',
      summary: 'whenever something that remotely resembles a non-broken build is seen'
    },
    {
      name: 'stability',
      summary: 'no stability at all. expect it to break every day'
    }
  ]
});

export default lookup;
