
import config   from 'src/config';

import own      from './own';
import manual   from './manual';
import merger   from './merger';
import clones   from './clones';
import recent   from './recent';
import kaffiene from './kaffiene';
import keywords from './keywords';

import imply    from './imply';

const plugins = {
  manual,
  own,
  merger,
  clones,
  keywords,
  recent,
  kaffiene
};

let providers = [];
let implyActive = false;

let initialized = false;

const init = async () => {
  if (initialized)
    return;
  await config.init();
  providers = [];
  implyActive = false;
  for (const name of config.tags.value.plugins) {
    if (name === 'imply') {
      implyActive = true;
    }
    else {
      const p = plugins[name];
      if (p == null) {
        console.log(`[ZeroGreeter] Cannot find plugin: ${name}. Skipping.`)
      }
      else {
        providers.push(plugins[name]);
      }
    }
  }
  await Promise.all(providers.filter((f) => f.init != null).map((f) => f.init()));
  initialized = true;
}

const tags = (site, modelData) => {
  const results = providers.map((f) => f.tags(site, modelData));
  let tags = {};
  for (const o of results) {
    for (const t in o) {
      if (tags[t] !== false) {
        tags[t] = o[t];
      }
    }
  }
  if (implyActive) {
    tags = imply(site, tags);
  }
  for (const t in tags) {
    if (tags[t] !== true)
      delete tags[t];
  }
  return tags;
};

export default {
  init,
  tags
};
