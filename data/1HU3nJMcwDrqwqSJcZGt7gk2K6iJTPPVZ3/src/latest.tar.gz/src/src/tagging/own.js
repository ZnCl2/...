
import doc from 'src/doc';

doc.add({
  type: 'plugin',
  name: 'own',
	summary: 'tag owned sites',
  remarks: 'applies tags: "own"'
});

const tags = (site) => {
  const tags = {};
  if (site.settings.own) {
    tags['own'] = true;
  }
  return tags;
};

export default {
  tags
};
