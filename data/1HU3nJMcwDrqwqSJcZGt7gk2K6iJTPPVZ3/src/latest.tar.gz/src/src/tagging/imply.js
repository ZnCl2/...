import doc from 'src/doc';

doc.add({
  type: 'plugin',
  name: 'imply',
	summary: 'tag sites according to tags they already have',
  remarks: 'due to its nature, this plugin is always run after all other plugins, regardless of its declared precedence',
  options: [
    {
      name: '<filter>',
      type: 'Object {String : Boolean}',
      summary: 'tags to grant or deny if site matches <filter>'
    }
  ]
});

import config from 'src/config';
import { predicate } from 'src/filtering';

const tempTags = (tags) => {
  const results = {};
  for (const t in tags) {
    if (tags[t] === true)
      results[t] = true;
  }
  return results;
};

const tempSummary = (s) => {
  return [s.address, s.content.domain || '', s.content.title,
         s.content.description, Object.keys(s.tags).join(',')]
         .join('|').toLowerCase();
};

export default (site, tags) => {
  const rules = config.tags.value.imply || {};
  const C = function () {};
  C.prototype = site;
  const s = new C();
  s.tags = tempTags(tags);
  s.summary = tempSummary(s);
  for (const p in rules) {
    if (!predicate(s, p))
      continue;
    for (const it in rules[p]) {
      if (tags[it] === true || tags[it] == null) {
        tags[it] = rules[p][it] === true;
      }
    }
  }
  return tags;
};
