
import doc from 'src/doc';

doc.add({
  type: 'plugin',
  name: 'manual',
	summary: 'manually tag sites',
  remarks: 'this generally should have the highest precedence, to ensure that rules for manual tags prevail',
  options: [
    {
      name: '<site address | domain>',
      type: 'Object {String: Boolean}',
      summary: 'tags to grant or deny for the specific site'
    }
  ]
});

import config from 'src/config';

const setTags = (tags, from) => {
  if (from == null)
    return false;
  let any = false;
  if (from.constructor === Array) {
    for (const t of from) {
      any = tags[t] = true;
    }
  }
  else {
    for (const t in from) {
      any = true;
      tags[t] = from[t] === true;
    }
  }
  return any;
};

const tags = (site) => {
  const tags = {};
  const manualTags = config.tags.value.manual || {};
  let any = false;
  any = any || setTags(tags, manualTags[site.address]);
  if (site.content.domain != null) {
    any = any || setTags(tags, manualTags[site.content.domain]);
  }
  if (any) {
    tags['manual'] = true;
  }
  return tags;
};

export default {
  tags
};
