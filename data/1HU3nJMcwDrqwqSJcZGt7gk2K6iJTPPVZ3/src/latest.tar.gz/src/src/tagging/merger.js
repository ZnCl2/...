
import doc from 'src/doc';

doc.add({
  type: 'plugin',
  name: 'merger',
	summary: 'tag merger / merged sites',
  remarks: 'based on permissions given. applies tags: "merger:<name>" and "merged:<name>"'
});

const merged = (site) => {
  const tags = {};
  if (site.content.merged_type != null) {
    tags[`merged:${site.content.merged_type}`] = true;
  }
  return tags;
};

const mergerPermission = /^Merger:(.+)$/;

const tags = (site) => {
  const tags = merged(site);
  for (const p of site.settings.permissions) {
    const match = mergerPermission.exec(p);
    if (match != null) {
      tags[`merger:${match[1]}`] = true;
    }
  }
  return tags;
};

export default {
  tags
};
