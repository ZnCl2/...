
import doc from 'src/doc';

doc.add({
  type: 'plugin',
  name: 'clones',
	summary: 'tag sites cloned from specific sites',
  remarks: ['includes special routines for certain ubiquitous sites.',
            'clones of cloned sites can also be tagged,',
            'provided that the entire path is on your instance.',
            'applies tags: "cloned:<name>"'].join(' '),
  options: [
    {
      name: '<cloned site address>',
      type: 'String (name)',
      summary: 'map cloned site source to name'
    }
  ]
});

import config   from 'src/config';

let lookup = {
};

const init = async () => {
  const conf = config.tags.value.clones || {};
  for (const addr in conf) {
    lookup[addr] = conf[addr];
  }
};

const checks = {
  'ZeroTalk': (site) => {
    const s = site.content.settings;
    return s != null && s.admin != null && s.admin_href != null && s.topic_sticky_uris != null;
  }
};

const checkClonedFrom = (site) => {
  const lookupResult = lookup[site.address] || lookup[site.content.cloned_from];
  if (lookupResult != null)
    return lookupResult;
  for (const s in checks) {
    if (checks[s](site))
      return s;
  }
};

const tags = (site, modelData) => {
  const tags = {};
  const checkedSites = {};
  let siteToCheck = site;
  let clonedFrom = null;
  while (siteToCheck != null && clonedFrom == null) {
    if (checkedSites[siteToCheck.address] != null)
      break;
    checkedSites[siteToCheck.address] = true;
    clonedFrom = checkClonedFrom(siteToCheck);
    const cloneAddress = site.content.cloned_from;
    if (cloneAddress != null && modelData.siteLookup[cloneAddress] == null) {
      console.log(`[ZeroGreeter: clones plugin] Cannot find site ${cloneAddress} on clone path of ${site.content.title} (${site.content.domain || site.address}).`);
    }
    siteToCheck = modelData.siteLookup[cloneAddress];
  }
  if (clonedFrom == null) {
    clonedFrom = false;
  }
  for (const addr in checkedSites) {
    lookup[addr] = clonedFrom;
  }
  if (clonedFrom) {
    tags[`cloned:${clonedFrom}`] = true;
  }
  return tags;
};

export default {
  init,
  tags
};
