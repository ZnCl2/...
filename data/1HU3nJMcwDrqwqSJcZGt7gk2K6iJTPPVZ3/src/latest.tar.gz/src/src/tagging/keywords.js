
import doc from 'src/doc';

doc.add({
  type: 'plugin',
  name: 'keywords',
	summary: 'tag sites by "keywords" field in content.json',
  remarks: 'matches [a-zA-Z0-9_] only. rarely observed. applies tags: "keyword:<name>"'
});

const keyword = /[a-zA-Z0-9_]+/g;

const tags = (site) => {
  const tags = {};
  if (site.content.keywords != null) {
    site.content.keywords.replace(keyword, (w) => {
      tags[`keyword:${w}`] = true;
    });
  }
  return tags;
};

export default {
  tags
};
