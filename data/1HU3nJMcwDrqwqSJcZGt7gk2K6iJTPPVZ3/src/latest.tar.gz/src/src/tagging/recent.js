
import doc from 'src/doc';

doc.add({
  type: 'plugin',
  name: 'recent',
	summary: 'tag recently updated sites',
  remarks: 'applies tags: "recent"',
  options: [
    {
      name: 'threshold',
      type: 'Integer',
      summary: 'threshold in seconds'
    }
  ]
});

import config from 'src/config';

const tags = (site) => {
  const tags = {};
  const now = Date.now() / 1000 | 0;
  if (now - site.settings.modified < (config.tags.value.recent.threshold || 7200)) {
    tags['recent'] = true;
  }
  return tags;
};

export default {
  tags
};
