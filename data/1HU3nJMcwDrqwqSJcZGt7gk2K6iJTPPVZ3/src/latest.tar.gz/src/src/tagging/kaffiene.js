
import doc from 'src/doc';

doc.add({
  type: 'plugin',
  name: 'kaffiene',
  summary: 'tag sites from "Kaffiene Search" style index file',
  remarks: 'requires ZeroNet 0.5.7 Rev2163 Cors plugin. may incur significant init time depending on index file chosen',
  options: [
    {
      name: 'site',
      type: 'String (site address)',
      summary: 'site from which to read index file',
      remarks: 'default: "1Mr5rX9TauvaGReB4RjCaE6D37FJQaY5Ba" (kaffiene.bit)'
    },
    {
      name: 'index',
      type: 'String (file path)',
      summary: 'name of the index file',
      remarks: 'default: "data.txt"'
    },
    {
      name: 'namespace',
      type: 'String (tag namespace)',
      summary: 'namespace for generated tags',
      remarks: 'default: "kaffiene"'
    }
  ]
});

import api from 'src/api';
import config from 'src/config';

const tagsRegex = /\[([a-zA-Z0-9_ ,]+)/;
const addrRegex = /:([^ ]+)/;
const lookup = {};

const init = async () => {
  const conf = config.tags.value.kaffiene || {};
  if (conf.site == null)
    conf.site = '1Mr5rX9TauvaGReB4RjCaE6D37FJQaY5Ba';
  if (conf.index == null)
    conf.index = 'data.txt';
  if (conf.namespace == null)
    conf.namespace = 'kaffiene';

  const perm = await api.permissionAdd(`Cors:${conf.site}`);
  if (perm !== 'ok') {
    console.log(`[ZeroGreeter: kaffiene plugin] Cannot obtain read permission for ${conf.site}: ${perm}`);
    return;
  }

  const indexFile = await api.fileGet({ inner_path: `cors-${conf.site}/${conf.index}`, required: false });
  if (!indexFile) {
    console.log(`[ZeroGreeter: kaffiene plugin] Cannot read index file. Skipping.`);
    return;
  }

  for (const line of indexFile.split('\n')) {
    const addrMatch = addrRegex.exec(line);
    if (addrMatch == null)
      continue;
    const addr = addrMatch[1];
    const tagsMatch = tagsRegex.exec(line);
    if (tagsMatch == null)
      continue;
    const tagNames = tagsMatch[1].split(',').map((s) => s.trim()).filter((s) => s.length > 0);
    if (tagNames.length === 0)
      continue;
    lookup[addr] = {};
    for (const t of tagNames) {
      lookup[addr][`${conf.namespace}:${t}`] = true;
    }
  }
};

const tags = (site) => {
  return lookup[site.address] || {};
};

export default {
  init,
  tags
};
