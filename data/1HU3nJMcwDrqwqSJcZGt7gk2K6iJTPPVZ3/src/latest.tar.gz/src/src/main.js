require('../static/index.html');
require('../static/content.json');

import Vue from 'vue';
import App from 'src/App.vue';

import api from 'src/api';

new Vue({
  el: '#app',
  render: h => h(App)
});
