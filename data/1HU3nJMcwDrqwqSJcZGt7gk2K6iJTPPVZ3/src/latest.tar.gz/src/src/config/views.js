
const defaults = {
	"simple": {
		"description": "one filter only",
		"layout": "site-list",
		"filter": "",
		"editable": true,
		"sort": "peers",
		"style": "detail columns",
		"limit": 24
	},
	"docs": {
		"description": "view ZeroGreeter docs",
		"header": "ZeroGreeter Documentation",
		"layout": "doc"
	},
	"hello": {
		"description": "ZeroHello clone",
		"layout": "panels",
		"style": "side inv",
		"modules": [
			{
				"layout": "feed-list",
				"header": "Feed",
				"style": "detail",
				"limit": 12
			},
			{
				"layout": "site-list",
				"filter": "#fav",
				"sort": "peers",
				"style": "list"
			},
			{
				"layout": "site-list",
				"filter": "#own",
				"sort": "modified",
				"style": "list"
			},
			{
				"layout": "site-list",
				"filter": "",
				"header": "All sites",
				"editable": true,
				"sort": "peers",
				"style": "list"
			}
		]
	},
	"vivace": {
		"description": "everything and the kitchen sink",
		"layout": "panels",
		"style": "plain",
		"modules": [
			{
				"layout": "panels",
				"style": "side inv",
				"modules": [
					{
						"layout": "feed-list",
						"header": "@mentions",
						"type": "mention",
						"style": "detail",
						"limit": 4
					},
					{
						"layout": "site-list",
						"filter": "#fav",
						"sort": "name",
						"style": "list nopeers",
						"limit": 10
					},
					{
						"layout": "site-list",
						"filter": "#own",
						"sort": "modified",
						"style": "list"
					}
				]
			},
			{
				"layout": "tabs",
				"style": "top noswitcher",
				"initial": 1,
				"tabs": [
					{
						"layout": "panels",
						"style": "side inv",
						"header": "All",
						"modules": [
							{
								"layout": "feed-list",
								"header": "All Feed",
								"style": "detail",
								"limit": 12
							},
							{
								"layout": "site-list",
								"filter": "",
								"header": "All sites",
								"editable": true,
								"sort": "peers",
								"style": "list",
								"limit": 24
							}
						]
					},
					{
						"layout": "panels",
						"style": "grid uneven-1",
						"header": "Blogs & Forums",
						"modules": [
							{
								"layout": "site-list",
								"filter": "#blog",
								"sort": "modified",
								"style": "list nopeers",
								"limit": 8
							},
							{
								"layout": "feed-list",
								"filter": "#blog",
								"type": "post",
								"header": false,
								"style": "list",
								"limit": 8
							},
							{
								"layout": "site-list",
								"filter": "#forum",
								"sort": "modified",
								"style": "list nopeers",
								"limit": 8
							},
							{
								"layout": "feed-list",
								"filter": "#forum",
								"type": "topic",
								"header": false,
								"style": "list",
								"limit": 8
							}
						]
					}
				]
			}
		]
	},
	"utils": {
		"description": "things useful once in a while",
		"layout": "panels",
		"style": "side inv",
		"modules": [
			{
				"layout": "panels",
				"style": "plain",
				"modules": [
					{
						"layout": "site-list",
						"filter": "#recent",
						"sort": "modified",
						"header": "Recently updated",
						"showHighlight": false,
						"style": "detail columns",
						"limit": 6
					},
					{
						"layout": "site-list",
						"filter": "#manual",
						"sort": "name",
						"header": "Sites manually tagged",
						"showHidden": true,
						"style": "detail columns",
						"limit": 6
					},
					{
						"layout": "site-list",
						"filter": "#hidden",
						"sort": "peers",
						"header": "Hidden sites",
						"showHidden": true,
						"style": "detail columns",
						"limit": 6
					}
				]
			},
			{
				"layout": "palette-chooser"
			}
		]
	}
};

const path = 'local/conf/views.json';

import doc from 'src/doc';

doc.add({
  type: 'config',
  name: 'views.json :: <view name>',
	summary: 'configure views for ZeroGreeter',
  options: [
    {
      name: '<view name>',
      type: 'String',
      summary: 'name of the view'
    },
    {
      name: 'description',
      type: 'String',
      summary: 'short description to show alongside the name'
    },
    {
      name: 'header',
      type: 'String',
      summary: 'supply a custom header for the page'
    },
    {
      name: 'layout',
      type: 'String (View Module Name)',
      summary: 'the top level module for the view'
    }
  ]
});

export default {
  defaults,
  path
};
