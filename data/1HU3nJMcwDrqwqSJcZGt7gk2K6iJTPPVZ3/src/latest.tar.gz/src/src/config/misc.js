
const defaults = {
  palette: 'eternal',
  theme: 'feather',
  view: 'hello',
  feedQueryLimit: 30,
  feedQueryDays: 30,
};

const path = 'local/conf/misc.json';

import doc from 'src/doc';

doc.add({
  type: 'config',
  name: 'misc.json',
	summary: 'misc options that does not belong elsewhere',
  options: [
    {
      name: 'palette',
      type: 'String (palette name)'
    },
    {
      name: 'theme',
      type: 'String (theme name)'
    },
    {
      name: 'view',
      type: 'String (view name)',
      summary: 'the current view defined in views.js',
    },
    {
      name: 'feedQueryLimit',
      type: 'Integer',
      summary: 'maximum amount of entries from each site. required by ZeroFrame API',
    },
    {
      name: 'feedQueryDays',
      type: 'Integer',
      summary: 'maximum age of entries from each site. required by ZeroFrame API',
    },
  ]
});

export default {
  defaults,
  path,
  update (value) {
    document.firstElementChild.className = `${value.palette} ${value.theme}`;
  }
};
