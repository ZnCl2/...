
const defaults = {
  rules: {
    'hidden':  {
      'display': false
    },
    'own':  {
      'display': true
    },
    'fav':  {
      'display': true
    },
    'recent':  {
      'highlight': true
    }
  },
  plugins: [
    'manual',
    'own',
    'merger',
    'clones',
    'keywords',
    'recent',
    'imply'
  ],
  imply: {
    '#merged:': { 'hidden': true },
    '#cloned:ZeroBlog': { 'blog': true },
    '#cloned:ZeroTalk': { 'forum': true }
  },
  clones: {
    '1BLogC9LN4oPDcruNz3qo1ysa133E9AGg8': 'ZeroBlog',
    '19k2nhubaYsDJNPHL6iNs3D2K9Mgj66P4R': 'ZeroBlog',
    '1TaLkFrMwvbNsooF4ioKAY9EuxTBTjipT':  'ZeroTalk'
  },
  recent: { threshold: 7200 },
  manual: {}
};

const path = 'local/conf/tags.json';

import doc from 'src/doc';

doc.add({
  type: 'config',
  name: 'tags.json',
	summary: 'configure rules for sites with the tag',
  remarks: 'rules are decided by the first matched tag that had a non-undefined value',
  options: [
    {
      name: 'plugins',
      type: 'Array [String (plugin name)]',
      summary: 'precedence of tag plugins'
    },
    {
      name: '<plugin name>',
      type: 'tag plugin specific options',
    }
  ]
});

doc.add({
  type: 'config',
  name: 'tags.json :: rules :: <tag name>',
	summary: 'configure rules for sites with the tag',
  remarks: 'Rules are decided by the first matched tag that had a non-undefined value',
  options: [
    {
      name: '<tag name>',
      type: 'String',
      summary: 'the exact tag name to match'
    },
    {
      name: 'display',
      type: 'Boolean',
      summary: 'whether sites should be shown by default'
    },
    {
      name: 'highlight',
      type: 'Boolean',
      summary: 'whether sites should be shown with a highlight'
    }
  ]
});

export default {
  defaults,
  path
};
