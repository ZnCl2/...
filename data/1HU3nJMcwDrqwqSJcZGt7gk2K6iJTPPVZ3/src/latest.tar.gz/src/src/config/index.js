
import api from 'src/api';
import { extend } from 'src/utils';

class Config {
  constructor (info) {
    this.defaults = info.defaults;
    this.path = info.path;
    this.hooks = {};
    if (info.update)
      this.hooks.update = info.update;
    this.value = {};
  }

  _setValue (config) {
    this.value = extend({}, this.defaults, config);
    if (this.hooks.update) {
      this.hooks.update(this.value);
    }
  }

  async init () {
    const config = await api.json.read(this.path);
    this._setValue(config);
    await this.save();
  }

  async save () {
    await api.json.write(this.path, this.value);
  }

  async update (config) {
    this._setValue(config);
    await this.save();
  }

  async patch (config) {
    this._setValue(extend({}, this.value, config));
    await this.save();
  }
}

import tags  from './tags';
import misc  from './misc';
import views from './views';

let initialized = false;

export default {
  async init () {
    if (initialized)
      return;
    await this.tags.init();
    await this.misc.init();
    await this.views.init();
    initialized = true;
  },
  tags:  new Config(tags),
  misc:  new Config(misc),
  views: new Config(views)
};
