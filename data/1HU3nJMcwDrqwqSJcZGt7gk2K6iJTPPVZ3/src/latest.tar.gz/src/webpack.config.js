var node_env = process.env.NODE_ENV || 'development';

var webpack = require('webpack');
var path    = require('path');

var ExtractTextPlugin = require("extract-text-webpack-plugin");
var BabiliPlugin      = require("babili-webpack-plugin");

var plugins = [
  new ExtractTextPlugin("main.css"),
  new webpack.DefinePlugin({ 'GREETER': { pace: `"${process.env.PACE || 'undefined'}"` } }),
];

var productionPlugins = [
  new ExtractTextPlugin("main.css"),
  new webpack.DefinePlugin({ 'GREETER': { pace: `"${process.env.PACE || 'undefined'}"` }, 'process.env': { NODE_ENV: '"production"' } }),
  new BabiliPlugin({}, { comments: false })
];

module.exports = {
  entry: {
    main: ["babel-polyfill", './src/main.js'],
  },
  output : {
    path: path.resolve(__dirname, 'dist'),
    filename : '[name].js',
    publicPath: '/'
  },
  module : {
    rules : [
      {
        test: /\.vue$/,
        loader: 'vue-loader',
        options: {
          loaders: {
            js:   'babel-loader?presets[]=es2015&presets[]=stage-0',
            css:  ExtractTextPlugin.extract("css-loader"),
            less: ExtractTextPlugin.extract("css-loader!less-loader")
          },
          postcss: [
            require('autoprefixer')({ browsers: ['last 8 versions'] })
          ]
        }
      },
      {
        test: /\.js$/,
        exclude: /node_modules/,
        loader: 'babel-loader',
        options: {
          presets: ['es2015', 'stage-0'],
        }
      },
      {
        test: /\.(html|json)$/,
        loader: 'file-loader',
        query: {
          name: '[name].[ext]'
        }
      }
    ]
  },

  resolve: {
    alias: {
      src:     path.join(__dirname, 'src'),
      lib:     path.join(__dirname, 'lib'),
      theme:   path.join(__dirname, 'src/theme/index.less'),
      look:    path.join(__dirname, 'src/theme/look/index.less'),
      palette: path.join(__dirname, 'src/theme/palette/index.less'),
    }
  },

  plugins: node_env === 'production' ? productionPlugins : plugins
};
