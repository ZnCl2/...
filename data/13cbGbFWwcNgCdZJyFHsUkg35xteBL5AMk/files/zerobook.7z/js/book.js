const pages = [
    `<h1>How to configure your book</h1>
    <p>Open <code>js/book.js</code> and configure your book</p>
    `
]
const title = "My book";
const author = `Me`