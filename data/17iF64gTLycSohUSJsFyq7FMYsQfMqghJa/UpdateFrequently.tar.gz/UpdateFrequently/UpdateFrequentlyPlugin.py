from Plugin import PluginManager
from Config import config
import gevent

@PluginManager.registerTo("Site")
class SitePlugin(object):
    # Keep connections to get the updates
    def needConnections(self, num=4, check_site_on_reconnect=False):
        need = min(len(self.peers), num, config.connected_limit)  # Need 5 peer, but max total peers

        connected = len(self.getConnectedPeers())

        connected_before = connected

        self.log.debug("Need connections: %s, Current: %s, Total: %s" % (need, connected, len(self.peers)))

        if connected < need:  # Need more than we have
            for peer in self.peers.values():
                if not peer.connection or not peer.connection.connected:  # No peer connection or disconnected
                    peer.pex()  # Initiate peer exchange
                    if peer.connection and peer.connection.connected:
                        connected += 1  # Successfully connected
                if connected >= need:
                    break

        if check_site_on_reconnect and connected > 0 and self.connection_server.has_internet:
            self.log.debug("Connected before: %s, after: %s. We need to check the site." % (connected_before, connected))
            gevent.spawn(self.update, check_files=False)

        self.log.debug("UpdateFrequently plugin runs well")
        return connected
