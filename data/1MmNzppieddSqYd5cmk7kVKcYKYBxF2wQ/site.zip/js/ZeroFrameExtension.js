"use strict";

// IF YOU WANT TO UPDATE ZeroFrame.js, GO TO http://babeljs.io/repl/ AND SET THE PRESET
// TO ES2015-LOOSE. PASTE THE NEW ZeroFrame.js INTO THE LEFT EDITOR, COPY THE TRANSLATED
// ES2015-LOOSE VERSION FROM THE RIGHT EDITOR AND REPLACE CONTENTS OF OLD ZeroFrame.js
// FILE WITH IT. SHOULD WORK, IF NOT, REPORT THE ISSUE.

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var ZeroFrameExtension = function (_ZeroFrame) {
    _inherits(ZeroFrameExtension, _ZeroFrame);

    function ZeroFrameExtension(url) {
        _classCallCheck(this, ZeroFrameExtension);

        var _this = _possibleConstructorReturn(this, _ZeroFrame.call(this, url));

        _this.onRequestFunc = null;
        _this.onOpenWebsocketFunc = null;
        return _this;
    }

    ZeroFrameExtension.prototype.registerOnRequest = function registerOnRequest(f) {
        this.onRequestFunc = f;
    };

    ZeroFrameExtension.prototype.registerOnOpenWebsocket = function registerOnOpenWebsocket(f) {
        this.onOpenWebsocketFunc = f;
    };

    ZeroFrameExtension.prototype.onRequest = function onRequest(cmd, message) {
        if (this.onRequestFunc != null) {
            this.onRequestFunc(cmd, message);
        } else {
            this.log("No requestFunc defined", this.onRequestFunc);
        }
    };

    ZeroFrameExtension.prototype.onOpenWebsocket = function onOpenWebsocket() {
        if (this.onOpenWebsocketFunc != null) {
            this.onOpenWebsocketFunc();
        } else {
            this.log("No onOpenWebsocketFunc defined", this.onOpenWebsocketFunc);
        }
    };

    return ZeroFrameExtension;
}(ZeroFrame);