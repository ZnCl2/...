enum MainLoadingType{
    NONE,
    LOCAL,
    FILE
}