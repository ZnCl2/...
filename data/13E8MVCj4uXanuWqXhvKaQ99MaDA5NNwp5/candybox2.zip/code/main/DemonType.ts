enum DemonType{
    CUBE,
    EYES,
    BUBBLES
}