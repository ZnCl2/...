enum PlayerCharacterType{
    CANDYBOX,
    MEDIUM,
    CANDYBOX_SQUEEZED,
    MEDIUM_SQUEEZED
}