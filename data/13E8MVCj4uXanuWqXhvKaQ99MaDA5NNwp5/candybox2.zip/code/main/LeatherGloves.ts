///<reference path="EqItem.ts"/>

class LeatherGloves extends EqItem{
    // Constructor
    constructor(){
        super("eqItemGlovesLeatherGloves",
              "eqItemGlovesLeatherGlovesName",
              "eqItemGlovesLeatherGlovesDescription",
              "eqItems/gloves/leatherGloves");
    }
}