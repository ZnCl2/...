///<reference path="EqItem.ts"/>

class LeatherBoots extends EqItem{
    // Constructor
    constructor(){
        super("eqItemBootsLeatherBoots",
              "eqItemBootsLeatherBootsName",
              "eqItemBootsLeatherBootsDescription",
              "eqItems/boots/leatherBoots");
    }
}