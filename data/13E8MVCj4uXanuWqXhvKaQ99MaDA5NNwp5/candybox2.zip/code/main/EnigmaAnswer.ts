// We can't use this class directly, we have to use a daughter class
class EnigmaAnswer{
    // Constructor
    constructor(){
        
    }
    
    // Public methods
    public isRight(answer: string): boolean{
        return false;
    }
}
