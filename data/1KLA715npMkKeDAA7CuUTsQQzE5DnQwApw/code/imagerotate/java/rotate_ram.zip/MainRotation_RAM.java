package graphics_rendering.imagerotate.image_03;

public class MainRotation_RAM
{
	public static void main(String[] args) 
	{
		new MainRotation_RAM();
	}
	
	// ============================================
	
	int width = 640;
	int height = 480;
	float radian = (float)Math.PI / 180f;
	int bgColor = toInt(0,0,200);
	
	public MainRotation_RAM()
	{
		Window wnd = new Window("Rotation By Area Mapping");
		Surface srf = new Surface(width, height);
		wnd.addSurface(srf);
		
		/*
		 * load image file
		 * rotate image
		 */
		IntBuffer image = ImageLoader.file( "path/to/your/image.png" );
		image = rotateAM(image, 20f * radian, bgColor);
		
		/*
		 * draw to surface, update window
		 */
		draw(100,100,image, srf);
		wnd.repaint();
		wnd.setVisible(true);
	}
	
	
	/*
	 * rotate by area mapping RAM
	 */
	public IntBuffer rotateAM(IntBuffer pic, float angle, int bgColor)
	{
	    float sin 	= (float)StrictMath.sin(angle);
	    float cos 	= (float)StrictMath.cos(angle);
	    
	    int width 	= pic.getWidth();
	    int height 	= pic.getHeight();

	    /*
	     * use absolute matrix rotation to find the bounding box
	     * of our our rotated image
	     */
	    float absin = (float)((sin<0f)?-sin:sin);
	    float abcos = (float)((cos<0f)?-cos:cos);
	    int neww 	= (int)(abcos*width + height*absin + 0.5f);
	    int newh 	= (int)(abcos*height + width*absin + 0.5f);
	    IntBuffer res = new IntBuffer(neww, newh);
	    res.clear(bgColor);
	    
	    float x0 	= 0.5f * width;
	    float y0 	= 0.5f * height;
	    float r_x0 	= 0.5f * neww;
	    float r_y0 	= 0.5f * newh;
	    int[] resX 	= res.getContent();
	    
	    // loop through all pixels of the new image
        for (int y = 0; y < newh; y++) 
	    {
        	// get an offset. 
        	// makes it easier to loop through our pixels
	        int off = y * neww;
	        
	        for (int x = 0; x < neww; x++, off++) 
	        {
	        	/*
	        	 * get point to rotate
	        	 */
	            float a = x - r_x0;
		        float b = y - r_y0;

	            /*
	             * compute reverse matrix transform
	             * reversing rotation is done by transposing the rotation matrix
	             */
	            float fx = a*cos - b*sin + x0; 
	            float fy = a*sin + b*cos + y0;
	            
	            /*
	             * hard cast floats to get upper-left pixel location
	             */
	            int i,j;
	            i = (int)(fx);
	            j = (int)(fy);
	            
	            /*
	             * set default color
	             */
	            int UL,UR,LL,LR;
	            UL=UR=LL=LR = bgColor;
	            
	            /*
	             * get the 4 pixel colors that overlap the destination pixel
	             */
	            if (j > 0)
				if (j < height)
				{
		            if (i > 0)
					if (i < width)
						UL = pic.grab(i, j);
		            
		            if (i+1 > 0)
					if (i+1 < width)
						UR = pic.grab(i+1, j);
				}
	            
				if (j+1 > 0)
				if (j+1 < height) 
				{
		            if (i > 0)
					if (i < width)
						LL = pic.grab(i, j+1);
		            
		            if (i+1 > 0)
					if (i+1 < width)
						LR = pic.grab(i+1, j+1);
	            }
				
	            /*
	             * interpolate colors
	             */
	            int subX = (int)(16f * (fx-i));
	            int subY = (int)(16f * (fy-j));
	            
	            /*
	             * make sure the lerp values are within bounds
	             */
	            subX = clamp(0,subX,16);
	            subY = clamp(0,subY,16);
	            
	            int colU = intLerpARGB(UL,UR, subX);
	            int colL = intLerpARGB(LL,LR, subX);
                resX[off] = intLerpARGB(colU, colL, subY);
	        }
	    }
	    return res;
	}
	
	/*
	 * draw a source image onto a destination image
	 */
	public void draw(int x, int y, IntBuffer source, Surface screen)
	{
		int w = source.getWidth();
		int h = source.getHeight();
		int wmax = screen.getWidth();
		int hmax = screen.getHeight();
		
		// clip negatives
		int xoff = (x<0)?-x:0;
		int yoff = (y<0)?-y:0;
		w = ((w+x) >= wmax)? -x+wmax :w;
		h = ((h+y) >= hmax)? -y+hmax :h;
		
		// draw
		for (int j=yoff,k=h; j<k; j++)
		for (int i=xoff,l=w; i<l; i++)
		{
			int c = source.grab(i, j);
			screen.plot(i+x, j+y, c);
		}
	}
	
	/*
	 * clamp a given value between two values.
	 */
	public int clamp(int lower, int x, int upper)
	{
		int x1 = (x<lower)?lower:x;
		return (x1<upper)?x1:upper;
	}
	
	public int intLerpARGB(int c1, int c2, int lerp)
	{
		int r = (c1>>16)& 0xFF;
		int g = (c1>>8) & 0xFF;
		int b = (c1) 	& 0xFF;
		
		int r2 = (c2>>16)& 0xFF;
		int g2 = (c2>>8) & 0xFF;
		int b2 = (c2) 	 & 0xFF;
		
		r = intLerp16(r, r2, lerp);
		g = intLerp16(g, g2, lerp);
		b = intLerp16(b, b2, lerp);
		
		return toInt(r,g,b);
	}
	
	public int intLerp16(int A, int B, int F)
	{
		return (A*(16-F) + B*F) >> 4;
	}
	
	public int toInt(int r,int g,int b)
	{
		return ( (255<<24) | r<<16 | g<<8 | b );
	}
}
