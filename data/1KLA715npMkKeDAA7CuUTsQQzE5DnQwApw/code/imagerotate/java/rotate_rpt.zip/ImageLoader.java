package graphics_rendering.imagerotate.image_01;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class ImageLoader 
{
	/*
	 * read a file into a texture
	 * returns an ImageTexture
	 * it loads: bmp, jpg, png, gif
	 */
	public static IntBuffer file(String path)
	{
		BufferedImage image = null;
		
		// try to load an image
		try 
		{
			image = ImageIO.read(new File(path));
		}
		catch (IOException e) 
		{
			System.err.println("Could not load image '"+path+"'.");
			return new IntBuffer(0,0); // return empty image as if its NULL
		}
		
		int width, height;
		width 	= image.getWidth();
		height 	= image.getHeight();
		IntBuffer tex = new IntBuffer(width,height);
		
		/*
		 * copy over the RGB pixel from the image to the buffer
		 */
		int i,j;
		for(j=0; j<height; j++)
		for(i=0; i<width; i++)
		{
			int c = image.getRGB(i,j);
			tex.plot(i,j,c);
		}
		
		return tex;
	}
}
