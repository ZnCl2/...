package graphics_rendering.imagerotate.image_02;

public class MainRotation_RS
{
	public static void main(String[] args) 
	{
		new MainRotation_RS();
	}
	
	// ============================================
	
	int width = 640;
	int height = 480;
	float radian = (float)Math.PI / 180f;
	int bgColor = toInt(0,0,200);
	
	public MainRotation_RS()
	{
		Window wnd = new Window("Rotation By Sampling");
		Surface srf = new Surface(width, height);
		wnd.addSurface(srf);
		
		IntBuffer image = ImageLoader.file( "path/to/your/image.png" );
		image = rotateSAMP(image, 30f * radian, bgColor);
		
		draw(100,100,image, srf);
		
		
		wnd.repaint();
		wnd.setVisible(true);
	}

	/*
	 * rotate by sampling (RSamp)
	 */
	public IntBuffer rotateSAMP(IntBuffer pic, float angle, int bgColor)
	{
	    float sin 	= (float)StrictMath.sin(angle);
	    float cos 	= (float)StrictMath.cos(angle);
	    
	    int width 	= pic.getWidth();
	    int height 	= pic.getHeight();

	    /*
	     * use absolute matrix rotation to find the bounding box
	     * of our our rotated image
	     */
	    float absin = (float)((sin<0f)?-sin:sin);
	    float abcos = (float)((cos<0f)?-cos:cos);
	    int neww 	= (int)(abcos*width + height*absin + 0.5f);
	    int newh 	= (int)(abcos*height + width*absin + 0.5f);
	    IntBuffer res = new IntBuffer(neww, newh);
	    res.clear(bgColor);
	    
	    // make sure we rotate around the center of the image using
	    // some offset values
	    float x0 	= 0.5f * width;
	    float y0 	= 0.5f * height;
	    float r_x0 	= 0.5f * neww;
	    float r_y0 	= 0.5f * newh;
	    
	    // get pixel content for easy access
	    int[] picX = pic.getContent();
	    int[] resX = res.getContent();
	    
	    // loop through all pixels of the new image
        for (int y = 0; y < newh; y++) 
	    {
        	// get an offset. 
        	// makes it easier to loop through our pixels
	        int off = y * neww;
	        
	        for (int x = 0; x < neww; x++, off++) 
	        {
	        	/*
	        	 * get point to rotate
	        	 */
	            float a = x - r_x0;
		        float b = y - r_y0;
	            
	            /*
	             * compute reverse matrix transform
	             * reversing rotation is done by transposing the rotation matrix
	             */
	            float fxx = a*cos - b*sin + x0; 
	            float fyy = a*sin + b*cos + y0;
	            
	            /*
	             * clip of the source pixel is out of frame
	             */
	            if (fxx >= width) continue;
	            if (fxx < 0f) continue;
	            if (fyy >= height) continue;
	            if (fyy < 0f) continue;
	            
	            /*
	             * cast to int to get the nearest source pixel
	             * no interpolation
	             */
	            int xx = (int)(fxx);
	            int yy = (int)(fyy);
                resX[off] = picX[xx + yy*width];
	        }
	    }
	    return res;
	}
	
	/*
	 * draw a source image onto a destination image
	 */
	public void draw(int x, int y, IntBuffer source, Surface screen)
	{
		int w = source.getWidth();
		int h = source.getHeight();
		int wmax = screen.getWidth();
		int hmax = screen.getHeight();
		
		// clip negatives
		int xoff = (x<0)?-x:0;
		int yoff = (y<0)?-y:0;
		w = ((w+x) >= wmax)? -x+wmax :w;
		h = ((h+y) >= hmax)? -y+hmax :h;
		
		// draw
		for (int j=yoff,k=h; j<k; j++)
		for (int i=xoff,l=w; i<l; i++)
		{
			int c = source.grab(i, j);
			screen.plot(i+x, j+y, c);
		}
	}
	
	/*
	 * compile rgb color
	 */
	int toInt(int r,int g,int b)
	{
		return ( (255<<24) | r<<16 | g<<8 | b );
	}
}
