package graphics_rendering.imagerender.image_02;

public class ImageRendering
{
	public static void main(String[] args) 
	{
		new ImageRendering();
	}
	
	// ============================================
	
	public int width,height;
	
	public ImageRendering()
	{
		
		IntBuffer image = ImageLoader.file( "path/to/your/image.png" );
		
		width = 640;
		height = 480;

		Window wnd = new Window("Image Rendering");
		Surface srf = new Surface(width, height);
		IntBuffer screen = new IntBuffer(width, height);
		wnd.addSurface(srf);
		
		drawInt(200, 0, image, screen);
		drawFloat(100.2f, 80.7f, image, screen);
		
		drawToSurface(0,0,screen,srf);
		wnd.repaint();
		wnd.setVisible(true);
	}
	
	// =====================================================
	// 						render images
	// =====================================================
	
	/*
	 * draw an image on a given decimal point
	 */
	public void drawFloat(float fx, float fy, IntBuffer source, IntBuffer screen)
	{
		int srcw = source.getWidth();
		int srch = source.getHeight();
		int wmax = screen.getWidth();
		int hmax = screen.getHeight();
		
		/*
		 * get the offset from the pixel grid
		 * calculate the interpolants
		 */
		int x = (int)fx;
		int y = (int)fy;
		float offx = fx - (float)x;
		float offy = fy - (float)y;
		int intx = (int)(16f * offx);
        int inty = (int)(16f * offy);
		
        /*
         * clipping
         */
		int clipx = (x<0)?-x:0;
		int clipy = (y<0)?-y:0;
		
		srcw = ((srcw+x) >= wmax)? -x+wmax :srcw;
		srch = ((srch+y) >= hmax)? -y+hmax :srch;

        /*
         * pixX and pixY are the source pixel scan.
         * they grab the right colors to blend
         */
		for (int j=clipy, jj=j-1,k=srch+1; j<k; j++, jj++)
		{
			/*
			 * clip vertical values for grabbing source colors
			 */
			boolean clipU = jj < 0;
			boolean clipD = jj+1 >= srch;
			
			for (int i=clipx, ii=i-1,l=srcw+1; i<l; i++,ii++)
			{
				/*
				 * color buffers
				 */
				int UL,UR,LL,LR,colU,colL;
				UL=UR=LL=LR = screen.grab(i+x,j+y);

				/*
				 * clip horizontal values for grabbing source colors
				 */
				boolean clipL = ii < 0;
				boolean clipR = ii+1 >= srcw;

				/*
				 * clip values grabbed from the source image
				 */
				if (!clipU)
				{
					if (!clipR)
					UL = source.grab(ii+1, jj);
					
					if (!clipL)
					UR = source.grab(ii, jj);
				}
				if (!clipD)
				{
					if (!clipR)
					LL = source.grab(ii+1, jj+1);
					
					if (!clipL)
					LR = source.grab(ii, jj+1);
				}
				
				/*
				 * blend the four colors
				 */
				colU = intLerpARGB(UL,UR, intx);
	            colL = intLerpARGB(LL,LR, intx);
	            colU = intLerpARGB(colL,colU, inty);
				screen.plot(i+x, j+y, colU);
			}
		}
	}
	
	/*
	 * draw a source image onto a destination image
	 */
	public void drawInt(int x, int y, IntBuffer source, IntBuffer screen)
	{
		int w = source.getWidth();
		int h = source.getHeight();
		int wmax = screen.getWidth();
		int hmax = screen.getHeight();
		
		// clip negatives
		int xoff = (x<0)?-x:0;
		int yoff = (y<0)?-y:0;
		w = ((w+x) >= wmax)? -x+wmax :w;
		h = ((h+y) >= hmax)? -y+hmax :h;
		
		// draw
		for (int j=yoff,k=h; j<k; j++)
		for (int i=xoff,l=w; i<l; i++)
		{
			int c = source.grab(i, j);
			screen.plot(i+x, j+y, c);
		}
	}
	
	/*
	 * draw a source image onto a surface
	 */
	public void drawToSurface(int x, int y, IntBuffer source, Surface screen)
	{
		int w = source.getWidth();
		int h = source.getHeight();
		int wmax = screen.getWidth();
		int hmax = screen.getHeight();
		
		// clip negatives
		int xoff = (x<0)?-x:0;
		int yoff = (y<0)?-y:0;
		w = ((w+x) >= wmax)? -x+wmax :w;
		h = ((h+y) >= hmax)? -y+hmax :h;
		
		// draw
		for (int j=yoff,k=h; j<k; j++)
		for (int i=xoff,l=w; i<l; i++)
		{
			int c = source.grab(i, j);
			screen.plot(i+x, j+y, c);
		}
	}
	
	public int intLerpARGB(int c1, int c2, int lerp)
	{
		int a = (c1>>24)& 0xFF;
		int r = (c1>>16)& 0xFF;
		int g = (c1>>8) & 0xFF;
		int b = (c1) 	& 0xFF;
		
		int a2 = (c2>>24)& 0xFF;
		int r2 = (c2>>16)& 0xFF;
		int g2 = (c2>>8) & 0xFF;
		int b2 = (c2) 	 & 0xFF;
		
		a = intLerp16(a, a2, lerp);
		r = intLerp16(r, r2, lerp);
		g = intLerp16(g, g2, lerp);
		b = intLerp16(b, b2, lerp);
		
		return ( a<<24 | r<<16 | g<<8 | b );
	}
	
	public int intLerp16(int A, int B, int F)
	{
		return (A*(16-F) + B * F) >> 4;
	}
	
	public int toInt(int r,int g,int b)
	{
		return ( (255<<24) | r<<16 | g<<8 | b );
	}
}
