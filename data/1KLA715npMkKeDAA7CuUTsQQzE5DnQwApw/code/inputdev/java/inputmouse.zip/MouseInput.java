package game_utilities.inputdev.input_01;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;

public class MouseInput implements MouseListener, MouseWheelListener, MouseMotionListener
{
	public static final int BUTTON_LEFT 	= 1;
	public static final int BUTTON_MIDDLE 	= 2;
	public static final int BUTTON_RIGHT 	= 3;

	// ===========================================
	
	private int idealWndX;
	private int idealWndY;
	private int xCurr;
	private int yCurr;
	
	// ===========================================
	
	private boolean bClickL = false;
	private boolean bClickM = false;
	private boolean bClickR = false;
	private boolean bDrag 	= false;
	
	private boolean bEntered = true;
	private boolean bScroll = false;
	private boolean bMouseLock = false;
	private int deltax = 0;
	private int deltay = 0;
	private int notch = 0;
	
	// ===========================================
	
	public MouseInput()
	{ 
		
	}
	
	/*
	 * snapshot constructor
	 */
	private MouseInput(	boolean clickL,
						boolean clickM,
						boolean clickR,
						boolean enter,
						boolean scroll,
						boolean drag,
						int n,
						int dx,
						int dy,
						int xcurr,
						int ycurr)
	{
		bClickL = clickL;
		bClickM = clickM;
		bClickR = clickR;
		
		bEntered = enter;
		bScroll = scroll;
		bDrag 	= drag;
		
		notch = n;
		deltax = dx;
		deltay = dy;
		xCurr = xcurr;
		yCurr = ycurr;
	}
	
	// ===========================================
	
	public void initMouseCoords(int wndx, int wndy,
								int wndw, int wndh) 
	{
		idealWndX = wndw/2;
		idealWndY = wndh/2;
		
		// center on screen 
		xCurr = idealWndX;
		yCurr = idealWndY;
	}
	
	/*
	 * 
	 */
	public synchronized MouseInput getSnapShot()
	{
		bScroll = (notch!=0)?true:false;
		MouseInput mi = new MouseInput(	bClickL,
										bClickM,
										bClickR,
										bEntered,
										bScroll,
										bDrag,
										notch,
										xCurr-idealWndX,
										yCurr-idealWndY,
										xCurr,
										yCurr);
		notch = 0;
		return mi;
	}

	// =============================================================
	
	/*
	 * returns true if either the left, middle and right button has been clicked
	 */
	public boolean isClicked()
	{
		return bClickL || bClickM || bClickR;
	}
	
	/*
	 * returns true if a mouse button ID has been pressed<br>
	 */
	public boolean isClicked(int button)
	{
		switch(button)
		{
		case BUTTON_LEFT: return bClickL;
		case BUTTON_MIDDLE: return bClickM;
		case BUTTON_RIGHT: return bClickR;
		}
		return false;
	}
	
	/*
	 * returns true if the mouse is in the window's canvas
	 */
	public boolean isFocused()
	{
		return bEntered;
	}
	
	/*
	 * 
	 */
	public boolean isScrolling()
	{
		return bScroll;
	}
	
	/*
	 * 
	 */
	public boolean isDragging()
	{
		return bDrag;
	}
	
	/*
	 * returns true of the mouse has been centered by the Robot.<br>
	 */
	public boolean isLocked()
	{
		return bMouseLock;
	}
	
	// =============================================================
	
	/*
	 * returns 1 or -1 indicating scroll direction
	 */
	public int getNotch()
	{
		return notch;
	}
	
	public int getDeltaX()
	{
		return deltax;
	}
	
	public int getDeltaY()
	{
		return deltay;
	}
	
	public int getMouseX()
	{
		return xCurr;
	}
	
	public int getMouseY()
	{
		return yCurr;
	}
	
	// =============================================================
	
	@Override
	public void mouseWheelMoved(MouseWheelEvent e)
	{
		notch += e.getWheelRotation();
	}
	
	// =============================================================
	
	@Override
	public void mouseDragged(MouseEvent e) 
	{
		mouseMoved(e);
		bDrag = true;
	}
	
	@Override
	public void mouseMoved(MouseEvent e) 
	{
		xCurr = (int)( (float)e.getX() + 0.5f);
		yCurr = (int)( (float)e.getY() + 0.5f);
	}
	
	// =============================================================
	
	@Override
	public void mouseClicked(MouseEvent e) 
	{
		
	}

	@Override
	public void mouseEntered(MouseEvent e) 
	{
		bEntered = true;
	}

	@Override
	public void mouseExited(MouseEvent e) 
	{
		bEntered = false;
	}
	
	@Override
	public void mousePressed(MouseEvent e) 
	{
		int btn = e.getButton();
		switch(btn)
		{
		case BUTTON_LEFT: bClickL = true; break;
		case BUTTON_MIDDLE: bClickM = true; break;
		case BUTTON_RIGHT: bClickR = true; break;
		}
	}
	
	@Override
	public void mouseReleased(MouseEvent e) 
	{
		int btn = e.getButton();
		switch(btn)
		{
		case BUTTON_LEFT: bDrag = bClickL = false; break;
		case BUTTON_MIDDLE: bClickM = false; break;
		case BUTTON_RIGHT: bClickR = false; break;
		}
	}
}
