package game_utilities.inputdev.input_02;

public class MainFixLoop extends FixedLoop
{
	public static void main(String[] args) 
	{
		MainFixLoop g = new MainFixLoop();
		g.start();
	}
	
	// ============================================
	
	final int width 	= 640;
    final int height 	= 480;
    
    final int RED 	= toRGB(255, 0, 0);
    final int YELLOW = toRGB(255, 255, 0);
    final int BLACK	= toRGB(0, 0, 0);
	
	Window wnd;
	Surface srf;
	KeyboardInput ki;
	KeyboardInput kiS;
	
	/*
	 * Use the init() as a constructor. 
	 * We don't have to, but it looks neat if we do.
	 */
	@Override
	public void init()
	{
		/*
		 * lets set a fixed FPS and update Hertz for this loop
		 */
		this.setTargetHz(20);
		this.setTargetFPS(60);
		
		ki = new KeyboardInput();
		wnd = new Window("Keyboard Input");
		srf = new Surface(width, height);
		wnd.addSurface(srf);
		wnd.addInput(ki);
		wnd.setVisible(true);
	}

	double circle_x_curr = width>>1;
	double circle_x_prev = circle_x_curr;
	
	double circle_y_curr = height>>1;
	double circle_y_prev = circle_y_curr;
	
	/*
	 * our game loop
	 */
	@Override
	public void update(double time)
	{
		/*
		 * capture keyboard state
		 */
		kiS = ki.getSnapShot();
		
		/*
		 * backup current position
		 */
		circle_x_prev = circle_x_curr;
		circle_y_prev = circle_y_curr;
		
		/*
		 * move current position using the keyboard
		 */
		if (kiS.isPressed())
		{
			/*
			 * W = up
			 */
			if (kiS.hasKey( Key.W ))
			{
				circle_y_curr -= 10;
			}
			
			/*
			 * S = down
			 */
			if (kiS.hasKey( Key.S ))
			{
				circle_y_curr += 10;
			}
			
			/*
			 * D = right
			 */
			if (kiS.hasKey( Key.D ))
			{
				circle_x_curr += 10;
			}
			
			/*
			 * A = left
			 */
			if (kiS.hasKey( Key.A ))
			{
				circle_x_curr -= 10;
			}
		}
		
	}
	
	@Override
	public void render(double lerp)
	{
		/*
		 * render the result
		 */
		
		srf.clear( BLACK );
		
		int x = (int)interpolate( (float)circle_x_prev, (float)circle_x_curr, (float)lerp );
		int y = (int)interpolate( (float)circle_y_prev, (float)circle_y_curr, (float)lerp );
		
		circle(x,y, 10, YELLOW, srf);
		
		wnd.repaint();
	}
	
	/*
	 * linear interpolation function
	 */
	public static float interpolate(float start, float end, float inter)
	{
		return start*(1f-inter) + end*inter;
	}
	
	/*
	 * convert three values ranging from 0-255 into a color representation.
	 * r = red
	 * g = green
	 * b = blue
	 */
	public int toRGB(int r, int g, int b)
	{
		return ( (255<<24) | r<<16 | g<<8 | b );
	}
	
	/*
	 * Bresenham circle algorithm
	 */
	public void circle(int cx, int cy, int r, int c, Surface screen)
	{
		int x,y,xC,yC,radErr;
		int w = screen.getWidth() - 1;
		int h = screen.getHeight() - 1;
		
		x = r;
		y = 0;
		xC = 1-(r+r);
		yC = 1;
		radErr = 0;
		
		while( x>= y)
		{
			/*
			 * clipping
			 */
			boolean cx_pls_x = cx+x < 0 || cx+x > w;
			boolean cx_min_x = cx-x < 0 || cx-x > w;

			boolean cy_pls_x = cy+x < 0 || cy+x > h;
			boolean cy_min_x = cy-x < 0 || cy-x > h;
			
			boolean cy_pls_y = cy+y < 0 || cy+y > h;
			boolean cy_min_y = cy-y < 0 || cy-y > h;
			
			boolean cx_pls_y = cx+y < 0 || cx+y > w;
			boolean cx_min_y = cx-y < 0 || cx-y > w;
			
			/*
			 * draw pixels
			 */
			if (!cy_pls_y)
			{
				if (!cx_pls_x) screen.plot(cx+x, cy+y, c);
				if (!cx_min_x) screen.plot(cx-x, cy+y, c);
			}
			
			if (!cy_min_y)
			{
				if (!cx_min_x) screen.plot(cx-x, cy-y, c);
				if (!cx_pls_x) screen.plot(cx+x, cy-y, c);
			}
			
			if (!cy_pls_x)
			{
				if (!cx_pls_y) screen.plot(cx+y, cy+x, c);
				if (!cx_min_y) screen.plot(cx-y, cy+x, c);
			}
			
			if (!cy_min_x)
			{
				if (!cx_min_y) screen.plot(cx-y, cy-x, c);
				if (!cx_pls_y) screen.plot(cx+y, cy-x, c);
			}
			
			y++;
			radErr += yC;
			yC += 2;
			
			if ( (radErr+radErr+xC) > 0 )
			{
				x--;
				radErr += xC;
				xC += 2;
			}
		}
	}
}
