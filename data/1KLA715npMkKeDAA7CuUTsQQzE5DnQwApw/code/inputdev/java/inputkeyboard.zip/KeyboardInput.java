package game_utilities.inputdev.input_02;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;

public class KeyboardInput implements KeyListener 
{
	private ArrayList<Integer> keys = new ArrayList<Integer>();
	private Integer mostRecent = -1;
	
	// ===========================================
	
	public KeyboardInput()
	{ 
        
	}
	
	private KeyboardInput(ArrayList<Integer> list, Integer recent)
	{
		mostRecent = recent;
		
		for(Integer b : list)
			keys.add( b.intValue() );
	}
	
	/**
	 * get a snapshot of the state of the keyboard at this point.
	 */
	public KeyboardInput getSnapShot()
	{
		synchronized(keys)
		{
			KeyboardInput ki = new KeyboardInput(keys,mostRecent);
			return ki;
		}
	}
	
	// ===========================================
	
	/**
	 * Returns all keys in the list in integer form.
	 */
	public Iterator<Integer> getKeys()
	{
		return new Iterator<Integer>(keys);
	}
	
	/**
	 * add a key code to the keyboard input list
	 */
	public void addKey(int code)
	{
		if (!hasKey(code)) 
		{
			keys.add(code);
			mostRecent = code;
		}
	}
	
	/**
	 * returns true if the given key is present in the key-pressed list
	 */
	public boolean hasKey(int code)
	{
		for(Integer b : keys)
			if (b == code) return true;
		return false;
	}
	
	/**
	 * Returns true if the given list keys is present in the key-pressed list<br>
	 */
	public boolean hasKey(int... code)
	{
		for(int c : code)
			if (hasKey(c)) return true;
		
		return false;
	}
	
	/*
	 * Check if the given keycode matches the last key pressed
	 */
	public boolean isLastKey(int code)
	{
		Integer b = keys.get(keys.size() - 1);
		return (b == code);
	}
	
	/**
	 * returns the key-code for the last registered key in the list
	 */
	public int lastKey()
	{
		if (keys.size()<1) return -1;
		return keys.get(keys.size() - 1);
	}
	
	/**
	 * returns the code of the most recently pressed key. 
	 * @return returns -1 if that key has been released and no new key has been pressed
	 */
	public int latestKey()
	{
		return mostRecent;
	}
	
	public boolean isPressed()
	{
		return keys.size() > 0;
	}
	
	public boolean isCombo()
	{
		return keys.size() > 1;
	}
	
	// ===========================================
	
	@Override
	public void keyPressed(KeyEvent e) 
	{
		synchronized(keys)
		{
			int code = e.getKeyCode();
			addKey(code);
		}
	}
	
	@Override
	public void keyReleased(KeyEvent e) 
	{
		synchronized(keys)
		{
			int k = e.getKeyCode();
			int l = keys.size();
			
			if (k == mostRecent)
				mostRecent = -1;
			
			for(int i=0; i<l; i++)
			if (keys.get(i) == k)
			{
				keys.remove(i);
				return;
			}
		}
	}

	@Override
	public void keyTyped(KeyEvent e) { }

}
