package game_utilities.inputdev.input_02;

import java.util.List;

public class Iterator<T>
{
	private int index = 0;
	private int size = 0;
	private List<T> lines;
	
	public Iterator(List<T> l)
	{
		lines = l;
		size = l.size();
	}
	
	public boolean hasNext()
	{
		if (index<size) return true;
		return false;
	}
	
	public T getNext()
	{
		return lines.get(index++);
	}
	
	public int getSize()
	{
		return lines.size();
	}
	
	public int getIndex()
	{
		return index;
	}
}