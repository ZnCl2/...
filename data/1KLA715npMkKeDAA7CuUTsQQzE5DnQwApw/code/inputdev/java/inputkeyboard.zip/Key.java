package game_utilities.inputdev.input_02;

public class Key 
{
	/**
	 * returns true if the given keycode is a letter in the alphabet
	 */
	public static boolean isLetter(int code)
	{
		return (code >= 65 && code <= 90) || (code >= 97 && code <= 122);
	}
	
	/**
	 * returns true if the given keycode is an Arabic number
	 */
	public static boolean isNumber(int code)
	{
		return (code >= 48 && code <= 57);
	}
	
	/**
	 * returns true for non-shifted punctuation markers<br>
	 * ` - = [ \ ] ; ' , . / *
	 */
	public static boolean isPunctuation(int code)
	{
		switch(code)
		{
		case 96:// `
		case 45:// -
		case 61:// =
		case 91:// [
		case 92:// \
		case 93:// ]
		case 59:// ;
		case 39:// '
		case 44:// ,
		case 46:// .
		case 47:// /
		case 42:// *
			return true;
		}
		return false;
	}
	
	public static String toString(int code)
	{
		return ""+((char)code);
	}
	
	/**
	 * returns the shifted keycode of the given character code
	 */
	public static int shift(int code)
	{
		if(isLetter(code))
			return code + 32;
		
		if(isNumber(code)) 
		{
			switch(code)
			{
			case 48: return 41; // )
			case 49: return 33; // !
			case 50: return 64; // @
			case 51: return 35; // #
			case 52: return 36; // $
			case 53: return 37; // %
			case 54: return 94; // ^
			case 55: return 38; // &
			case 56: return 42; // *
			case 57: return 40; // (
			}
		}
		
		//if isPunctuation(code)
		switch(code)
		{
		case 96: return 126; // ~
		case 45: return 95; // _
		case 61: return 43; // +
		case 91: return 123; // {
		case 92: return 124; // |
		case 93: return 125; // }
		case 59: return 58; // :
		case 39: return 34; // "
		case 44: return 60; // <
		case 46: return 62; // >
		case 47: return 63; // ?
		}
		
		return ERROR;
	}
	
	// error code
	public final static int ERROR = -1;
	
	// modifiers
	public final static int ESC = 27;
	public final static int TAB = 9;
	public final static int SHIFT = 16;
	public final static int CTRL = 17;
	public final static int ALT = 18;
	public final static int ENTER = 10;
	public final static int SPACE = 32;
	
	// function
	public final static int F5 = 116; 
	public final static int F9 = 120;
	
	// special functions
	public final static int PAUSE = 19;
	public final static int BACKSPACE = 8;
	
	// arrow
	public final static int DOWN 	= 40;
	public final static int RIGHT 	= 39;
	public final static int UP 		= 38;
	public final static int LEFT 	= 37;
	
	// numbers
	public final static int num0 = 48;
	public final static int num1 = 49;
	public final static int num2 = 50;
	public final static int num3 = 51;
	public final static int num4 = 52;
	public final static int num5 = 53;
	public final static int num6 = 54;
	public final static int num7 = 55;
	public final static int num8 = 56;
	public final static int num9 = 57;
	
	// alphabet
	public final static int A = 65;
	public final static int B = 66;
	public final static int C = 67;
	public final static int D = 68;
	public final static int E = 69;
	public final static int F = 70;
	public final static int G = 71;
	public final static int H = 72;
	public final static int I = 73;
	public final static int J = 74;
	public final static int K = 75;
	public final static int L = 76;
	public final static int M = 77;
	public final static int N = 78;
	public final static int O = 79;
	public final static int P = 80;
	public final static int Q = 81;
	public final static int R = 82;
	public final static int S = 83;
	public final static int T = 84;
	public final static int U = 85;
	public final static int V = 86;
	public final static int W = 87;
	public final static int X = 88;
	public final static int Y = 89;
	public final static int Z = 90;
}
