package game_utilities.loop_02;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class MainFixLoop extends FixedLoop
{
	public static void main(String[] args) 
	{
		MainFixLoop g = new MainFixLoop();
		g.start();
	}
	
	// ============================================
	
	final int width 	= 640;
    final int height 	= 480;

    final int RED 	= toRGB(255, 0, 0);
    final int YELLOW = toRGB(255, 255, 0);
    final int BLACK	= toRGB(0, 0, 0);
	
	Window wnd;
	Surface srf;
    
	/*
	 * Use the init() as a constructor. 
	 * We don't have to, but it looks neat if we do.
	 */
	@Override
	public void init()
	{
		/*
		 * lets set a fixed FPS and update Hertz for this loop
		 */
		this.setTargetHz(5);
		this.setTargetFPS(20);
		
		wnd = new Window(width, height);
		srf = new Surface(width, height);
		
		wnd.addSurface(srf);
		wnd.setVisible(true);
	}
	
	double radian = Math.PI / 180d;
	double angle = 0d;

	double circle_x_curr = 440d;
	double circle_x_prev = 440d;
	
	double circle_y_curr = 240d;
	double circle_y_prev = 240d;
	
	/*
	 * our game loop
	 */
	@Override
	public void update(double time)
	{
		/*
		 * update our "game" logic
		 */
		
		angle += 20d * time;
		angle %= 360d;

		double cos = StrictMath.cos(angle * radian);
		double sin = StrictMath.sin(angle * radian);
		
		circle_x_prev = circle_x_curr;
		circle_x_curr = 320d + 120d * cos;

		circle_y_prev = circle_y_curr;
		circle_y_curr = 240d - 120d * sin;
	}
	
	@Override
	public void render(double lerp)
	{
		/*
		 * render the result
		 */
		
		srf.clear( BLACK );

		int x = (int)interpolate( (float)circle_x_prev, (float)circle_x_curr, (float)lerp );
		int y = (int)interpolate( (float)circle_y_prev, (float)circle_y_curr, (float)lerp );
		
		circle(x,y, 10, YELLOW, srf);
		circle(320,240, 120, RED, srf);
		
		wnd.repaint();
	}
	
	/*
	 * linear interpolation function
	 */
	public static float interpolate(float start, float end, float inter)
	{
		return start*(1f-inter) + end*inter;
	}
	
	/*
	 * convert three values ranging from 0-255 into a color representation.
	 * r = red
	 * g = green
	 * b = blue
	 */
	public int toRGB(int r, int g, int b)
	{
		return ( (255<<24) | r<<16 | g<<8 | b );
	}
	
	/*
	 * Bresenham circle algorithm
	 */
	public void circle(int cx, int cy, int r, int c, Surface screen)
	{
		int x,y,xC,yC,radErr;
		
		x = r;
		y = 0;
		xC = 1-(r+r);
		yC = 1;
		radErr = 0;
		
		while( x>= y)
		{
			screen.plot(cx+x, cy+y, c);
			screen.plot(cx-x, cy+y, c);
			screen.plot(cx-x, cy-y, c);
			screen.plot(cx+x, cy-y, c);
			screen.plot(cx+y, cy+x, c);
			screen.plot(cx-y, cy+x, c);
			screen.plot(cx-y, cy-x, c);
			screen.plot(cx+y, cy-x, c);
			
			y++;
			radErr += yC;
			yC += 2;
			
			if ( (radErr+radErr+xC) > 0 )
			{
				x--;
				radErr += xC;
				xC += 2;
			}
		}
	}
}

/*
 * Simple window class.
 */
class Window extends JFrame
{
	private static final long serialVersionUID = 430959593579646079L;
	
	public Window(int width, int height)
	{
		setSize(width, height);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setResizable(false);
	}
	
	public void addSurface(Surface srf)
	{
		this.add(srf);
	}
}

/*
 * A class that contains pixel data for our window.
 */
class Surface extends JPanel
{
	private static final long serialVersionUID = 8224004759629210049L;
	
	private BufferedImage img;
	private int[] pixels;
	private int width = 0;
	
	public Surface(int width, int height)
	{
		img = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
		pixels 	= ((DataBufferInt) img.getRaster().getDataBuffer()).getData();
		this.width = width;
	}
	
	@Override
	public void paintComponent(Graphics g) 
	{
        g.drawImage(img, 0, 0, null);
        g.dispose();
	}
	
	public void plot(int x, int y, int rgb)
	{
		int i = x + y*width;
		pixels[i] = rgb;
	}
	
	public void clear(int rgb)
	{
		for (int i=0,l=pixels.length; i<l; i++)
		{
			pixels[i] = rgb;
		}
	}
}