package game_utilities.loop_01;

/** Variable time stepping<br><br>
 * 
 * + Render and game logic speed capped for consistency on different machines.<br>
 * + High granularity, render updates after changes take place.<br>
 * + Provides delta time to provide equal update speeds on various machines.<br>
 * = No interpolation.<br>
 * - Not good with simulations, like those using physics,
 *   which requires constant updates and takes snapshots to render instead.<br>
 */
public abstract class VariableLoop
{
	private final long MICRO = 1000000;		// 10^6
	private final long NANO  = 1000000000;	// 10^9
	private final double inv_MICRO = 1d / MICRO; // 10^-6
	private final double inv_NANO = 1d / NANO; // 10^-9
	
	private boolean running = true;
	private boolean paused = false;
	
	private int target_update; 
	private long ideal_time;
	private long nanotime_prev;
	
	/*
	 * a pseudo-constructor
	 */
	public abstract void init();
	
	/*
	 * override this method to insert your own game logic 
	 */
	public abstract void update(double timing);
	
	/*
	 * Start the program.
	 */
	public void start()
	{
		/*
		 * set default fps
		 */
		setTargetFPS(30);
		
		init();
		
		nanotime_prev = System.nanoTime();
		
		/*
		 * start our loop
		 */
		while (running)
		{
			if (!paused)
			{
				/*
				 * get nanotime
				 */
				long nanotime_curr = System.nanoTime();
				
				/*
				 * get delta nanotime
				 */
				long nanotime_delta = nanotime_curr - nanotime_prev;
				nanotime_prev = nanotime_curr;
				
				/*
				 * convert to seconds
				 * update game
				 */
				double timing = nanotime_delta * inv_NANO;
				update(timing);
				
				/*
				 * get nanotime till next cycle
				 * convert to milliseconds, since thats what sleep() wants
				 */
				long t = (long)( ((nanotime_curr - System.nanoTime() + ideal_time) * inv_MICRO));
				
				/*
				 * sleep thread
				 */
				try
				{
					Thread.sleep( (t<0)?0:t );
				} 
				catch (InterruptedException e) 
				{
					e.printStackTrace();
				}
			}
		}
		
		cleanUp();
	}
	
	/*
	 * Set the target frames rendered per second
	 */
	public void setTargetFPS(int fps) 
	{
		target_update = fps;
		ideal_time = NANO / target_update;
	}
	
	/*
	 * Pause the program, but does not terminate the program.
	 */
	public void pause(boolean pause)
	{
		this.paused = pause;
	}
	
	/*
	 * Terminates the program.
	 */
	public void stop()
	{
		running = false;
	}
	
	/*
	 * override optional
	 */
	public void cleanUp() { }
}
