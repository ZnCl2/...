package graphics_rendering.affinetexture.texture_02;

import java.util.ArrayList;
import java.util.List;

public class AreaInterpolator
{
	/*
	 * triangle positions
	 */
	private float x1,y1, x2,y2, x3,y3;
	
	/*
	 * store interpolation data, like the inverse area and triangle weights
	 */
	private float inva = 1f;
	private float l1 = 0f;
	private float l2 = 0f;
	private float l3 = 0f;
	
	/*
	 * store values to be interpolated. 
	 */
	private List<float[]> interpolants = new ArrayList<float[]>();
	
	/*
	 * pass three vertices that make a triangle 
	 */
	public AreaInterpolator(float[] minv, float[] midv, float[] maxv)
	{
		x1 = minv[0];
		y1 = minv[1];
			x2 = midv[0];
			y2 = midv[1];
				x3 = maxv[0];
				y3 = maxv[1];
		
		inva = 1f / ( area( x1,y1, x2,y2, x3,y3) );
	}
	
	/*
	 * recalculate interpolants
	 */
	public void calculate(int x, int y)
	{
		float a1 = area( x,y, x2,y2, x3,y3);
		float a2 = area( x1,y1, x,y, x3,y3);
		
		l1 = a1 * inva;
		l2 = a2 * inva;
		l3 = 1.0f - l1 - l2;
		
		l1 = clamp(0f, l1, 1f);
		l2 = clamp(0f, l2, 1f);
		l3 = clamp(0f, l3, 1f);
	}
	
	/*
	 * add new set of values to be interpolated
	 */
	public void addValues(float c1, float c2, float c3)
	{
		interpolants.add( new float[]{c1,c2,c3} );
	}
	
	/*
	 * get the interpolated values by index
	 */
	public float getValue(int index)
	{
		float[] c = interpolants.get(index);
		float u = c[0];
		float v = c[1];
		float w = c[2];
		return u*l1 + v*l2 + w*l3;
	}
	
	// =========================================================
	
	/*
	 * returns the double area of a triangle.<br>
	 * to get the actual area, multiply the result with 0.5f.
	 * the reason we don't multiply here is because the math will cancel out the common factor in the area division.
	 * this will save us a bit of performance
	 */
	private float area( float x1, float y1, 
						float x2, float y2, 
						float x3, float y3) 
	{
		float n = (x1-x3)*(y2-y1)-(x1-x2)*(y3-y1);
		return abs(n);
	}
	
	/*
	 * fast float absolute function
	 */
	private float abs(float n)
	{
		return Float.intBitsToFloat( 0x7fffffff & Float.floatToIntBits(n) );
	}
	
	/*
	 * clamp a given value between two values.<br>
	 * saturation can be done with: sat(x) = clamp(0.0f, x, 1.0f)<br>
	 */
	private float clamp(float lower, float x, float upper)
	{
		if (lower > upper) return clamp(upper,x,lower);
		float x1 = (x<lower)?lower:x;
		return (x1<upper)?x1:upper;
	}
}
