package graphics_rendering.affinetexture.texture_01;

import java.util.ArrayList;
import java.util.List;

public class VectorInterpolator
{
	/*
	 * triangle positions
	 */
	private float[] p1,p2,p3;
	
	/*
	 * store interpolation data, like the inverse area and triangle weights
	 */
	private float l1 = 0f;
	private float l2 = 0f;
	private float l3 = 0f;
	
	/*
	 * store values to be interpolated. 
	 */
	private List<float[]> interpolants = new ArrayList<float[]>();
	
	/*
	 * pass three vertices that make a triangle 
	 */
	public VectorInterpolator(float[] minv, float[] midv, float[] maxv)
	{
		p1 = minv;
		p2 = midv;
		p3 = maxv;
	}
	
	/*
	 * recalculate interpolants
	 */
	public void calculate(int x, int y)
	{
		/*
		 * convert pixel location to vector P
		 */
		float[] P = vector(x,y);
		
		/*
		 * get two vectors from p1 and the opposite edge
		 */
		float[] vec_v1P = sub(P, p1);
		float[] vec_v2v3 = sub(p3, p2);
		
		/*
		 * find intersection distance scaler
		 * get point on the edge
		 */
		float lambda = intersect(p1, vec_v1P, p2, vec_v2v3);
		float[] v1_at_edge = add(p1, mul(vec_v1P, lambda) );
		
		/*
		 * get the two distances from p1 to edge, and to P
		 */
		float dist_v1 = magnitude( sub(v1_at_edge, p1) );
		float dist_v1p = magnitude(vec_v1P);
		
		/*
		 * now the same from the point of view of p2
		 */
		float[] vec_v2P = sub(P, p2);
		float[] vec_v3v1 = sub(p1, p3);
		lambda = intersect(p2, vec_v2P, p3, vec_v3v1);
		float[] v2_at_edge = add(p2, mul(vec_v2P, lambda) );
		float dist_v2 = magnitude( sub(v2_at_edge, p2) );
		float dist_v2p = magnitude(vec_v2P);
		
		/*
		 * get interpolation values
		 */
		l1 = 1f - (dist_v1p / dist_v1);
		l2 = 1f - (dist_v2p / dist_v2);
		l3 = 1.0f - l1 - l2;
		
		l1 = clamp(0f, l1, 1f);
		l2 = clamp(0f, l2, 1f);
		l3 = clamp(0f, l3, 1f);
	}
	
	/*
	 * add new set of values to be interpolated
	 */
	public void addValues(float c1, float c2, float c3)
	{
		interpolants.add( new float[]{c1,c2,c3} );
	}
	
	/*
	 * get the interpolated values by index
	 */
	public float getValue(int index)
	{
		float[] c = interpolants.get(index);
		float u = c[0];
		float v = c[1];
		float w = c[2];
		return u*l1 + v*l2 + w*l3;
	}

	// =========================================================
	// 					2D VECTOR MATH
	// =========================================================
	
	/*
	 * make a vector from two coordinates
	 */
	public float[] vector(float x, float y)
	{
		return new float[]{x,y};
	}
	
	/*
	 * add two vector2 arrays
	 */
	public float[] add(float[] a, float[] b)
	{
		return new float[]{	a[0]+b[0],
							a[1]+b[1]};
	}
	
	/*
	 * solves for a^2 + b^2 = c^2
	 */
	public float magnitude(float[] a)
	{
		return (float)StrictMath.sqrt(a[0]*a[0] + a[1]*a[1]);
	}
	
	/*
	 * subtract two vector2 arrays
	 */
	public float[] sub(float[] a, float[] b)
	{
		return new float[]{	a[0]-b[0],
							a[1]-b[1]};
	}
	
	/*
	 * multiply a vector with a factor
	 */
	public float[] mul(float[] a, float f)
	{
		return new float[]{	a[0]*f,
							a[1]*f};
	}
	
	/*
	 * returns the normal from a vector
	 */
	public float[] normal(float[] a)
	{
		return new float[]{-a[1],a[0]};
	}
	
	/*
	 * returns the dot product between two vectors.
	 * can also be used to get the square distance
	 */
	public float dot(float[] a, float[] b)
	{
		return a[0]*b[0] + a[1]*b[1];
	}
	
	/*
	 * find the intersection of A+l*a onto line B+l*b<br>
	 * returns the lambda scalar<br>
	 * l = ( dot(n,B) - dot(n,A) ) / dot(n,a)<br>
	 */
	public float intersect(float[] A, float[] a, float[] B, float[] b)
	{
		float[] n 	= normal(b);
		float denom = dot(n,a);
		if (denom == 0.0f) return 0f;
		float numer = dot(n,B) - dot(n,A);
		float l 	= numer / denom;
		return l;
	}
	
	/*
	 * clamp a given value between two values.<br>
	 * saturation can be done with: sat(x) = clamp(0.0f, x, 1.0f)<br>
	 */
	private float clamp(float lower, float x, float upper)
	{
		if (lower > upper) return clamp(upper,x,lower);
		float x1 = (x<lower)?lower:x;
		return (x1<upper)?x1:upper;
	}
}
