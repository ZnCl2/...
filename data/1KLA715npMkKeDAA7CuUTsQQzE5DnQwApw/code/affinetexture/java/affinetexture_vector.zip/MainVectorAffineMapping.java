package graphics_rendering.affinetexture.texture_01;

public class MainVectorAffineMapping
{
	public static void main(String[] args) 
	{
		new MainVectorAffineMapping();
	}
	
	// ============================================
	
	final int width 	= 640;
    final int height 	= 480;

    final int WHITE = toInt(255, 255, 255);
    final int BLACK = toInt(0, 0, 0);
	
	public MainVectorAffineMapping()
	{
		/*
		 * make a texture filled with random colors
		 */
		int img_w = 12;
		int img_h = 12;
		int[] img_colors = new int[img_w*img_h];
		for (int i=0,l=img_colors.length; i<l;i++)
		{
			int color = toInt(  (int)(Math.random()*255.0 + 0.5),
								(int)(Math.random()*255.0 + 0.5),
								(int)(Math.random()*255.0 + 0.5));
			img_colors[i] = color;
		}
		IntBuffer texture = new IntBuffer(img_w,img_h);
		texture.plot(img_colors);
		
		/*
		 * make window and drawing surface
		 */
		Window wnd = new Window("Affine Texture Mapping");
		Surface srf = new Surface(width, height);
		wnd.addSurface(srf);
		
		/*
		 * draw texture as a reference image to compare results
		 */
		scale(0,0, img_w*10,img_h*10, texture, srf);
		
		/*
		 * create vertices
		 */
		float[] p1 = {200,150};
		float[] p2 = {230,400};
		float[] p3 = {450,130};
		
		/*
		 * determine uv vertex for each triangle vertex
		 */
		float[] u1 = {0f,0f};
		float[] u2 = {0f,1f};
		float[] u3 = {1f,0f};
		
		/*
		 * render triangle
		 */
		triangle(p1,p2,p3, 
				 u1,u2,u3, 
				 texture,
				 srf);
		
		/*
		 * show result
		 */
		wnd.repaint();
		wnd.setVisible(true);
	}
	
	/*
	 * draws triangles counter clockwise
	 */
	void triangle(float[] v1,float[] v2,float[] v3,
				  float[] uv1,float[] uv2,float[] uv3,
				  IntBuffer tex, Surface screen)
	{
		
		/*
		 * create interpolator
		 * add uv values to interpolator
		 */
		VectorInterpolator alerp = new VectorInterpolator(v1,v2,v3);
		alerp.addValues(uv1[0], uv2[0], uv3[0]);
		alerp.addValues(uv1[1], uv2[1], uv3[1]);
		
		/*
		 * pass float[] for reference swapping
		 */
		float[] minv = v1; 
		float[] midv = v2; 
		float[] maxv = v3;
		
		/*
		 * sort vertices from top to bottom
		 */
		float[] temp;
		if (maxv[1] < midv[1])
			{temp = maxv; maxv = midv; midv = temp;}
		if (midv[1] < minv[1])
			{temp = midv; midv = minv; minv = temp;}
		if (maxv[1] < midv[1])
			{temp = maxv; maxv = midv; midv = temp;}
		
		/*
		 * make edges for scan-line
		 * t2b = top to bottom
		 * t2m = top to middle
		 * m2b = middle to bottom
		 * get the y range of the triangle
		 */
		Edge t2b = new Edge(minv, maxv);
		Edge t2m = new Edge(minv, midv);
		Edge m2b = new Edge(midv, maxv);
		
		int ymin = t2b.getStart();
		int ymid = t2m.getEnd();
		int ymax = t2b.getEnd();
		
		/*
		 * get triangle handiness from area, left or right
		 */
		float a = cross(minv[0],minv[1], maxv[0],maxv[1], midv[0],midv[1]);
		boolean hand = a >= 0; 
		
		/*
		 * draw top half
		 */
		Edge left = t2b;
		Edge right = t2m;
		if (hand)
		{
			left = t2m;
			right = t2b;
		}
		
		drawScan(ymin,ymid, left,right, alerp, tex, screen);
		
		/*
		 * draw bottom half
		 */
		left = t2b;
		right = m2b;
		if (hand)
		{
			left = m2b;
			right = t2b;
		}
		
		drawScan(ymid,ymax, left,right, alerp, tex, screen);
	}
	
	/*
	 * draw the scan-lines from the given heights and edges
	 */
	public void drawScan(int ymin, int ymax, 
						 Edge left, Edge right, 
						 VectorInterpolator alerp,
						 IntBuffer tex, Surface screen)
	{
		for (int y=ymin; y<ymax; y++)
		{
			// get left and right boundary
			int lbound = ceil(left.getX());
			int rbound = ceil(right.getX());
			
			// draw line
			while(lbound < rbound)
			{
				/*
				 * calculate new interpolants
				 */
				alerp.calculate(lbound, y);
				float u = alerp.getValue(0);
				float v = alerp.getValue(1);
				int c = tex.grab(u, v);
				
				screen.plot(lbound, y, c);
				lbound++;
			}
			
			// step one down
			left.step();
			right.step();
		}
	}
	
	/*
	 * only works for positive values, does not check overflow
	 */
	int ceil(float x)
	{
		return (int)x + 1;
	}
	
	/*
	 * determine the triangle handiness using a 2d cross product
	 */
	float cross(float x1, float y1, 
				 float x2, float y2, 
				 float x3, float y3) 
	{
		return (x2-x1)*(y3-y1)-(x3-x1)*(y2-y1);
	}
	
	/*
	 * convert three values ranging from 0-255 into a color representation.
	 * r = red
	 * g = green
	 * b = blue
	 */
	public int toInt(int r, int g, int b)
	{
		return ( r<<16 | g<<8 | b );
	}
	
	/*
	 * draw a source image onto a destination image scaling to desired dimensions
	 */
	public void scale(int sx, int sy, int dx, int dy, 
					  IntBuffer source, Surface screen)
	{
		int sw = source.getWidth();
		int sh = source.getHeight();
		int deltax = (dx-sx);
		int deltay = (dy-sy);
		
		/*
		 * get ratios
		 */
		float ratiox = (float)sw / (float)deltax;
		float ratioy = (float)sh / (float)deltay;
		float currX, currY, startX=0f, startY=0f;
		
		/*
		 * reverse draw step for flipped image
		 */
		if (deltax<0)
		{
			startX = ratiox*(deltax+1);
			deltax = -deltax;
			sx = dx;
		}
		if (deltay<0)
		{
			startY = ratioy*(deltay+1);
			deltay = -deltay;
			sy = dy;
		}
		
		/*
		 * clipping
		 */
		int offx = 0;
		if (sx<0)
		{
			offx = -sx;
			startX = startX + offx*ratiox;
		}
		
		int offy = 0;
		if (sy<0)
		{
			offy = -sy;
			startY = startY + offy*ratioy;
		}
		
		sw = screen.getWidth();
		sh = screen.getHeight();
		if (sx + deltax > sw)
		{
			deltax = deltax - (sx + deltax - sw);
		}
		if (sy + deltay > sh)
		{
			deltay = deltay - (sy + deltay - sh);
		}
		
		/*
		 * draw image
		 */
		currY = startY;
		for (int j=offy, k=deltay; j<k; j++)
		{
			currX = startX;
			for (int i=offx, l=deltax; i<l; i++)
			{
				int grap_x = (int)(currX);
				int grap_y = (int)(currY);
				int c = source.grab(grap_x, grap_y);
				
				screen.plot(sx+i, sy+j, c);
				currX += ratiox;
			}
			currY += ratioy;
		}		
	}
}
