package graphics_rendering.affinetexture.texture_01;

/*
 * a class to represent an edge of a triangle
 */
public class Edge 
{
	/*
	 * stepping values
	 */
	private float x;
	private float xstep;
	private int ystart;
	private int yend;
	
	/*
	 * step along the edge of a triangle top down down the y axes.
	 * use ceil() to conform to fill convention.
	 * the presteps are used to correct for cast truncations so are math stays correct.
	 */
	public Edge(float[] v1, float[] v2)
	{
		// get float values
		float x1f = v1[0];
		float y1f = v1[1];
		
		float x2f = v2[0];
		float y2f = v2[1];
		
		/*
		 * get vertical stepping
		 */
		ystart 			= (int)StrictMath.ceil(y1f);
		yend 			= (int)StrictMath.ceil(y2f);
		float xdelta 	= x2f - x1f;
		float ydelta 	= y2f - y1f;
		float ypre 		= (float)ystart - y1f;
		xstep 			= xdelta/ydelta;
		x 				= x1f + ypre*xstep;
	}
	
	/*
	 * step the edge tracer over the y axes
	 */
	public void step()
	{
		x += xstep;
		
	}
	
	/*
	 * get value from the edge tracer
	 */
	public float getX()
	{
		return x;
	}
	
	/*
	 * get the starting y of this edge
	 */
	public int getStart()
	{
		return ystart;
	}
	
	/*
	 * get the end y of this edge
	 */
	public int getEnd()
	{
		return yend;
	}
}