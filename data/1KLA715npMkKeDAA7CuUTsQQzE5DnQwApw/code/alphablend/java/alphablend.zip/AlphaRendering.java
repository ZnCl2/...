package graphics_rendering.alphablend.image_01;

public class AlphaRendering
{
	public static void main(String[] args) 
	{
		new AlphaRendering();
	}
	
	// ============================================
	
	int width = 640;
	int height = 480;
	
	public AlphaRendering()
	{
		Window wnd = new Window("Alpha Blending");
		Surface srf = new Surface(width, height);
		wnd.addSurface(srf);
		
		IntBuffer image1 = ImageLoader.file( "path/to/your/image.png" );
		IntBuffer image2 = new IntBuffer(width,height);
		
		/*
		 * draw two images on top of each other. draw to image2 so we 
		 * can render the result to the Surface, which renders to the window
		 */
		drawTransparency(100, 100, image1, image2);
		drawTransparency(200, 50, image1, image2);
		
		/*
		 * draw to the window
		 */
		drawNoTransparency(0,0, image2, srf);
		wnd.repaint();
		
		wnd.setVisible(true);
	}
	
	/*
	 * draw a source image onto a destination image
	 */
	public void drawNoTransparency(int x, int y, IntBuffer source, Surface screen)
	{
		int w = source.getWidth();
		int h = source.getHeight();
		int wmax = screen.getWidth();
		int hmax = screen.getHeight();
		
		// clip negatives
		int xoff = (x<0)?-x:0;
		int yoff = (y<0)?-y:0;
		w = ((w+x) >= wmax)? -x+wmax :w;
		h = ((h+y) >= hmax)? -y+hmax :h;
		
		// draw
		for (int j=yoff,k=h; j<k; j++)
		for (int i=xoff,l=w; i<l; i++)
		{
			int c = source.grab(i, j);
			screen.plot(i+x, j+y, c);
		}
	}
	
	/*
	 * draw a source image onto a destination image
	 */
	void drawTransparency(int x, int y, IntBuffer source, IntBuffer screen)
	{
		int w = source.getWidth();
		int h = source.getHeight();
		int wmax = screen.getWidth();
		int hmax = screen.getHeight();
		
		// clip negatives
		int xoff = (x<0)?-x:0;
		int yoff = (y<0)?-y:0;
		
		// clip max values
		w = ((w+x) >= wmax)? -x+wmax :w;
		h = ((h+y) >= hmax)? -y+hmax :h;
		
		// draw
		for (int j=yoff,k=h; j<k; j++)
		for (int i=xoff,l=w; i<l; i++)
		{
			int c = source.grab(i, j);
			int srcc = screen.grab(i+x, j+y);
			
			// extract values
			int a = (c>>24) & 0xFF;
			float cAlpha = (float)a / 255f;
			c = lerpARGB(srcc, c, cAlpha);
			
			screen.plot(i+x, j+y, c);
		}
	}
	
	/*
	 * interpolates from color1 to color2 indicated by the given lerp value [0-1]
	 * lerp = short for linear interpolation
	 */
	int lerpARGB(int c1, int c2, float lerp)
	{
		int a = (c1>>24)& 0xFF;
		int r = (c1>>16)& 0xFF;
		int g = (c1>>8) & 0xFF;
		int b = (c1) 	& 0xFF;
		
		int a2 = (c2>>24)& 0xFF;
		int r2 = (c2>>16)& 0xFF;
		int g2 = (c2>>8) & 0xFF;
		int b2 = (c2) 	 & 0xFF;
		
		a = lerpC(a, a2, lerp);
		r = lerpC(r, r2, lerp);
		g = lerpC(g, g2, lerp);
		b = lerpC(b, b2, lerp);
		
		return toInt(a,r,g,b);
	}
	
	/*
	 * interpolates from integer1 to integer2 indicated by the given lerp value [0-1]
	 */
	int lerpC(int c1, int c2, float alpha)
	{
		return (int)( (float)c1*(1f-alpha) + (float)c2*(alpha) );
	}
	
	/*
	 * compile alpha,red,green,blue from ranges [0-255] into a 32bit color
	 */
	int toInt(int a, int r,int g,int b)
	{
		return ( a<<24 | r<<16 | g<<8 | b );
	}
}


