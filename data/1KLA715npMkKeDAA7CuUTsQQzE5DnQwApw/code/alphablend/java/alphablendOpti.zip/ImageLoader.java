package graphics_rendering.alphablend.image_02;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import javax.imageio.ImageIO;

public class ImageLoader 
{
	/*
	 * read a file into a texture
	 * returns an ImageTexture
	 * it loads: bmp, jpg, png, gif
	 */
	public static IntBuffer file(String path)
	{
		BufferedImage image = null;
		
		// try to load an image
		try 
		{
			image = ImageIO.read(new File(path));
		}
		catch (IOException e) 
		{
			System.err.println("Could not load image '"+path+"'.");
			return new IntBuffer(0,0); // return empty image as if its NULL
		}
		
		return convert(image);
	}
	
	/*
	 * load a resource from the project folder
	 */
	public static IntBuffer resource(String directory)
	{
		// check first char for a '/'
		char c = directory.charAt(0);
		if (c != '/') directory = "/"+directory;
		
		// begin loading image
		BufferedImage image = null;
		InputStream stream = InputStream.class.getResourceAsStream(directory);
		
		if (stream!=null)
		try 
		{
			image = ImageIO.read( stream );
		} 
		catch (IOException e) 
		{
			System.err.println("Could not load resource '"+directory+"'.");
			return new IntBuffer(0,0);
		}
		
		if (image==null)
		{
			System.err.println("InputStream error from reading '"+directory+"'.");
			return new IntBuffer(0,0);
		}
		
		return convert(image);
	}
	
	/*
	 * convert BufferedImage to buffer
	 */
	private static IntBuffer convert(BufferedImage image)
	{
		int width, height;
		width 	= image.getWidth();
		height 	= image.getHeight();
		
		int[] pixels = new int[width*height];
		
		int i,j,k=0;
		for(j=0; j<height; j++)
		for(i=0; i<width; i++, k++)
			pixels[k] = image.getRGB(i,j);
		
		IntBuffer tex = new IntBuffer(width,height);
		tex.plot(pixels);
		return tex;
	}
}
