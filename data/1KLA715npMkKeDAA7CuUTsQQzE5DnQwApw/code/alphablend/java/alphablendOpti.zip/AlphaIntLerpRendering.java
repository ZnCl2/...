package graphics_rendering.alphablend.image_02;

public class AlphaIntLerpRendering
{
	public static void main(String[] args) 
	{
		new AlphaIntLerpRendering();
	}
	
	// ============================================
	
	int width = 640;
	int height = 480;
	
	public AlphaIntLerpRendering()
	{
		Window wnd = new Window("Optimized Alpha Blending");
		Surface srf = new Surface(width, height);
		wnd.addSurface(srf);
		
		IntBuffer image1 = ImageLoader.file( "path/to/your/image.png" );
		IntBuffer image2 = new IntBuffer(width,height);
		
		/*
		 * draw two images on top of each other. draw to image2 so we 
		 * can render the result to the Surface, which renders to the window
		 */
		drawTransparency(100, 100, image1, image2);
		drawTransparency(200, 50, image1, image2);
		
		/*
		 * draw to the window
		 */
		drawNoTransparency(0,0, image2, srf);
		wnd.repaint();
		
		wnd.setVisible(true);
	}
	
	/*
	 * draw a source image onto a destination image
	 */
	public void drawNoTransparency(int x, int y, IntBuffer source, Surface screen)
	{
		int w = source.getWidth();
		int h = source.getHeight();
		int wmax = screen.getWidth();
		int hmax = screen.getHeight();
		
		// clip negatives
		int xoff = (x<0)?-x:0;
		int yoff = (y<0)?-y:0;
		w = ((w+x) >= wmax)? -x+wmax :w;
		h = ((h+y) >= hmax)? -y+hmax :h;
		
		// draw
		for (int j=yoff,k=h; j<k; j++)
		for (int i=xoff,l=w; i<l; i++)
		{
			int c = source.grab(i, j);
			screen.plot(i+x, j+y, c);
		}
	}
	
	/*
	 * draw a source image onto a destination image
	 */
	void drawTransparency(int x, int y, IntBuffer source, IntBuffer screen)
	{
		int w = source.getWidth();
		int h = source.getHeight();
		int wmax = screen.getWidth();
		int hmax = screen.getHeight();
		
		// clip negatives
		int xoff = (x<0)?-x:0;
		int yoff = (y<0)?-y:0;
		
		// clip max values
		w = ((w+x) >= wmax)? -x+wmax :w;
		h = ((h+y) >= hmax)? -y+hmax :h;
		
		// draw
		for (int j=yoff,k=h; j<k; j++)
		for (int i=xoff,l=w; i<l; i++)
		{
			int c = source.grab(i, j);
			int srcc = screen.grab(i+x, j+y);
			
			// extract alpha channel
			int a = (c>>24) & 0xFF;
			c = intLerpARGB(srcc, c, a+1);
			
			screen.plot(i+x, j+y, c);
		}
	}
	
	/*
	 * interpolates from color1 to color2 indicated by the given lerp value [0-1]
	 * lerp = short for linear interpolation
	 */
	int intLerpARGB(int c1, int c2, int lerp)
	{
		int a = (c1>>24)& 0xFF;
		int r = (c1>>16)& 0xFF;
		int g = (c1>>8) & 0xFF;
		int b = (c1) 	& 0xFF;
		
		int a2 = (c2>>24)& 0xFF;
		int r2 = (c2>>16)& 0xFF;
		int g2 = (c2>>8) & 0xFF;
		int b2 = (c2) 	 & 0xFF;
		
		a = intLerp256(a, a2, lerp);
		r = intLerp256(r, r2, lerp);
		g = intLerp256(g, g2, lerp);
		b = intLerp256(b, b2, lerp);
		
		return toInt(a,r,g,b);
	}
	
	int intLerp256(int A, int B, int F)
	{
		return (A*(256-F) + B * F) >> 8;
	}
	
	int toInt(int a, int r,int g,int b)
	{
		return ( a<<24 | r<<16 | g<<8 | b );
	}
}
