package graphics_rendering.alphablend.image_03;

/*
 * a container for 32bit data, like an image or basic depth buffer
 */
public class IntBuffer
{
	private int[] data;
	private int width,height;
	
	public IntBuffer(int w, int h) 
	{
		width = w;
		height = h;
		data = new int[width*height];
	}
	
	public int getHeight() 
	{
		return height;
	}
	
	public int getWidth() 
	{
		return width;
	}
	
	/*
	 * exposes the entire data buffer
	 */
	public int[] getContent()
	{
		return data;
	}
	
	/*
	 * set all data to the given value
	 */
	public void clear(int c)
	{
		for (int i=0, l=data.length; i<l; i++)
    	{
    		data[i] = c;
    	}
	}

	/*
	 * take a value from the buffer
	 */
	public int grab(int x, int y)
	{
		int i = x + y*width;
		return data[i];
	}
	
	/*
	 * place a value into the buffer
	 */
	public void plot(int x, int y, int d)
	{
		int i = x + y*width;
		data[i] = d;
	}
	
	/*
	 * place a value on an index
	 */
	public void plot(int i, int c) 
	{
		data[i] = c;
	}
	
	/*
	 * copy over the values of one array into another.
	 * make sure they are the same length
	 */
	public void plot(int[] c)
    {
    	for (int i=0, l=c.length; i<l; i++)
    	{
    		data[i] = c[i];
    	}
    }
	
	/*
	 * resize the buffer and clear the content with the given value
	 */
	public void resize(int w, int h, int value)
	{
		width = w;
		height = h;
		data = new int[width*height];
		clear(value);
	}
}