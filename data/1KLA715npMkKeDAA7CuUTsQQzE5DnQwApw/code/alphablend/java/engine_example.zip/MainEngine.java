package graphics_rendering.alphablend.image_03;

public class MainEngine
{
	public static void main(String[] args) 
	{
		new MainEngine();
	}
	
	// ============================================
	
	int width = 640;
	int height = 480;
	
	Window wnd;
	Surface srf;
	IntBuffer frame;
	Engine engine;
	
	boolean running = true;
	int BLACK 	= toInt(255,0,0,0);
	int RED 	= toInt(255,255,0,0);
	int GREEN 	= toInt(150,0,255,0); // translucent
	int BLUE 	= toInt(255,0,0,255);
	
	

	IntBuffer image01;
	IntBuffer image02;
	IntBuffer image03;
	
	
	
	public MainEngine()
	{
		engine = new Engine();
		engine.start();
		
		wnd = new Window("Simple 2D Engine");
		srf = new Surface(width, height);
		frame = new IntBuffer(width,height);
		wnd.addSurface(srf);
		wnd.setVisible(true);
		
		/*
		 * create some images to display
		 */
		image01 = new IntBuffer(100,100);
		image01.clear( RED );
		
		image02 = new IntBuffer(140,80);
		image02.clear( BLUE );
		
		image03 = new IntBuffer(100,150);
		image03.clear( GREEN );
		
		/*
		 * start the update loop.
		 */
		while(running)
		{
			frame.clear(BLACK);
			engine.drawOn(frame);
			update();
			await();
			srf.plot(frame.getContent());
			wnd.repaint();
		}
	}
	
	/*
	 * main update logic will go in this method
	 */
	public void update()
	{
		
		/*
		 * draw here
		 */
		
		// draw red image on top, layer 2
		engine.append(80, 50, image01, 2, false);
		
		// draw translucent green image underneath the red image
		engine.append(130, 90, image03, 1, true);
		
		// draw a blue image under the red and translucent green image
		engine.append(160, 120, image02, 0, false);
		
		
		
	}
	
	/*
	 * wait for the engine to return a frame
	 */
	public void await()
	{
		/*
		 * could add frame-rate management code
		 */
		engine.requestFrame();
		while(!engine.hasFrame()) {}
	}
	
	/*
	 * stops the program
	 */
	public void terminate()
	{
		/*
		 * dont forget to stop the engine
		 */
		engine.terminate();
		running = false;
	}
	
	/*
	 * compile red,green,blue from ranges [0-255] into a 32bit color
	 */
	int toInt(int a, int r,int g,int b)
	{
		return ( a<<24 | r<<16 | g<<8 | b );
	}
}

