package graphics_rendering.alphablend.image_03;

import java.util.Comparator;
import java.util.Vector;

public class Engine extends Thread 
{
	private int LUCID = toInt(0,0,0,0);
	private boolean running = true;
	private Boolean requestFrame = false;
	private Boolean jobDone = false;
	private IntBuffer depth;
	private IntBuffer target;
	private IntBuffer alpha;
	private Vector<DrawRequest> issueList;
	private Vector<DrawRequest> alphaList;
	private Comparator<DrawRequest> compare;
	
	public Engine()
	{
		compare = new Comparator<DrawRequest>()
		{
			public int compare(DrawRequest o1, DrawRequest o2) 
			{
				return o1.getLayer() - o2.getLayer();
			}
		};

		issueList = new Vector<DrawRequest>();
		alphaList = new Vector<DrawRequest>();
		
		depth = new IntBuffer(0,0);
		alpha = new IntBuffer(0,0);
	}
	
	@Override
	public void run()
	{
		while(running)
		{
			/*
			 * if we already completed a frame, skip rendering a new
			 * wait till program retrieves the frame
			 */
			if (!jobDone)
			{
				/*
				 * lock thread, draw all new requests
				 */
				synchronized(issueList)
				{
					if (!issueList.isEmpty())
					{
						for (DrawRequest dr : issueList)
						{
							int x=dr.getX(),
								y=dr.getY(),
								l=dr.getLayer();
							drawNoTransparency(x,y,l, dr.getImage(), target, depth);
							dr.cleanUp();
						}
						issueList.clear();
					}
					
					/*
					 * check if the program is requesting a frame
					 * if not, more opaque images might be requested
					 * otherwise, start rendering transparent images
					 */
					if (requestFrame)
					{
						if (!alphaList.isEmpty())
						{
							/*
							 * sort image layers
							 */
							alphaList.sort(compare);
							
							for (DrawRequest dr : alphaList)
							{
								int x=dr.getX(),
									y=dr.getY(),
									l=dr.getLayer();
								/*
								 * draw on translucent image
								 */
								drawTransparency(x,y,l, dr.getImage(), alpha, depth);
								dr.cleanUp();
							}
							
							alphaList.clear();
							
							/*
							 * apply all blended colors to the frame
							 */
							merge(target, alpha);
						}
						
						/*
						 * flag the job well done
						 */
						synchronized(jobDone) {jobDone = true;}
					}
				}
			}
			
			// end while
		}
	}
	
	/*
	 * stops the engine
	 */
	public void terminate()
	{
		running = false;
	}
	
	/*
	 * add a new request to the render pipeline
	 */
	public void append(int x, int y, IntBuffer img, int layer, boolean hasAlpha)
	{
		DrawRequest dr = new DrawRequest(x,y,img,layer);
		if (hasAlpha)
		{
			synchronized(alphaList)
			{
				alphaList.add(dr);
			}
		}
		else
		{
			synchronized(issueList)
			{
				issueList.add(dr);
			}
		}
	}
	
	/*
	 * prepare the engine with a new buffer to draw on.
	 * adjust the depth buffer and set it to -1.
	 */
	public void drawOn(IntBuffer frame) 
	{
		requestFrame = false;
		jobDone = false;
		target = frame;
		int w=frame.getWidth();
		int h=frame.getHeight();
		depth.resize(w,h, -1);
		alpha.resize(w,h, LUCID);
	}
	
	/*
	 * flag the engine to wrap up rendering
	 */
	public void requestFrame() 
	{
		synchronized(requestFrame)
		{requestFrame = true;}
	}
	
	/*
	 * returns true if the engine is done drawing
	 */
	public boolean hasFrame() 
	{
		synchronized(jobDone)
		{return jobDone;}
	}

	// ===============================================================
	// 							render code
	// ===============================================================

	/*
	 * draw a source image onto a destination image
	 */
	public void drawNoTransparency(int x, int y, int layer, IntBuffer source, IntBuffer screen, IntBuffer depth)
	{
		int w = source.getWidth();
		int h = source.getHeight();
		int wmax = screen.getWidth();
		int hmax = screen.getHeight();
		
		// clip negatives
		int xoff = (x<0)?-x:0;
		int yoff = (y<0)?-y:0;
		w = ((w+x) >= wmax)? -x+wmax :w;
		h = ((h+y) >= hmax)? -y+hmax :h;
		
		// draw
		for (int j=yoff,k=h; j<k; j++)
		for (int i=xoff,l=w; i<l; i++)
		{
			int lay = depth.grab(i+x, j+y);
			// if current pixel is on top of our image's pixel, skip
			if (lay > layer) continue;
			
			int c = source.grab(i, j);
			screen.plot(i+x, j+y, c);
			depth.plot(i+x, j+y, layer);
		}
	}
	
	/*
	 * draw a source image onto a destination image
	 */
	public void drawTransparency(int x, int y, int layer, IntBuffer source, IntBuffer screen, IntBuffer depth)
	{
		int w = source.getWidth();
		int h = source.getHeight();
		int wmax = screen.getWidth();
		int hmax = screen.getHeight();
		
		// clip negatives
		int xoff = (x<0)?-x:0;
		int yoff = (y<0)?-y:0;
		
		// clip max values
		w = ((w+x) >= wmax)? -x+wmax :w;
		h = ((h+y) >= hmax)? -y+hmax :h;
		
		// draw
		for (int j=yoff,k=h; j<k; j++)
		for (int i=xoff,l=w; i<l; i++)
		{
			int lay = depth.grab(i+x, j+y);
			// if current pixel is on top of our image's pixel, skip
			if (lay > layer) continue;
			
			// collect colors
			int c = source.grab(i, j);
			int srcc = screen.grab(i+x, j+y);
			
			// extract values
			int a = (c>>24) & 0xFF;
			c = intLerpARGB(srcc, c, a+1);
			
			screen.plot(i+x, j+y, c);
		}
	}
	
	/*
	 * full-pass merger of the blended colors onto the opaque data
	 */
	public void merge(IntBuffer screen, IntBuffer alpha) 
	{
		int[] scrn = screen.getContent();
		int[] alph = alpha.getContent();
		int c = 0;
		
		for (int i=0,l=scrn.length; i<l; i++)
		{
			int alpC = alph[i];
			int a = (alpC>>24) & 0xFF;
			// if alpha channel is 0%, skip
			if (a > 0) 
			{
				int srcC = scrn[i];
				c = intLerpARGB(srcC, alpC, a+1);
				screen.plot(i, c);
			}
		}
	}
	
	/*
	 * interpolates from color1 to color2 indicated by the given value [0-256]
	 */
	private int intLerpARGB(int c1, int c2, int lerp)
	{
		int a = (c1>>24)& 0xFF;
		int r = (c1>>16)& 0xFF;
		int g = (c1>>8) & 0xFF;
		int b = (c1) 	& 0xFF;
		
		int a2 = (c2>>24)& 0xFF;
		int r2 = (c2>>16)& 0xFF;
		int g2 = (c2>>8) & 0xFF;
		int b2 = (c2) 	 & 0xFF;
		
		a = intLerp256(a, a2, lerp);
		r = intLerp256(r, r2, lerp);
		g = intLerp256(g, g2, lerp);
		b = intLerp256(b, b2, lerp);
		
		return toInt(a,r,g,b);
	}
	
	/*
	 * interpolates from integer1 to integer2 indicated by the given lerp value [0-256]
	 */
	private int intLerp256(int A, int B, int F)
	{
		return (A*(256-F) + B * F) >> 8;
	}
	
	/*
	 * compile alpha,red,green,blue from ranges [0-255] into a 32bit color
	 */
	public int toInt(int a, int r,int g,int b)
	{
		return ( a<<24 | r<<16 | g<<8 | b );
	}
}
