package graphics_rendering.alphablend.image_03;

public class DrawRequest 
{
	private IntBuffer image = new IntBuffer(0,0);
	private int layer = 1;
	private int xpos=0,ypos=0;
	
	public DrawRequest(int x, int y, IntBuffer i, int l)
	{
		xpos = x;
		ypos = y;
		image = i;
		layer = l;
	}
	
	public IntBuffer getImage() 
	{
		return image;
	}
	
	public int getLayer() 
	{
		return layer;
	}
	
	public int getX() 
	{
		return xpos;
	}
	
	public int getY() 
	{
		return ypos;
	}
	
	public void cleanUp() 
	{
		image = null;
	}
}
