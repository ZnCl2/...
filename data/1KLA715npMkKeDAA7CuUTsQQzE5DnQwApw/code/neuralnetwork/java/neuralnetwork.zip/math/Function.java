package ai.neuralnetwork.math;

public abstract class Function 
{
	public abstract float calculate(float in);
	
	// ================================================
	// 				sigmoid function
	// ================================================
	
	public static final Function logistic()
	{
		return new Function()
		{
			public float calculate(float in) {return (float)logistic(in);}
		};
	}
	
	public static final Function nonlin()
	{
		return new Function()
		{
			public float calculate(float in) {return (float)nonlin(in);}
		};
	}
	
	public static final Function logistic 	= logistic();
	public static final Function nonlin 	= nonlin();
	
	/**
	 * sigmoid logistic curve
	 */
	public static double logistic(double x)
	{
		return 1d / (1d + StrictMath.exp(-x));
	}
	
	/**
	 * non linear sigmoid derivative function
	 */
	public static double nonlin(double x)
	{
		return (x*(1d-x));
	}
	
}
