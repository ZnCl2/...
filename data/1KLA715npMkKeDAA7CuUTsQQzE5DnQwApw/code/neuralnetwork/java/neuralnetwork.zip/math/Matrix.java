package ai.neuralnetwork.math;

public class Matrix 
{
	
	/**
	 * multiply two matrices with each other. takes transposition flags
	 * returns the resulting matrix
	 */
	public static float[][] mul(float[][] m1, boolean t1, float[][] m2, boolean t2)
	{
		// if no transposition is done
		if (!t1)
		if (!t2)
		{
			return mul(m1,m2);
		}
		
		// if first is transposed
		if (t1)
		if (!t2)
		{
			int rows = m1[0].length;
			int cols = m2[0].length;
			
			float[][] res = new float[rows][cols];
			
			for (int r=0;r<rows;r++)
			{
				float[] res_row = res[r];
				
				for (int c=0;c<cols;c++)
				{
					res_row[c] = dot( col(m1,r) , col(m2,c) );
				}
			}
			return res;
		}
		
		// if second is transposed
		if (!t1)
		if (t2)
		{
			int rows = m1.length;
			int cols = m2.length;
			
			float[][] res = new float[rows][cols];
			
			for (int r=0;r<rows;r++)
			{
				float[] res_row = res[r];
				float[] m1_row = m1[r];
				
				for (int c=0;c<cols;c++)
				{
					res_row[c] = dot( m1_row , m2[c] );
				}
			}
			return res;
		}
		
		// if both transposed
		if (t1)
		if (t2)
		{
			int rows = m1[0].length;
			int cols = m2.length;
			
			float[][] res = new float[rows][cols];
			
			for (int r=0;r<rows;r++)
			{
				float[] res_row = res[r];
				
				for (int c=0;c<cols;c++)
				{
					res_row[c] = dot( col(m1,r) , m2[c] );
				}
			}
			return res;
		}
		
		
		return new float[0][0];
	}
	
	// ========================================
	
	/**
	 * multiply two matrices with each other.
	 * returns the resulting matrix
	 */
	public static float[][] mul(float[][] m1, float[][] m2)
	{
		int rows = m1.length;
		int cols = m2[0].length;
		
		float[][] res = new float[rows][cols];
		for (int r=0;r<rows;r++)
		{
			float[] m1_row = m1[r];
			float[] res_row = res[r];
			
			for (int c=0;c<cols;c++)
			{
				float d = dot( m1_row , col(m2,c) );
				res_row[c] = d;
			}
		}
		return res;
	}
	
	/**
	 * perform a multiplication on each element of the given matrix
	 */
	public static float[][] mul(float[][] m, float value)
	{
		int rows = m.length;
		int cols = m[0].length;
		float[][] res = new float[rows][cols];
		for (int y=0; y<rows; y++)
		{
			float[] r = res[y];
			float[] mm = m[y];
			
			for (int x=0; x<cols; x++)
			{
				r[x] = value * mm[x];
			}
		}
		return res;
	}
	
	/**
	 * perform a function on each element of the given matrix
	 */
	public static float[][] map(float[][] m, Function s)
	{
		int rows = m.length;
		int cols = m[0].length;
		float[][] res = new float[rows][cols];
		for (int y=0; y<rows; y++)
		{
			float[] res_y = res[y];
			float[] m_y = m[y];
			
			for (int x=0; x<cols; x++)
			{
				res_y[x] = s.calculate(m_y[x]);
			}
		}
		return res;
	}
	
	/**
	 * transpose a matrix
	 */
	public static float[][] transpose(float[][] matrix)
	{
		int rows = matrix.length;
		int cols = matrix[0].length;
		
		float[][] res = new float[cols][rows];
		
		for (int r=0; r<rows; r++)
		{
			float[] row = matrix[r];
			
			for (int c=0; c<cols; c++)
			{
				res[c][r] = row[c];
			}
		}
		
		return res;
	}
	
	/**
	 * copy a matrix
	 */
	public static float[][] copy(float[][] matrix) 
	{
		int rows = matrix.length;
		int cols = matrix[0].length;
		
		float[][] res = new float[rows][cols];
		
		for (int r=0; r<rows; r++)
		{
			float[] row = matrix[r];
			float[] res_y = res[r];
			
			for (int c=0; c<cols; c++)
			{
				res_y[c] = row[c];
			}
		}
		return res;
	}
	
	/*
	 * set the given matrix to a number
	 */
	public static void set(float[][] matrix, float v) 
	{
		int rows = matrix.length;
		int cols = matrix[0].length;
		
		for (int r=0; r<rows; r++)
		{
			float[] row = matrix[r];
			for (int c=0; c<cols; c++)
			{
				row[c] = v;
			}
		}
	}

	// ========================================
	
	public static float dot(float[] a, float[] b)
	{
		float r=0f;
		
		for (int i=0,l=a.length; i<l; i++) 
			r = r + (a[i]*b[i]);
		
		return r;
	}
	
	public static float[] col(float[][] matrix, int i)
	{
		int l = matrix.length;
		float[] r = new float[l];
		
		for (int it=0;it<l;it++)
			r[it] = matrix[it][i];
		
		return r;
	}

	public static float[] row(float[][] matrix,int i)
	{
		return matrix[i];
	}
}
