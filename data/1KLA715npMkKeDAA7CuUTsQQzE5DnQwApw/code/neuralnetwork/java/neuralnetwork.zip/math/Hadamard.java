package ai.neuralnetwork.math;

public class Hadamard 
{
	
	// =====================================================
	
	/**
	 * add two matrices element-wise
	 */
	public static float[][] add(float[][] m1, float[][] m2)
	{
		int r = m1.length;
		int c = m1[0].length;
		
		float[][] res = new float[r][c];
		for (int y=0;y<r;y++)
		{
			float[] res_y = res[y];
			float[] m1_y = m1[y];
			float[] m2_y = m2[y];
			
			for (int x=0;x<c;x++)
			{
				res_y[x] = m1_y[x] + m2_y[x];
			}
		}
		return res;
	}
	
	/**
	 * add two matrices element-wise
	 */
	public static float[][] sub(float[][] m1, float[][] m2)
	{
		int r = m1.length;
		int c = m1[0].length;
		
		float[][] res = new float[r][c];
		for (int y=0;y<r;y++)
		{
			float[] res_y = res[y];
			float[] m1_y = m1[y];
			float[] m2_y = m2[y];
			
			for (int x=0;x<c;x++)
			{
				res_y[x] = m1_y[x] - m2_y[x];
			}
		}
		return res;
	}
	
	/**
	 * multiply two matrices element-wise
	 */
	public static float[][] mul(float[][] m1, float[][] m2)
	{
		int r = m1.length;
		int c = m1[0].length;
		
		float[][] res = new float[r][c];
		for (int y=0;y<r;y++)
		{
			float[] res_y = res[y];
			float[] m1_y = m1[y];
			float[] m2_y = m2[y];
			
			for (int x=0;x<c;x++)
			{
				res_y[x] = m1_y[x] * m2_y[x];
			}
		}
		return res;
	}
}
