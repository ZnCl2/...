package ai.neuralnetwork.nn;

import ai.neuralnetwork.math.Function;

/*
 * manage a set of layers
 * 
 * the constructor asks the amount of nodes per layer in an int[] array
 * the first layer is always the input layer
 */
public class Network 
{
	private Layer[] layer;
	private int[] l_index;
	private int leng = 0;
	
	public Network(int... layers)
	{
		l_index = layers;
		leng 	= layers.length - 1;
		layer 	= new Layer[leng];
		
		for (int i=0, l=leng; i<l; i++)
		{
			int index_0 = l_index[i];
			int index_1 = l_index[i+1];
			
			/*
			 * hard-code the type of activation function for all neurons.
			 * in some cases different functions are required
			 */
			layer[i] = new Layer(index_0, 
								 index_1, 
								 Function.logistic, // sigmoid logistic curve
								 Function.nonlin ); // sigmoid derivative
			
		}
		
	}

	// train the neural network
	public void train(float[][] data, float[][] answer, float rate)
	{
		// feed forward 
		
		Layer lay = layer[0];
		lay.input( data );
		lay.feedforward();
		
		for (int i=1, l=leng; i<l; i++)
		{
			Layer l0 = layer[i-1];
			Layer l1 = layer[i];
			
			l1.input( l0.result() );
			l1.feedforward();
		}
		
		// back propagate error correction
		float[][] error;
		
		lay = layer[leng-1];
		error = lay.error( answer );
		
		for (int i=leng-1, l=0; i>=l; i--)
		{
			Layer l1 = layer[i];
			error = l1.backpropagate(error, rate);
		}
		
	}
	
	// test the networks accuracy
	public float[][] guess(float[][] data)
	{
		Layer lay = layer[0];
		lay.input( data );
		lay.feedforward();
		
		for (int i=1, l=leng; i<l; i++)
		{
			Layer l0 = layer[i-1];
			Layer l1 = layer[i];
			
			l1.input( l0.result() );
			l1.feedforward();
		}
		
		lay = layer[leng-1];
		return lay.result();
	}
	
	
}
