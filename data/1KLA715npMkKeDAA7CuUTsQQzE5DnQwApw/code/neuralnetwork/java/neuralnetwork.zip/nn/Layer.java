package ai.neuralnetwork.nn;

import ai.neuralnetwork.math.Function;
import ai.neuralnetwork.math.Hadamard;
import ai.neuralnetwork.math.Matrix;

/**
 * To learn, is to minimize a cost function..
 */
public class Layer
{
	private int in,out;
	private Function f, d; // activation function and its derivative
	private float[][] W; // weights
	private float[][] I; // activation (input)
	private float[][] B; // bias
	private float[][] O; // output
	
	/**
	 * create a neural network layer with a given amount of in and outputs.<br>
	 * pass a function to perform when the activation is called.
	 */
	public Layer(int in, int out, Function f, Function d)
	{
		this.f		= f;
		this.d		= d;
		this.in 	= in;
		this.out 	= out;
		
		// all math is performed with matrices. 
		// Makes the code less transparent, but the math will be accurate.
		W 	= new float[out][in]; // weights
		B 	= new float[out][1]; // biases
		I 	= new float[in][1]; // input nodes
		O 	= new float[out][1]; // output nodes
		
		// randomize weights and biases
		for (int i=0; i<out; i++)
		{
			B[i][0] = (float)(StrictMath.random()*2.0 - 1.0);
			
			float[] v = W[i];
			for (int j=0; j<in; j++)
			{
				v[j] = (float)(StrictMath.random()*2.0 - 1.0);
			}
		}
	}
	
	/**
	 * perform matrix math and add bias, then pass through an activation function
	 * O = func( W*I + b )
	 */
	public void feedforward()
	{
		// convert input matrix to vector
		float[] I_column = Matrix.col(I,0);
		float[] B_column = Matrix.col(B,0);
		
		float[][] feed = new float[out][1];
		for (int r=0;r<out;r++)
		{
			float[] W_row = W[r];
			float d = Matrix.dot( W_row , I_column );
			feed[r][0] = f.calculate(d + B_column[r]);
		}
		O = feed;
	}
	
	/**
	 * get the error from this layer relative to the given answers
	 */
	public float[][] error(float[][] answer)
	{
		return Hadamard.sub(answer, O);
	}
	
	/**
	 * multiply the errors with the transpose of the weights.
	 * backpropagate errors using gradient decent
	 * 
	 * W * I = O
	 * 
	 * calculate error at the previous layer
	 * returns the errors
	 * 
	 * W^T * O = I
	 * W^T * O_error = I_error (error at input)
	 * 
	 * apply corrections to weight
	 * s
	 * delta_W = E * func'(O) * I^T
	 * W = W + delta_W
	 * 
	 */
	public float[][] backpropagate(float[][] error, float rate)
	{
		// use derivative to get the gradient
		float[][] d_O = Matrix.map(O, d);
		float[][] gradient = Hadamard.mul(error, d_O);
		gradient = Matrix.mul(gradient, rate);
		
		 // get input matrix transposition
		float[][] d_W = Matrix.mul(gradient,false, I,true); 
		
		// apply correction
		W = Hadamard.add(W, d_W);
		B = Hadamard.add(B, gradient);
		
		// calculate the influence of error at the inputs
		// return for next layer backpropagation
		float[][] input_error = Matrix.mul(W,true, error,false);
		return input_error;
	}
	
	/**
	 * pass an float[] of input values of the same length at the input layer
	 */
	public void input(float[][] input)
	{
		if (input.length == in) I = input;
	}
	
	/**
	 * returns a float[][] copy of the output values
	 */
	public float[][] result()
	{
		return Matrix.copy(O);
	}
	
}
