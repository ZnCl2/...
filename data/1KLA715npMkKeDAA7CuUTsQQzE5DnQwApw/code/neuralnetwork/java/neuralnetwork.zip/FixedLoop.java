package ai.neuralnetwork;

/** Fixed time stepping<br><br>
 * 
 * + Consistent render time across different machines.<br>
 * + Has interpolation<br>
 * + Good for math heavy games.<br>
 * = No delta time. Each render has equal time spacing.<br>
 * - Not good on machines that experience frequent interruptions.<br>
 * - CPU intensive on some OS.<br>
 * 
 */
public abstract class FixedLoop
{
	private final long NANO = 1000000000;	// 10^9

	private double game_hertz;
	private int game_fps;
	private long ideal_render_time;
	private long ideal_update_time;
	private double inv_ideal_update_time;
	private double inv_game_hertz;
	
	private long update_nanotime_prev;
	private long render_nanotime_prev;
	
	private boolean running = true;
	private boolean paused = false;
	
	/*
	 * a pseudo-constructor
	 */
	public abstract void init();
	
	/*
	 * override this method to insert your own game logic 
	 */
	public abstract void update(double time);
	
	/*
	 * override this method to organize rendering
	 */
	public abstract void render(double lerp);
	
	/*
	 * Start the program.
	 */
	public void start() 
	{
		setTargetHz(20.0);
		setTargetFPS(60);
		
		init();
		
		update_nanotime_prev = System.nanoTime();
		render_nanotime_prev = System.nanoTime();
		
		/*
		 * start loop
		 */
		while (running)
		{
			if (!paused)
			{
				/*
				 * get time stamp
				 */
				long nanotime_curr = System.nanoTime();
				
				/*
				 * update logic while/if we are allowed.
				 * this will catch up on missed time, if it happens. 
				 * far example, some process on your OS halted the game for a moment.
				 */
				while( nanotime_curr - update_nanotime_prev > ideal_update_time)
				{
					update(inv_game_hertz);
					
					/*
					 * step update time. Try again
					 */
					update_nanotime_prev += ideal_update_time;
				}
				
				/*
				 * calculate in-between frame interpolation. capped at 1(100%).
				 */
				double interpolation = (nanotime_curr - update_nanotime_prev) * inv_ideal_update_time;
				interpolation = (interpolation>1d)? 1d: interpolation;
				
				/*
				 * render with interpolation
				 */
				render(interpolation);
				render_nanotime_prev = nanotime_curr;
				
				/*
				 * if both updating and rendering have been performed recently, yield the thread.
				 * this time, we cant sleep the thread. it causes blank frame. instead,
				 * we yield to tell the system this thread isn't important so we conserve CPU power
				 */
				while ( nanotime_curr - render_nanotime_prev < ideal_render_time 
						&& nanotime_curr - update_nanotime_prev < ideal_update_time)
				{
					Thread.yield();
					nanotime_curr = System.nanoTime();
				}
			}
		}
		
		cleanUp();
	}
	
	/*
	 * Set the target renders per second.
	 */
	public void setTargetFPS(int fps) 
	{
		game_fps = fps;
		ideal_render_time = NANO / game_fps;
	}
	
	/*
	 * Set the target updates per second.
	 */
	public void setTargetHz(double hertz) 
	{
		game_hertz 				= hertz;
		inv_game_hertz 			= 1d / game_hertz;
		ideal_update_time 		= (long)((double)NANO * inv_game_hertz);
		inv_ideal_update_time 	= 1d / ideal_update_time;
	}
	
	/*
	 * Pause the program, but does not terminate program.
	 */
	public void pause(boolean pause)
	{
		this.paused = pause;
	}

	/*
	 * Terminates the program.
	 */
	public void stop()
	{
		running = false;
	}
	
	public void cleanUp() { }
}
