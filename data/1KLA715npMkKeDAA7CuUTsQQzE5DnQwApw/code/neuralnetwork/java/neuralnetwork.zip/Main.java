package ai.neuralnetwork;

import ai.neuralnetwork.nn.Network;

public class Main extends FixedLoop
{
	public static void main(String[] args) 
	{
		Main g = new Main();
		g.start();
	}
	
	// =====================================================

	final int BLACK = toInt(0, 0, 0);
	final int WHITE = toInt(255, 255, 255);
	
	int world_width 	= 80;
	int world_height 	= 80;
	int grid_size 		= 5;
	float inv_k  = 1f/(float)world_height;
	float inv_l  = 1f/(float)world_width;
	
	private FloatBuffer world;
	
	// =====================================================
	
	/*
	 * size the window based on the size of the training ground
	 */
	private int width 			= world_width * grid_size;
	private int height 			= world_height * grid_size;
	private String title 		= "Machine Learning - Neural Networks";
	
	private Window wnd;
	private Surface srf;

	// =====================================================
	
	/*
	 * neural network with 1 input layer as usual, and 3 processing layers.
	 * 
	 * note:
	 * 
	 * more layers makes an AI more certain.
	 * layers with more neurons makes an AI smarter
	 * 
	 */
	Network nn = new Network(2,20,10,1);
	
	/*
	 * create training data in matrix form
	 * corners are 0 = black. 
	 * center is 1 = white
	 * 
	 * these are 2D matrices stored in an array.
	 * not the easiest to edit, but it keeps the math consistent
	 */
	
	float[][][] train_data = 
	{
		{
			{0},
			{0}
		},
		
		{
			{0},
			{1}
		},
		
		{
			{1},
			{0}
		},

		{
			{1},
			{1}
		},

		{
			{0.5f},
			{0.5f}
		}
		
	};
	
	float[][][] train_answer = 
	{
		{
			{0}
		},
		
		{
			{0}
		},
		
		{
			{0}
		},
		
		{
			{0}
		},
		
		{
			{1}
		}
	};
	
	// =====================================================
	
	/*
	 * program constructor
	 */
	@Override
	public void init() 
	{
		this.setTargetFPS(30);
		this.setTargetHz(20);
		
		// make data buffers.
		world 	= new FloatBuffer(world_width, world_height);
		
		// make a window
		wnd = new Window(title);
		srf = new Surface(width, height);
		wnd.addSurface(srf);
		wnd.setVisible(true);
	}
	
	/*
	 * update tick
	 */
	@Override
	public void update(double dt) 
	{
		int leng = train_data.length;
		
		// train for n cycles each update
		for (int i=0; i<20; i++)
		{
			// select a new data point
			int t = (int)( StrictMath.random()*leng + 0.5f )%leng;
			
			nn.train(train_data[t], train_answer[t], 0.2f );
		}
		
		// plot progress
		for (int j=0,k=world_height; j<k; j++)
		{	
			float y = (float)j*inv_k;
			
			for (int i=0,l=world_width; i<l; i++)
			{
				float x = (float)i*inv_l;
				
				// make test column matrix
				float[][] test = {{x},{y}};
				
				test = nn.guess(test);
				
				world.plot(i, j, test[0][0]);
			}
		}
	}
	
	/*
	 * render loop
	 */
	@Override
	public void render(double di) 
	{
		// draw the current state of the training ground
		for (int j=0,k=world_height; j<k; j++)
		{
			for (int i=0,l=world_width; i<l; i++)
			{
				float value = world.grab(i, j);
				int c = intLerpARGB(BLACK, WHITE, (int)(value*255f) );
				rect(i*grid_size, j*grid_size, grid_size, grid_size, c, srf);
			}
		}
		
		wnd.repaint();
	}
	
	// =====================================================
	
	/*
	 * draws a rectangle filled with the given color
	 */
	public void rect(int x, int y, int w, int h, int c, Surface screen) 
	{
		int wmax = screen.getWidth();
		int hmax = screen.getHeight();
		
		int xoff = (x<0)?-x:0;
		int yoff = (y<0)?-y:0;
		w = ((w+x) >= wmax)? -x+wmax :w;
		h = ((h+y) >= hmax)? -y+hmax :h;
		
		for (int j=yoff,k=h; j<k; j++)
		for (int i=xoff,l=w; i<l; i++)
			screen.plot(i+x, j+y, c);
	}

	public int intLerpARGB(int c1, int c2, int lerp)
	{
		int a = (c1>>24)& 0xFF;
		int r = (c1>>16)& 0xFF;
		int g = (c1>>8) & 0xFF;
		int b = (c1) 	& 0xFF;
		
		int a2 = (c2>>24)& 0xFF;
		int r2 = (c2>>16)& 0xFF;
		int g2 = (c2>>8) & 0xFF;
		int b2 = (c2) 	 & 0xFF;
		
		a = intLerp256(a, a2, lerp);
		r = intLerp256(r, r2, lerp);
		g = intLerp256(g, g2, lerp);
		b = intLerp256(b, b2, lerp);
		
		return ( a<<24 | r<<16 | g<<8 | b );
	}
	
	public int intLerp256(int A, int B, int F)
	{
		return (A*(256-F) + B * F) >> 8;
	}
	
	public int toInt(int r,int g,int b)
	{
		return ( (255<<24) | r<<16 | g<<8 | b );
	}
}
