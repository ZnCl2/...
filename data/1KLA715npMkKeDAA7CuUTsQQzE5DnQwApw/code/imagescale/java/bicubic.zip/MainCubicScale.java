package graphics_rendering.imagescale.image_04;

public class MainCubicScale
{
	public static void main(String[] args) 
	{
		new MainCubicScale();
	}
	
	// ============================================
	
	/*
	 * window dimensions
	 */
	int width = 640;
	int height = 480;
	
	// ============================================
	
	public MainCubicScale()
	{
		Window wnd = new Window("Bicubic Scaling");
		Surface srf = new Surface(width, height);
		wnd.addSurface(srf);
		
		/*
		 * make an image with random colors
		 */
		int img_w = 12;
		int img_h = 12;
		int[] img_colors = new int[img_w*img_h];
		for (int i=0,l=img_colors.length; i<l;i++)
		{
			int color = toInt(  (int)(Math.random()*255.0 + 0.5),
								(int)(Math.random()*255.0 + 0.5),
								(int)(Math.random()*255.0 + 0.5));
			img_colors[i] = color;
		}
		IntBuffer image = new IntBuffer(img_w,img_h);
		image.plot(img_colors);
		
		/*
		 * up-scale the image to fit inside the window
		 * draw to the rendering surface
		 */
		scale(0, 0, width, height, image, srf);
		
		/*
		 * update window
		 */
		wnd.repaint();
		wnd.setVisible(true);
	}
	
	/*
	 * draw a source image onto a destination image scaling to desired dimensions
	 */
	public void scale(int sx, int sy, int dx, int dy, 
					  IntBuffer source, Surface screen)
	{
		int sw = source.getWidth();
		int sh = source.getHeight();
		int deltax = (dx-sx);
		int deltay = (dy-sy);
		
		/*
		 * get ratios
		 */
		float ratiox = (float)sw / (float)deltax;
		float ratioy = (float)sh / (float)deltay;
		float currX, currY, startX=0f, startY=0f;
		
		/*
		 * reverse draw step for flipped image
		 */
		if (deltax<0)
		{
			startX = ratiox*(deltax+1);
			deltax = -deltax;
			sx = dx;
		}
		if (deltay<0)
		{
			startY = ratioy*(deltay+1);
			deltay = -deltay;
			sy = dy;
		}
		
		/*
		 * clipping
		 */
		int offx = 0;
		if (sx<0)
		{
			offx = -sx;
			startX = startX + offx*ratiox;
		}
		
		int offy = 0;
		if (sy<0)
		{
			offy = -sy;
			startY = startY + offy*ratioy;
		}
		
		sw = screen.getWidth();
		sh = screen.getHeight();
		if (sx + deltax > sw)
		{
			deltax = deltax - (sx + deltax - sw);
		}
		if (sy + deltay > sh)
		{
			deltay = deltay - (sy + deltay - sh);
		}
		
		/*
		 * draw image
		 */
		currY = startY;
		for (int j=offy, k=deltay; j<k; j++)
		{
			currX = startX;
			for (int i=offx, l=deltax; i<l; i++)
			{
				int c = getCubic(currX,currY,source);
				
				screen.plot(sx+i, sy+j, c);
				currX += ratiox;
			}
			currY += ratioy;
		}		
	}
	
	/*
	 * cubic interpolation
	 */
	private int getCubic(float step_x, float step_y, IntBuffer s)
	{
		int w = s.getWidth();
		int h = s.getHeight();
		
		int s_x2 = (int)step_x;
		int s_x1 = s_x2 - 1;
		int s_x3 = s_x2 + 1;
		int s_x4 = s_x2 + 2;

		int s_y2 = (int)step_y;
		int s_y1 = s_y2 - 1;
		int s_y3 = s_y2 + 1;
		int s_y4 = s_y2 + 2;
		
		/*
		 * calculate grid offset
		 */
		float off_x = step_x - (float)s_x2;
		float off_y = step_y - (float)s_y2;
		
		/*
		 * clip, loop around
		 */
		s_x1 	= (s_x1<0)?s_x2:s_x1;
		s_x3 	= (s_x3>=w)?s_x3%w:s_x3;
		s_x4 	= (s_x4>=w)?s_x4%w:s_x4;
		
		s_y1 	= (s_y1<0)?s_y2:s_y1;
		s_y3 	= (s_y3>=h)?s_y3%h:s_y3;
		s_y4 	= (s_y4>=h)?s_y4%h:s_y4;
		
		/*
		 * interpolate each row of colors over x
		 * then interpolate results over y to get final color
		 */
		int col1 = colorCurp(s.grab(s_x1, s_y1), s.grab(s_x2, s_y1), s.grab(s_x3, s_y1), s.grab(s_x4, s_y1), off_x);
		int col2 = colorCurp(s.grab(s_x1, s_y2), s.grab(s_x2, s_y2), s.grab(s_x3, s_y2), s.grab(s_x4, s_y2), off_x);
		int col3 = colorCurp(s.grab(s_x1, s_y3), s.grab(s_x2, s_y3), s.grab(s_x3, s_y3), s.grab(s_x4, s_y3), off_x);
		int col4 = colorCurp(s.grab(s_x1, s_y4), s.grab(s_x2, s_y4), s.grab(s_x3, s_y4), s.grab(s_x4, s_y4), off_x);
		return colorCurp(col1,col2,col3,col4, off_y);
	}
	
	// ===============================================================
	
	/*
	 * color cubic interpolation
	 */
	public int colorCurp(int c1, int c2, int c3, int c4, float lerp)
	{
		int r1 = (c1>>16) & 0xFF;
		int g1 = (c1>>8) & 0xFF;
		int b1 = (c1) & 0xFF;
		
		int r2 = (c2>>16) & 0xFF;
		int g2 = (c2>>8) & 0xFF;
		int b2 = (c2) & 0xFF;
		
		int r3 = (c3>>16) & 0xFF;
		int g3 = (c3>>8) & 0xFF;
		int b3 = (c3) & 0xFF;
		
		int r4 = (c4>>16) & 0xFF;
		int g4 = (c4>>8) & 0xFF;
		int b4 = (c4) & 0xFF;
		
		r1 = (int)curp(r1,r2,r3,r4, lerp);
		g1 = (int)curp(g1,g2,g3,g4, lerp);
		b1 = (int)curp(b1,b2,b3,b4, lerp);
		
		/*
		 * make sure color values are within the range of [0-255]
		 */
		r1 = clamp(0,r1,255);
		g1 = clamp(0,g1,255);
		b1 = clamp(0,b1,255);
		
		return toInt(r1,g1,b1);
	}
	
	/*
	 * spline coefficients.
	 * 
	 * matrix contains values in the sequence of
	 * f(0), f'(0), f(1), f'(1)
	 * every row.
	 */
	public final float[][] spline = 
	{
		{  2f,  1f, -2f,  1f},
		{ -3f, -2f,  3f, -1f},
		{  0f,  1f,  0f,  0f},
		{  1f,  0f,  0f,  0f}
	};
	
	public final float softness = 1.0f;
	
	/*
	 * cubic interpolation function
	 */
	public float curp(float y0,float y1,float y2,float y3,float mu)
	{
		/*
		 * f(0), f'(0), f(1), f'(1)
		 */
		float f_0 	= y1;
		float fp_0 	= (y2-y0)*softness;
		float f_1 	= y2;
		float fp_1 	= (y3-y1)*softness;
		
		/*
		 * color column vector multiplied with a spline matrix
		 */
		float a,b,c,d;
		a = spline[0][0]*f_0 + spline[0][1]*fp_0 + spline[0][2]*f_1 + spline[0][3]*fp_1;
		b = spline[1][0]*f_0 + spline[1][1]*fp_0 + spline[1][2]*f_1 + spline[1][3]*fp_1;
		c = spline[2][0]*f_0 + spline[2][1]*fp_0 + spline[2][2]*f_1 + spline[2][3]*fp_1;
		d = spline[3][0]*f_0 + spline[3][1]*fp_0 + spline[3][2]*f_1 + spline[3][3]*fp_1;
		
		/*
		 * compile 3rd degree polynomial
		 * 
		 * f(x) = ax^3 + bx^2 + cx + d
		 */
		float mu2 = mu*mu; // pre-compute square
		return (a*mu2*mu + b*mu2 + c*mu + d);
	}
	
	/*
	 * clamp the value x between two values.
	 */
	public int clamp(int lower, int x, int upper)
	{
		int x1 = (x<lower)?lower:x;
		return (x1<upper)?x1:upper;
	}
	
	/*
	 * compile aRGB [0-255] to a 32-bit color
	 */
	public int toInt(int r,int g,int b)
	{
		return ( (255<<24) | r<<16 | g<<8 | b );
	}
}
