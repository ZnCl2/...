package graphics_rendering.imagescale.image_01;

public class MainNearestScale
{
	public static void main(String[] args) 
	{
		new MainNearestScale();
	}
	
	// ============================================
	
	int width = 800;
	int height = 600;
	
	public MainNearestScale()
	{
		Window wnd = new Window("Nearest Neighbor Scaling");
		Surface srf = new Surface(width, height);
		wnd.addSurface(srf);
		
		/*
		 * make an image with random colors
		 */
		int img_w = 12;
		int img_h = 12;
		int[] img_colors = new int[img_w*img_h];
		for (int i=0,l=img_colors.length; i<l;i++)
		{
			int color = toInt(  (int)(Math.random()*255.0 + 0.5),
								(int)(Math.random()*255.0 + 0.5),
								(int)(Math.random()*255.0 + 0.5));
			img_colors[i] = color;
		}
		IntBuffer image = new IntBuffer(img_w,img_h);
		image.plot(img_colors);
		
		/*
		 * scale the image
		 */
		scale(0, 0, width, height, image, srf);
		
		/*
		 * draw to surface, update window
		 */
		wnd.repaint();
		wnd.setVisible(true);
	}
	
	/*
	 * draw a source image onto a destination image scaling to desired dimensions
	 */
	public void scale(int sx, int sy, int dx, int dy, 
					  IntBuffer source, Surface screen)
	{
		int sw = source.getWidth();
		int sh = source.getHeight();
		int deltax = (dx-sx);
		int deltay = (dy-sy);
		
		/*
		 * get ratios
		 */
		float ratiox = (float)sw / (float)deltax;
		float ratioy = (float)sh / (float)deltay;
		float currX, currY, startX=0f, startY=0f;
		
		/*
		 * reverse draw step for flipped image
		 */
		if (deltax<0)
		{
			startX = ratiox*(deltax+1);
			deltax = -deltax;
			sx = dx;
		}
		if (deltay<0)
		{
			startY = ratioy*(deltay+1);
			deltay = -deltay;
			sy = dy;
		}
		
		/*
		 * clipping
		 */
		int offx = 0;
		if (sx<0)
		{
			offx = -sx;
			startX = startX + offx*ratiox;
		}
		
		int offy = 0;
		if (sy<0)
		{
			offy = -sy;
			startY = startY + offy*ratioy;
		}
		
		sw = screen.getWidth();
		sh = screen.getHeight();
		if (sx + deltax > sw)
		{
			deltax = deltax - (sx + deltax - sw);
		}
		if (sy + deltay > sh)
		{
			deltay = deltay - (sy + deltay - sh);
		}
		
		/*
		 * draw image
		 */
		currY = startY;
		for (int j=offy, k=deltay; j<k; j++)
		{
			currX = startX;
			for (int i=offx, l=deltax; i<l; i++)
			{
				/*
				 * use shader to get color
				 */
				int c = getNearestNeighbor(currX,currY,source);
				
				screen.plot(sx+i, sy+j, c);
				currX += ratiox;
			}
			currY += ratioy;
		}		
	}
	
	/*
	 * nearest neighbor color grabbing shader
	 */
	private int getNearestNeighbor(float step_x, float step_y, IntBuffer source)
	{
		/*
		 * round location 
		 */
		int grap_x = (int)(step_x + 0.5f);
		int grap_y = (int)(step_y + 0.5f);
		
		int width = source.getWidth();
		int height = source.getHeight();
		
		/*
		 * clip, loop around
		 */
		grap_x = (grap_x>=width)?grap_x%width:grap_x;
		grap_y = (grap_y>=height)?grap_y%height:grap_y;
		
		/*
		 * return color
		 */
		return source.grab(grap_x, grap_y);
	}
	
	/*
	 * compile opaque RGB color
	 */
	public int toInt(int r,int g,int b)
	{
		return ( (255<<24) | r<<16 | g<<8 | b );
	}
	
	/*
	 * clamp a given value between two values.
	 */
	public int clamp(int lower, int x, int upper)
	{
		int x1 = (x<lower)?lower:x;
		return (x1<upper)?x1:upper;
	}
}
