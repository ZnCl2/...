package graphics_rendering.imagescale.image_02;

public class MainLinearScale
{
	public static void main(String[] args) 
	{
		new MainLinearScale();
	}
	
	// ============================================
	
	int width = 800;
	int height = 600;
	
	public MainLinearScale()
	{
		Window wnd = new Window("Bilinear Interpolation Scaling");
		Surface srf = new Surface(width, height);
		wnd.addSurface(srf);
		
		/*
		 * make an image with random colors
		 */
		int img_w = 12;
		int img_h = 12;
		int[] img_colors = new int[img_w*img_h];
		for (int i=0,l=img_colors.length; i<l;i++)
		{
			int color = toInt(  (int)(Math.random()*255.0 + 0.5),
								(int)(Math.random()*255.0 + 0.5),
								(int)(Math.random()*255.0 + 0.5));
			img_colors[i] = color;
		}
		IntBuffer image = new IntBuffer(img_w,img_h);
		image.plot(img_colors);
		
		/*
		 * scale the image
		 */
		scale(0, 0, width, height, image, srf);
		
		/*
		 * draw to surface, update window
		 */
		wnd.repaint();
		wnd.setVisible(true);
	}
	
	/*
	 * draw a source image onto a destination image scaling to desired dimensions
	 */
	public void scale(int sx, int sy, int dx, int dy, 
					  IntBuffer source, Surface screen)
	{
		int sw = source.getWidth();
		int sh = source.getHeight();
		int deltax = (dx-sx);
		int deltay = (dy-sy);
		
		/*
		 * get ratios
		 */
		float ratiox = (float)sw / (float)deltax;
		float ratioy = (float)sh / (float)deltay;
		float currX, currY, startX=0f, startY=0f;
		
		/*
		 * reverse draw step for flipped image
		 */
		if (deltax<0)
		{
			startX = ratiox*(deltax+1);
			deltax = -deltax;
			sx = dx;
		}
		if (deltay<0)
		{
			startY = ratioy*(deltay+1);
			deltay = -deltay;
			sy = dy;
		}
		
		/*
		 * clipping
		 */
		int offx = 0;
		if (sx<0)
		{
			offx = -sx;
			startX = startX + offx*ratiox;
		}
		
		int offy = 0;
		if (sy<0)
		{
			offy = -sy;
			startY = startY + offy*ratioy;
		}
		
		sw = screen.getWidth();
		sh = screen.getHeight();
		if (sx + deltax > sw)
		{
			deltax = deltax - (sx + deltax - sw);
		}
		if (sy + deltay > sh)
		{
			deltay = deltay - (sy + deltay - sh);
		}
		
		/*
		 * draw image
		 */
		currY = startY;
		for (int j=offy, k=deltay; j<k; j++)
		{
			currX = startX;
			for (int i=offx, l=deltax; i<l; i++)
			{
				/*
				 * use shader to get color
				 */
				int c = getLinear(currX,currY,source);
				
				screen.plot(sx+i, sy+j, c);
				currX += ratiox;
			}
			currY += ratioy;
		}		
	}
	
	/*
	 * bilinear interpolation
	 */
	private int getLinear(float step_x, float step_y, IntBuffer source)
	{
		int w = source.getWidth();
		int h = source.getHeight();
		
		int s_x = (int)step_x;
		int s_y = (int)step_y;
		int s_xx = s_x + 1;
		int s_yy = s_y + 1;
		
		/*
		 * calculate grid offset
		 */
		float off_x = step_x - (float)s_x;
		float off_y = step_y - (float)s_y;
		
		int UL,UR,LL,LR, colU,colL;
		
		/*
		 * clip, loop around
		 */
		s_xx = (s_xx>=w)?s_xx%w:s_xx;
		s_yy = (s_yy>=h)?s_yy%h:s_yy;

		/*
		 * get colors
		 */
		UL = source.grab(s_x, s_y);
		UR = source.grab(s_xx, s_y);
		LL = source.grab(s_x, s_yy);
		LR = source.grab(s_xx, s_yy);
		
		/*
		 * interpolate
		 */
		colU = colorLerp(UL,UR, off_x);
		colL = colorLerp(LL,LR, off_x);
		return colorLerp(colU,colL, off_y);
	}
	
	
	/*
	 * linear interpolation function
	 */
	public float lerp(float start, float end, float inter)
	{
		return start*(1f-inter) + end*inter;
	}
	
	/*
	 * color linear interpolation
	 */
	public int colorLerp(int c1, int c2, float lerp)
	{
		int r = (c1>>16)& 0xFF;
		int g = (c1>>8) & 0xFF;
		int b = (c1) 	& 0xFF;
		
		int r2 = (c2>>16)& 0xFF;
		int g2 = (c2>>8) & 0xFF;
		int b2 = (c2) 	 & 0xFF;
		
		r = (int)lerp(r, r2, lerp);
		g = (int)lerp(g, g2, lerp);
		b = (int)lerp(b, b2, lerp);
		
		return toInt(r,g,b);
	}
	
	public int toInt(int r,int g,int b)
	{
		return ( (255<<24) | r<<16 | g<<8 | b );
	}
}
